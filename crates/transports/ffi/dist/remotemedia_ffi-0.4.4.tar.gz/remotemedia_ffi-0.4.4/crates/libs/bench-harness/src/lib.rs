//! `remotemedia bench` — speech-to-speech latency / throughput benchmark.
//!
//! Drives a pipeline (default: the `qwen_s2s_avatar` manifest) in-process,
//! injecting one or more WAV files as 48 kHz mono utterances back-to-back,
//! and measures harness-level end-to-end timings *plus* per-node merged
//! HDR-histogram percentiles from the existing `PerfAggregator` tap.
//!
//! Output: a single `bench_s2s.json` with run metadata, per-utterance
//! timings, end-to-end percentiles, and per-node breakdowns.
//!
//! Activation:
//! ```bash
//! REMOTEMEDIA_PERF_TAP=1 \
//! REMOTEMEDIA_PERF_WINDOW_MS=600000 \
//!   remotemedia bench examples/manifests/qwen_s2s_avatar.json \
//!     --inputs examples/transcribe_demo.wav \
//!     --utterances 10 \
//!     --warmup 1 \
//!     --output bench_s2s.json
//! ```

use anyhow::{Context, Result};
use remotemedia_core::data::perf::PerfSnapshot;
use remotemedia_core::data::{AudioSamples, RuntimeData};
use remotemedia_core::manifest::Manifest;
use remotemedia_core::transport::{
    ExecutorConfig, PipelineExecutor, TransportData, WarmSessionPool,
};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{Duration, Instant};

pub mod capture;
mod wav;

use capture::{CaptureRoot, CaptureSummary, UtteranceCapture};
use wav::parse_wav;

const TARGET_SR: u32 = 48_000;
const CHUNK_SAMPLES: usize = 480; // 10 ms at 48 kHz mono

#[derive(Clone, Debug)]
pub struct BenchConfig {
    /// Human-readable manifest path for reports and capture headers.
    pub manifest_path: PathBuf,
    pub inputs: Vec<PathBuf>,
    pub utterances: usize,
    pub warmup: usize,
    pub realtime_pace: bool,
    pub single_shot: bool,
    pub output_kind: BenchOutput,
    pub response_timeout_secs: u64,
    pub capture_dir: Option<PathBuf>,
    pub capture_tag: Option<String>,
    pub prewarm: bool,
}

impl BenchConfig {
    pub fn new(manifest_path: PathBuf, inputs: Vec<PathBuf>) -> Self {
        Self {
            manifest_path,
            inputs,
            utterances: 10,
            warmup: 1,
            realtime_pace: false,
            single_shot: false,
            output_kind: BenchOutput::Audio,
            response_timeout_secs: 120,
            capture_dir: None,
            capture_tag: None,
            prewarm: true,
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum BenchOutput {
    Audio,
    Data,
}

#[derive(Serialize)]
pub struct RunReport {
    pub schema_version: u32,
    pub started_at_unix_ms: u64,
    pub wall_clock_secs: f64,
    pub manifest_path: String,
    pub manifest_metadata_name: Option<String>,
    pub config: ConfigBlock,
    pub host: HostBlock,
    pub gpu: Vec<GpuInfo>,
    pub utterances: Vec<UtteranceMeasurement>,
    pub end_to_end: EndToEndStats,
    /// Pipeline node ids in manifest declaration order. Lets downstream
    /// tools render `per_node` in pipeline order without re-reading the
    /// manifest. Empty if the manifest had no nodes (shouldn't happen).
    pub node_order: Vec<String>,
    pub per_node: serde_json::Value,
    pub notes: Vec<String>,
    /// Conversational scenario results, populated when the benchmark runs
    /// a multi-turn conversational scenario with barge-in support.
    pub conversational: Option<ConversationalBlock>,
}

#[derive(Serialize)]
pub struct ConfigBlock {
    pub utterances: usize,
    pub warmup: usize,
    pub realtime_pace: bool,
    pub single_shot: bool,
    pub output_kind: BenchOutput,
    pub response_timeout_secs: u64,
    pub inputs: Vec<String>,
    pub perf_tap_enabled: bool,
    pub perf_window_ms: u32,
}

#[derive(Serialize)]
pub struct HostBlock {
    pub os: String,
    pub arch: String,
    pub cpu_logical: usize,
}

#[derive(Serialize, Default)]
pub struct GpuInfo {
    pub name: String,
    pub memory_total_mib: u64,
    pub utilization_pct: u32,
    pub memory_used_mib: u64,
}

#[derive(Serialize)]
pub struct UtteranceMeasurement {
    pub idx: usize,
    pub is_warmup: bool,
    pub source_wav: String,
    pub audio_duration_secs: f64,
    pub push_secs: f64,
    /// Eos-to-first-emit on the selected benchmark output channel.
    pub eos_to_first_emit_secs: Option<f64>,
    /// Eos-to-last-emit on the selected benchmark output channel.
    pub eos_to_last_emit_secs: Option<f64>,
    /// "audio" | "text" | None — which selected channel emitted first.
    pub first_emit_kind: Option<String>,
    /// Eos-to-first-emit on the AUDIO channel specifically. For TTS and
    /// interleaved this is what the user actually hears (TTFA proper).
    /// `None` when no audio was emitted (e.g. ASR mode).
    ///
    /// **Caveat under `--realtime-pace`**: `eos` is anchored to the moment
    /// the bench finished pushing the last speech sample (start of the
    /// trailing-silence window), not to the pipeline's actual
    /// end-of-utterance signal. If VAD declares speech_end *before* eos
    /// — e.g. when the test audio has a soft-consonant / low-energy
    /// region that Silero classifies as silence for ≥`min_silence_duration_ms`
    /// — the accumulator flushes early, LFM2 emits before eos, and this
    /// field saturates to 0 ms (Instant::duration_since is saturating).
    /// That is not a measurement bug, it reflects the pipeline genuinely
    /// emitting before the speaker's wallclock end-of-speech.
    ///
    /// For a realtime-mode TTFA number that is immune to where `eos` is
    /// anchored, read `per_node.lfm2_audio.first_output_latency_us` from
    /// the perf snapshot — it's measured inside the runtime as input
    /// arrival → first output emit on the LFM2 node and reflects only
    /// model-side latency.
    pub eos_to_first_audio_emit_secs: Option<f64>,
    /// Eos-to-first-emit on the TEXT channel specifically. For ASR this
    /// is the TTFT proper. `None` when no text was emitted.
    pub eos_to_first_text_emit_secs: Option<f64>,
    /// Backward-compat: same as eos_to_first_emit_secs when the first
    /// emit was audio, None otherwise.
    pub eos_to_first_tts_secs: Option<f64>,
    pub eos_to_last_tts_secs: Option<f64>,
    pub tts_audio_secs: f64,
    pub tts_frames: usize,
    /// Number of text chunks emitted (ASR mode) or 0.
    pub text_frames: usize,
    /// Total chars emitted across all text frames.
    pub text_chars: usize,
    /// First text payload — useful as a sanity check that ASR returned
    /// something sensible. Truncated by the caller if necessary.
    pub text_first_payload: Option<String>,
    pub timed_out: bool,
}

#[derive(Serialize, Default)]
pub struct EndToEndStats {
    pub measured_utterances: usize,
    /// First emit on the selected benchmark output channel.
    pub eos_to_first_emit_p50_ms: Option<f64>,
    pub eos_to_first_emit_p95_ms: Option<f64>,
    pub eos_to_first_emit_p99_ms: Option<f64>,
    pub eos_to_first_emit_min_ms: Option<f64>,
    pub eos_to_first_emit_max_ms: Option<f64>,
    pub eos_to_last_emit_p50_ms: Option<f64>,
    pub eos_to_last_emit_p95_ms: Option<f64>,
    /// Per-mode counts. Sums to `measured_utterances`.
    pub first_emit_kind_audio: usize,
    pub first_emit_kind_text: usize,
    pub first_emit_kind_none: usize,
    /// Eos-to-first-AUDIO-emit percentiles (TTFA proper). Only includes
    /// utterances that emitted audio at all. For TTS this is the right
    /// "user-perceived" latency.
    pub eos_to_first_audio_p50_ms: Option<f64>,
    pub eos_to_first_audio_p95_ms: Option<f64>,
    pub eos_to_first_audio_p99_ms: Option<f64>,
    /// Eos-to-first-TEXT-emit percentiles (TTFT proper). Only includes
    /// utterances that emitted text. For ASR this is the right latency.
    pub eos_to_first_text_p50_ms: Option<f64>,
    pub eos_to_first_text_p95_ms: Option<f64>,
    pub eos_to_first_text_p99_ms: Option<f64>,
    /// Audio-only legacy fields — only set when first emit was audio.
    pub eos_to_first_tts_p50_ms: Option<f64>,
    pub eos_to_first_tts_p95_ms: Option<f64>,
    pub eos_to_first_tts_p99_ms: Option<f64>,
    pub eos_to_first_tts_min_ms: Option<f64>,
    pub eos_to_first_tts_max_ms: Option<f64>,
    pub eos_to_last_tts_p50_ms: Option<f64>,
    pub eos_to_last_tts_p95_ms: Option<f64>,
    pub response_audio_secs_per_wall_clock: Option<f64>,
    pub audio_in_secs_per_wall_clock: Option<f64>,
}

// ── Conversational scenario data structures ──────────────────────────────

/// High-level description of a multi-turn conversational benchmark scenario.
/// Loaded from a scenario manifest file and drives turn-by-turn input injection.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ConversationalScenario {
    /// Human-readable scenario identifier (e.g. "customer_support_bargein").
    pub scenario: String,
    /// Path to the scenario manifest file.
    pub manifest: PathBuf,
    /// Ordered list of turns that compose this scenario.
    pub turns: Vec<TurnDefinition>,
    /// Optional free-text description of the scenario purpose.
    pub description: Option<String>,
}

/// Definition of a single turn within a conversational scenario.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TurnDefinition {
    /// Path to the WAV input file for this turn.
    pub input: PathBuf,
    /// Type of turn (normal or barge-in).
    pub turn_type: TurnType,
    /// For barge-in turns: the offset in milliseconds from the start of the
    /// previous turn's agent response at which to inject the interruption.
    /// `None` for normal turns.
    pub trigger_at_ms: Option<u64>,
    /// Optional description of what this turn represents.
    pub description: Option<String>,
}

/// The kind of turn in a conversational scenario.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TurnType {
    /// A standard user utterance that starts a new exchange.
    Normal,
    /// A barge-in: the user interrupts the agent mid-response.
    BargeIn,
}

/// Per-scenario results block appended to the run report.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ConversationalBlock {
    /// Scenario identifier matching the input scenario.
    pub scenario: String,
    /// Measurements collected for each turn.
    pub turns: Vec<TurnMeasurement>,
    /// Aggregate summary statistics across all turns.
    pub summary: ConversationalSummary,
}

/// Detailed measurements for a single turn in a conversational scenario.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TurnMeasurement {
    /// Zero-based index of this turn within the scenario.
    pub turn_idx: usize,
    /// Whether this was a normal or barge-in turn.
    pub turn_type: TurnType,
    /// Time-to-first-audio (TTFA) for this turn, in milliseconds.
    pub ttfa_ms: f64,
    /// Total response time from turn start to last audio emit, in milliseconds.
    pub total_response_ms: f64,
    /// Agent turn ID assigned by the pipeline for this response.
    pub agent_turn_id: String,
    /// For barge-in turns: time to detect the barge-in event, in milliseconds.
    /// `None` for normal turns.
    pub barge_in_detection_ms: Option<f64>,
    /// For barge-in turns: time from barge-in detection to cancellation
    /// propagation completing (old response suppressed), in milliseconds.
    /// `None` for normal turns.
    pub cancellation_propagation_ms: Option<f64>,
    /// For barge-in turns: TTFA of the recovery response (after barge-in),
    /// in milliseconds. `None` for normal turns.
    pub recovery_ttfa_ms: Option<f64>,
    /// Whether the stale (interrupted) response was successfully suppressed.
    /// `None` for normal turns.
    pub stale_response_suppressed: Option<bool>,
    /// For barge-in turns: the agent turn ID of the interrupted response
    /// that was cancelled. `None` for normal turns.
    pub interrupted_turn_id: Option<String>,
}

/// Aggregate summary statistics for a conversational scenario.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ConversationalSummary {
    /// Total number of turns in the scenario.
    pub total_turns: usize,
    /// Number of barge-in turns.
    pub barge_in_count: usize,
    /// Average TTFA across all turns, in milliseconds.
    pub avg_ttfa_ms: f64,
    /// Average barge-in detection latency across barge-in turns, in milliseconds.
    /// `None` if there were no barge-in turns.
    pub avg_barge_in_detection_ms: Option<f64>,
    /// Percentage regression of TTFA for barge-in turns compared to normal turns.
    /// Positive means barge-in turns were slower; negative means faster.
    /// `None` if there were no barge-in turns.
    pub ttfa_regression_pct: Option<f64>,
}

/// Executor configuration that matches the historical CLI benchmark
/// budgets for heavyweight avatar/speech pipelines.
pub fn default_executor_config(started_at_unix_ms: u64) -> ExecutorConfig {
    let mut exec_cfg = ExecutorConfig::default();
    exec_cfg.session_id_prefix = format!("bench_{}_{}", std::process::id(), started_at_unix_ms);
    exec_cfg.scheduler_config = exec_cfg
        .scheduler_config
        .with_node_timeout("llm", 300_000)
        .with_node_timeout("stt_in", 60_000)
        .with_node_timeout("kokoro_tts", 120_000)
        .with_node_timeout("audio2face_lipsync", 60_000)
        .with_node_timeout("kimodo_motion", 300_000)
        .with_node_timeout("cc_render", 30_000)
        .with_node_timeout("live2d_render", 30_000)
        // LFM2-Audio (Python multiprocess) — cold-start time-on-budget
        // dominated by transformers/torch venv provisioning + 1.5B-param
        // model download + GPU upload. The scheduler's per-call timeout
        // is a different axis from the multiprocess init_timeout_secs
        // (see REMOTEMEDIA_INIT_TIMEOUT_SECS), but we set this defensively
        // so generation calls also have headroom.
        .with_node_timeout("lfm2_audio", 300_000);
    exec_cfg
}

pub async fn run_benchmark(
    executor: Arc<PipelineExecutor>,
    manifest: Arc<Manifest>,
    config: BenchConfig,
) -> Result<RunReport> {
    let perf_tap = std::env::var("REMOTEMEDIA_PERF_TAP").ok().is_some();
    let perf_window_ms: u32 = std::env::var("REMOTEMEDIA_PERF_WINDOW_MS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(1000);

    if !perf_tap {
        eprintln!(
            "[bench] WARNING: REMOTEMEDIA_PERF_TAP is not set — per-node \
             percentiles will not be collected. Set it (plus a long \
             REMOTEMEDIA_PERF_WINDOW_MS like 600000) for full breakdown."
        );
    }

    let started_at_unix_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    let metadata_name = Some(manifest.metadata.name.clone());
    let node_order: Vec<String> = manifest.nodes.iter().map(|n| n.id.clone()).collect();

    eprintln!(
        "[bench] manifest: {} ({} nodes, {} connections)",
        config.manifest_path.display(),
        manifest.nodes.len(),
        manifest.connections.len()
    );

    // ── Preload all input WAVs (resampled to 48 kHz mono) ────────────────
    let prepared = prepare_inputs(&config.inputs)?;

    let _pool_keepalive = if config.prewarm {
        // Critical: llama.cpp loads the GGUF on *first inference*, not at
        // session init. Without prewarm, the first utterance's LLM call
        // pays 30-60s of cold model load — which blows past the bench's
        // response-timeout and corrupts every utterance after.
        eprintln!(
            "[bench] prewarming pipeline (loads models — may take 30-60s for cold caches)..."
        );
        let prewarm_t0 = Instant::now();
        let pool = WarmSessionPool::new(executor.clone());
        pool.prewarm(manifest.clone()).await.map_err(|e| {
            eprintln!("[bench] ERROR during prewarm: {:?}", e);
            anyhow::anyhow!("WarmSessionPool::prewarm failed: {}", e)
        })?;
        executor.set_default_pool(pool.clone());
        eprintln!(
            "[bench] prewarm complete in {:.2}s",
            prewarm_t0.elapsed().as_secs_f32()
        );
        Some(pool)
    } else {
        None
    };

    // ── Create session (consumes the warm entry) ─────────────────────────
    let session_t0 = Instant::now();
    let mut session = executor
        .create_session(manifest.clone())
        .await
        .map_err(|e| anyhow::anyhow!("create_session failed: {}", e))?;
    eprintln!(
        "[bench] session acquired (warm) in {:.2}s (id={})",
        session_t0.elapsed().as_secs_f32(),
        session.session_id
    );

    let perf_agg = session.perf_aggregator().cloned();
    let outputs = session
        .take_output_receivers()
        .ok_or_else(|| anyhow::anyhow!("output receivers already taken"))?;
    let mut audio_rx = outputs.audio_rx;
    let mut data_rx = outputs.data_rx;
    // Keep video_rx alive when --capture-dir is set so video frames are
    // captured alongside audio/text/json. With no capture configured the
    // bench doesn't use video for TTFA, so dropping it would let the
    // sender's channel fill — keep it and drain into capture (or /dev/null).
    let mut video_rx = outputs.video_rx;

    // ── Capture setup ────────────────────────────────────────────────────
    let capture_root = if let Some(dir) = config.capture_dir.clone() {
        let root =
            CaptureRoot::new(dir, config.capture_tag.clone()).context("initialize capture root")?;
        capture::write_run_header(&root, &config.manifest_path).ok();
        eprintln!(
            "[bench] capturing per-utterance output to {} (tag={:?})",
            root.dir.display(),
            root.tag
        );
        Some(root)
    } else {
        None
    };

    // ── Run loop ─────────────────────────────────────────────────────────
    let total_utterances = config.warmup + config.utterances;
    let mut measurements: Vec<UtteranceMeasurement> = Vec::with_capacity(total_utterances);
    let mut capture_summaries: Vec<CaptureSummary> = Vec::new();
    let bench_t0 = Instant::now();

    for idx in 0..total_utterances {
        let prep = &prepared[idx % prepared.len()];
        let is_warmup = idx < config.warmup;

        eprintln!(
            "[bench] utt {:>3}/{} {} src={} dur={:.2}s",
            idx + 1,
            total_utterances,
            if is_warmup { "warmup" } else { "measure" },
            prep.label,
            prep.duration_secs
        );

        // Drain anything left over from the previous utterance before
        // starting a new clock — keeps eos_to_first_emit measurement
        // tight against this utterance's output.
        while audio_rx.try_recv().is_ok() {}
        while data_rx.try_recv().is_ok() {}
        while video_rx.try_recv().is_ok() {}

        let capture = capture_root
            .as_ref()
            .map(|root| root.for_utterance(idx, is_warmup))
            .transpose()
            .context("create utterance capture")?;

        let outcome = run_one_utterance(
            &session,
            audio_rx,
            data_rx,
            video_rx,
            capture,
            prep,
            config.realtime_pace,
            config.single_shot,
            config.output_kind,
            Duration::from_secs(config.response_timeout_secs),
            idx,
            is_warmup,
        )
        .await?;
        audio_rx = outcome.audio_rx;
        data_rx = outcome.data_rx;
        video_rx = outcome.video_rx;
        let capture = outcome.capture;
        measurements.push(outcome.measurement);

        if let Some(c) = capture {
            match c.finish() {
                Ok(summary) => {
                    eprintln!(
                        "[bench] utt {:>3} captured: audio_streams={} text_chunks={} json={} video={} images={} tensors={} bins={} -> {}",
                        idx + 1,
                        summary.audio_streams.len(),
                        summary.text_chunks,
                        summary.json_events,
                        summary.video_frames,
                        summary.images,
                        summary.tensors,
                        summary.binaries,
                        summary.utt_dir,
                    );
                    capture_summaries.push(summary);
                }
                Err(e) => {
                    eprintln!("[bench] utt {:>3} capture finish failed: {}", idx + 1, e);
                }
            }
        }
    }

    let wall_clock = bench_t0.elapsed().as_secs_f64();
    let _ = &capture_summaries; // currently informational only; future: thread into RunReport

    // ── Pull final perf snapshot ─────────────────────────────────────────
    // Take the typed snapshot once so we can both serialize it into the
    // report and render an aligned per-node table in `print_summary`.
    let perf_snapshot: Option<PerfSnapshot> = perf_agg.as_ref().map(|agg| agg.peek_snapshot());
    let per_node = perf_snapshot
        .as_ref()
        .map(|snap| serde_json::to_value(snap).unwrap_or(serde_json::Value::Null))
        .unwrap_or(serde_json::Value::Null);

    // ── End-to-end stats ─────────────────────────────────────────────────
    let measured: Vec<&UtteranceMeasurement> = measurements
        .iter()
        .filter(|m| !m.is_warmup && !m.timed_out)
        .collect();

    let end_to_end = compute_e2e_stats(&measured, wall_clock);

    // ── GPU info ─────────────────────────────────────────────────────────
    let gpu = sample_gpu_info();

    // ── Tear down session (graceful) ─────────────────────────────────────
    let _ = session.close().await;

    // ── Write report ─────────────────────────────────────────────────────
    let mut notes = Vec::new();
    if !perf_tap {
        notes.push("REMOTEMEDIA_PERF_TAP not set — per-node block is null".to_string());
    }
    if perf_tap && perf_window_ms < 60_000 {
        notes.push(format!(
            "REMOTEMEDIA_PERF_WINDOW_MS={perf_window_ms} is short; per-node \
             snapshot reflects only the most-recent window — set 600000 \
             for whole-run merged histograms"
        ));
    }
    if config.warmup == 0 {
        notes.push(
            "warmup=0: first utterance includes cold-load cost; consider --warmup 1 or more".into(),
        );
    }

    let report = RunReport {
        schema_version: 1,
        started_at_unix_ms,
        wall_clock_secs: wall_clock,
        manifest_path: config.manifest_path.display().to_string(),
        manifest_metadata_name: metadata_name,
        config: ConfigBlock {
            utterances: config.utterances,
            warmup: config.warmup,
            realtime_pace: config.realtime_pace,
            single_shot: config.single_shot,
            output_kind: config.output_kind,
            response_timeout_secs: config.response_timeout_secs,
            inputs: config
                .inputs
                .iter()
                .map(|p| p.display().to_string())
                .collect(),
            perf_tap_enabled: perf_tap,
            perf_window_ms,
        },
        host: HostBlock {
            os: std::env::consts::OS.to_string(),
            arch: std::env::consts::ARCH.to_string(),
            cpu_logical: std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(0),
        },
        gpu,
        utterances: measurements,
        end_to_end,
        node_order: node_order.clone(),
        per_node,
        notes,
        conversational: None,
    };

    Ok(report)
}

// ─── Audio prep ─────────────────────────────────────────────────────────

struct PreparedUtterance {
    label: String,
    /// `Audio` for WAV inputs; `Text` for prompt files (`.txt`).
    payload: PreparedPayload,
    /// Wall-clock duration of the audio (audio inputs only); for text
    /// inputs this is 0 — there's nothing to "play back".
    duration_secs: f64,
}

enum PreparedPayload {
    /// Mono f32 samples at 48 kHz, ready to chunk and push.
    Audio(Vec<f32>),
    /// UTF-8 prompt text. Pushed as a single `RuntimeData::Text` frame.
    Text(String),
}

fn prepare_inputs(paths: &[PathBuf]) -> Result<Vec<PreparedUtterance>> {
    if paths.is_empty() {
        anyhow::bail!("at least one --input (.wav or .txt) is required");
    }
    let mut out = Vec::with_capacity(paths.len());
    for p in paths {
        let ext = p
            .extension()
            .and_then(|s| s.to_str())
            .map(str::to_ascii_lowercase)
            .unwrap_or_default();
        if ext == "txt" || ext == "md" || ext == "prompt" {
            // Text-input utterance (TTS mode). One file = one prompt.
            let text = std::fs::read_to_string(p)
                .with_context(|| format!("read text prompt: {}", p.display()))?;
            let text = text.trim().to_string();
            if text.is_empty() {
                anyhow::bail!("text input is empty: {}", p.display());
            }
            out.push(PreparedUtterance {
                label: p.display().to_string(),
                payload: PreparedPayload::Text(text),
                duration_secs: 0.0,
            });
            continue;
        }
        let bytes = std::fs::read(p).with_context(|| format!("read wav: {}", p.display()))?;
        let (mut samples, sr, ch) =
            parse_wav(&bytes).map_err(|e| anyhow::anyhow!("parse wav {}: {}", p.display(), e))?;
        // Downmix to mono if needed (simple average).
        if ch > 1 {
            samples = downmix_to_mono(&samples, ch as usize);
        }
        // Resample to TARGET_SR with rubato's sinc-windowed resampler.
        // Originally this used a linear interpolator on the assumption
        // that the manifest's FastResampleNode would clean up any
        // aliasing — empirically that's wrong: 44.1 → 48 (linear) → 16
        // (sinc) compounds enough aliasing on speech to make
        // downstream audio LLMs misclassify the content. A single
        // sinc-windowed pre-stage costs ~ms per second of audio and
        // preserves the signal.
        if sr != TARGET_SR {
            samples = sinc_resample_mono(&samples, sr, TARGET_SR)
                .with_context(|| format!("resample {} -> {}", sr, TARGET_SR))?;
        }
        let duration_secs = samples.len() as f64 / TARGET_SR as f64;
        out.push(PreparedUtterance {
            label: p.display().to_string(),
            payload: PreparedPayload::Audio(samples),
            duration_secs,
        });
    }
    Ok(out)
}

fn downmix_to_mono(interleaved: &[f32], channels: usize) -> Vec<f32> {
    let frames = interleaved.len() / channels;
    let mut out = Vec::with_capacity(frames);
    for f in 0..frames {
        let base = f * channels;
        let mut acc = 0.0_f32;
        for c in 0..channels {
            acc += interleaved[base + c];
        }
        out.push(acc / channels as f32);
    }
    out
}

/// High-quality offline mono resample using rubato's sinc-windowed
/// interpolator. Designed for the bench's input pre-stage where each
/// utterance wav is processed once at load time; not on the hot path.
///
/// Implementation notes:
/// * `SincFixedIn` wants fixed-size input chunks. We feed it the audio
///   in `CHUNK_SIZE`-sample blocks and zero-pad the final tail block so
///   the resampler can emit the trailing samples.
/// * Output is trimmed to the expected length (`input.len() * ratio`)
///   so the zero-padded tail doesn't appear in the final stream.
/// * Parameters mirror `FastResampleNode` Medium quality
///   (sinc_len=128, oversampling=256, BlackmanHarris2 window) — the
///   same constants the runtime uses for its real-time resampler.
fn sinc_resample_mono(input: &[f32], src_sr: u32, dst_sr: u32) -> anyhow::Result<Vec<f32>> {
    if src_sr == dst_sr || input.is_empty() {
        return Ok(input.to_vec());
    }
    use rubato::{
        Resampler as RubatoResampler, SincFixedIn, SincInterpolationParameters,
        SincInterpolationType, WindowFunction,
    };

    const CHUNK_SIZE: usize = 1024;
    let ratio = dst_sr as f64 / src_sr as f64;

    let params = SincInterpolationParameters {
        sinc_len: 128,
        f_cutoff: 0.95,
        interpolation: SincInterpolationType::Linear,
        oversampling_factor: 256,
        window: WindowFunction::BlackmanHarris2,
    };

    let mut resampler = SincFixedIn::<f32>::new(ratio, 1.0, params, CHUNK_SIZE, 1)
        .map_err(|e| anyhow::anyhow!("rubato init: {e}"))?;

    let expected_out = ((input.len() as f64) * ratio).round() as usize;
    let mut out: Vec<f32> = Vec::with_capacity(expected_out + CHUNK_SIZE);

    let mut pos = 0;
    while pos < input.len() {
        let end = (pos + CHUNK_SIZE).min(input.len());
        let chunk = if end - pos == CHUNK_SIZE {
            input[pos..end].to_vec()
        } else {
            // Final short chunk — zero-pad to CHUNK_SIZE.
            let mut padded = vec![0.0_f32; CHUNK_SIZE];
            padded[..end - pos].copy_from_slice(&input[pos..end]);
            padded
        };
        let frames_in = [chunk];
        let resampled = resampler
            .process(&frames_in, None)
            .map_err(|e| anyhow::anyhow!("rubato process: {e}"))?;
        out.extend_from_slice(&resampled[0]);
        pos = end;
    }

    // Trim trailing zero-padded tail. The amount to keep is just the
    // ratio-scaled count of real input samples.
    out.truncate(expected_out);
    Ok(out)
}

// ─── Per-utterance run ──────────────────────────────────────────────────

/// Bundle the per-utterance measurement with the receivers and capture
/// handed back from the spawned recv task. The caller re-binds these to
/// reuse them for the next utterance.
struct UtteranceRunOutcome {
    measurement: UtteranceMeasurement,
    audio_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    data_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    video_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    capture: Option<UtteranceCapture>,
}

/// Internal return type of the spawned recv task — owns the receivers
/// and capture for the duration of one utterance, then hands them back
/// for the next.
struct RecvTaskOutput {
    first_emit: Option<Instant>,
    first_emit_kind: Option<&'static str>,
    first_audio_emit: Option<Instant>,
    first_text_emit: Option<Instant>,
    last_emit: Option<Instant>,
    tts_samples_total: usize,
    tts_frames: usize,
    tts_sample_rate: u32,
    text_frames: usize,
    text_chars: usize,
    text_first_payload: Option<String>,
    audio_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    data_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    video_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    capture: Option<UtteranceCapture>,
}

#[allow(clippy::too_many_arguments)]
async fn run_one_utterance(
    session: &remotemedia_core::transport::SessionHandle,
    audio_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    data_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    video_rx: tokio::sync::mpsc::Receiver<RuntimeData>,
    capture: Option<UtteranceCapture>,
    prep: &PreparedUtterance,
    realtime_pace: bool,
    single_shot: bool,
    output_kind: BenchOutput,
    response_timeout: Duration,
    idx: usize,
    is_warmup: bool,
) -> Result<UtteranceRunOutcome> {
    let push_start = Instant::now();
    // 10 ms cadence at 48 kHz. The router/source nodes will buffer
    // and resample; pacing at the *capture* rate matches what a mic
    // would feed in real-world conditions.
    let chunk_dur = Duration::from_micros((CHUNK_SAMPLES as u64 * 1_000_000) / TARGET_SR as u64);

    // VAD needs to *see silence* to fire `is_speech_end`. The avatar
    // manifest sets `min_silence_duration_ms=500` + `speech_pad_ms=150`,
    // so we append 1 s of silence after the speech samples. Without
    // this, VAD stays "in speech" forever, the coordinator never
    // transitions out of UserSpeaking, and all LLM text is silently
    // dropped — every utterance times out.
    const TRAILING_SILENCE_SECS: usize = 1;

    // Push and receive run on INDEPENDENT tokio tasks. An earlier version
    // used `tokio::try_join!(push_fut, recv_fut)`, which polls both
    // futures inside the same task — they share one executor slot. On
    // alternate utterances this caused a 2–3 s TTFA p95 spike: even
    // though the model emitted on time (per `lfm2_audio.total_ms` perf),
    // the recv side wasn't woken until push finally yielded. Spawning
    // recv on its own task gives the scheduler freedom to wake it on
    // any worker the instant a frame lands in `audio_rx`.
    let push_fut = async {
        let mut eos: Option<Instant> = None;
        match &prep.payload {
            PreparedPayload::Audio(samples) if single_shot => {
                let data = RuntimeData::Audio {
                    samples: AudioSamples::from(samples.clone()),
                    sample_rate: TARGET_SR,
                    channels: 1,
                    stream_id: None,
                    timestamp_us: Some(0),
                    arrival_ts_us: None,
                    metadata: None,
                };
                session
                    .send_input(TransportData::new(data))
                    .await
                    .map_err(|e| anyhow::anyhow!("send_input(single_shot): {}", e))?;
                eos = Some(Instant::now());
            }
            PreparedPayload::Audio(samples) => {
                let trailing_silence_samples = TRAILING_SILENCE_SECS * TARGET_SR as usize;
                let total_samples = samples.len() + trailing_silence_samples;
                let mut chunk_idx = 0usize;
                while chunk_idx * CHUNK_SAMPLES < total_samples {
                    let start = chunk_idx * CHUNK_SAMPLES;
                    let end = (start + CHUNK_SAMPLES).min(total_samples);
                    // Mark EOS at the boundary where speech ends and silence
                    // begins — that's the user-perceived "I stopped
                    // speaking" moment, the reference point for TTFA. We
                    // continue pushing silence after so VAD detects the
                    // end-of-speech transition.
                    if eos.is_none() && start >= samples.len() {
                        eos = Some(Instant::now());
                    }
                    let mut chunk: Vec<f32> = Vec::with_capacity(end - start);
                    for i in start..end {
                        chunk.push(samples.get(i).copied().unwrap_or(0.0));
                    }
                    let data = RuntimeData::Audio {
                        samples: AudioSamples::from(chunk),
                        sample_rate: TARGET_SR,
                        channels: 1,
                        stream_id: None,
                        timestamp_us: Some(((start as u64) * 1_000_000) / TARGET_SR as u64),
                        arrival_ts_us: None,
                        metadata: None,
                    };
                    session
                        .send_input(TransportData::new(data))
                        .await
                        .map_err(|e| anyhow::anyhow!("send_input: {}", e))?;

                    if realtime_pace {
                        let expected_elapsed = chunk_dur * (chunk_idx as u32 + 1);
                        let actual = push_start.elapsed();
                        if expected_elapsed > actual {
                            tokio::time::sleep(expected_elapsed - actual).await;
                        }
                    }
                    chunk_idx += 1;
                }
            }
            PreparedPayload::Text(prompt) => {
                let data = RuntimeData::Text(prompt.clone());
                session
                    .send_input(TransportData::new(data))
                    .await
                    .map_err(|e| anyhow::anyhow!("send_input(text): {}", e))?;
                eos = Some(Instant::now());
            }
        }
        let push_secs = push_start.elapsed().as_secs_f64();
        // Fallback (shouldn't happen given the branches above always set it).
        let eos = eos.unwrap_or_else(Instant::now);
        Ok::<(Instant, f64), anyhow::Error>((eos, push_secs))
    };

    // Wait for the first output frame on EITHER the audio or data
    // (text/JSON) channel. Different LFM2-Audio modes emit on different
    // channels:
    //   - Interleaved / TTS  → audio output (audio_rx)
    //   - ASR                → text output (data_rx)
    // We watch both and record whichever arrives first. End of response
    // is declared when we go `silence_window` with no new frame of any
    // kind. Counters are tracked per-channel so the summary can show
    // both audio frames and text chunks.
    //
    // Spawned as its own task so the scheduler can wake it on any
    // worker the moment a frame arrives, independent of push's progress
    // (see comment on push_fut above).
    let recv_handle: tokio::task::JoinHandle<RecvTaskOutput> = tokio::spawn(async move {
        let mut audio_rx = audio_rx;
        let mut data_rx = data_rx;
        let mut video_rx = video_rx;
        let mut capture = capture;

        let silence_window = Duration::from_millis(800);
        let mut first_emit: Option<Instant> = None;
        let mut first_emit_kind: Option<&'static str> = None;
        let mut first_audio_emit: Option<Instant> = None;
        let mut first_text_emit: Option<Instant> = None;
        let mut last_emit: Option<Instant> = None;
        let mut tts_samples_total: usize = 0;
        let mut tts_frames: usize = 0;
        let mut tts_sample_rate: u32 = 0;
        let mut text_frames: usize = 0;
        let mut text_chars: usize = 0;
        let mut text_first_payload: Option<String> = None;
        let deadline = Instant::now() + response_timeout;

        loop {
            let sleep_until = match last_emit {
                Some(t) => t + silence_window,
                None => deadline,
            }
            .min(deadline);
            let now_at_top = Instant::now();
            if now_at_top >= sleep_until {
                break;
            }
            let sleep_for = sleep_until - now_at_top;

            tokio::select! {
                biased;
                rd = audio_rx.recv() => {
                    let Some(rd) = rd else { break; };
                    if let RuntimeData::Audio {
                        samples,
                        sample_rate,
                        ..
                    } = &rd
                    {
                        let now = Instant::now();
                        if first_audio_emit.is_none() {
                            first_audio_emit = Some(now);
                        }
                        if matches!(output_kind, BenchOutput::Audio) {
                            if first_emit.is_none() {
                                first_emit = Some(now);
                                first_emit_kind = Some("audio");
                            }
                            last_emit = Some(now);
                        }
                        tts_samples_total += samples.len();
                        tts_frames += 1;
                        tts_sample_rate = *sample_rate;
                    }
                    if let Some(c) = capture.as_mut() {
                        c.record(&rd);
                    }
                }
                rd = data_rx.recv() => {
                    let Some(rd) = rd else { break; };
                    if let RuntimeData::Text(text) = &rd {
                        let now = Instant::now();
                        if first_text_emit.is_none() {
                            first_text_emit = Some(now);
                        }
                        if matches!(output_kind, BenchOutput::Data) {
                            if first_emit.is_none() {
                                first_emit = Some(now);
                                first_emit_kind = Some("text");
                            }
                            last_emit = Some(now);
                        }
                        if text_first_payload.is_none() {
                            text_first_payload = Some(text.clone());
                        }
                        text_chars += text.chars().count();
                        text_frames += 1;
                    }
                    if let Some(c) = capture.as_mut() {
                        c.record(&rd);
                    }
                }
                rd = video_rx.recv() => {
                    let Some(rd) = rd else { break; };
                    if let Some(c) = capture.as_mut() {
                        c.record(&rd);
                    }
                }
                _ = tokio::time::sleep(sleep_for) => {
                    // No event before the silence window expired or the
                    // overall deadline was reached. The next loop iteration
                    // will break out via the `if now_at_top >= sleep_until`
                    // check at the top.
                }
            }
        }

        RecvTaskOutput {
            first_emit,
            first_emit_kind,
            first_audio_emit,
            first_text_emit,
            last_emit,
            tts_samples_total,
            tts_frames,
            tts_sample_rate,
            text_frames,
            text_chars,
            text_first_payload,
            audio_rx,
            data_rx,
            video_rx,
            capture,
        }
    });

    let (eos, push_secs) = push_fut.await?;
    let recv = recv_handle
        .await
        .map_err(|e| anyhow::anyhow!("recv task join failed: {}", e))?;
    let RecvTaskOutput {
        first_emit,
        first_emit_kind,
        first_audio_emit,
        first_text_emit,
        last_emit,
        tts_samples_total,
        tts_frames,
        tts_sample_rate,
        text_frames,
        text_chars,
        text_first_payload,
        audio_rx,
        data_rx,
        video_rx,
        capture,
    } = recv;

    let timed_out = first_emit.is_none();
    let eos_to_first = first_emit.map(|t| t.duration_since(eos).as_secs_f64());
    let eos_to_last = last_emit.map(|t| t.duration_since(eos).as_secs_f64());
    let tts_audio_secs = if tts_sample_rate > 0 {
        tts_samples_total as f64 / tts_sample_rate as f64
    } else {
        0.0
    };

    let kind_label = first_emit_kind.unwrap_or("none");
    if let Some(s) = eos_to_first {
        eprintln!(
            "[bench]   utt {:>3} first_emit={kind_label} ttfx={:.0}ms response_dur={:.2}s \
             audio={:.2}s/{frames}f text={tchars}c/{tframes}f",
            idx + 1,
            s * 1000.0,
            eos_to_last.unwrap_or(0.0),
            tts_audio_secs,
            frames = tts_frames,
            tchars = text_chars,
            tframes = text_frames,
        );
    } else {
        eprintln!(
            "[bench]   utt {:>3} TIMEOUT (>{:.0}s)",
            idx + 1,
            response_timeout.as_secs_f32(),
        );
    }

    // Backward-compat: keep eos_to_first_tts_secs set only when first
    // emit was audio so existing report consumers continue to work.
    let (eos_to_first_tts, eos_to_last_tts) = match first_emit_kind {
        Some("audio") => (eos_to_first, eos_to_last),
        _ => (None, None),
    };

    let eos_to_first_audio_emit_secs =
        first_audio_emit.map(|t| t.duration_since(eos).as_secs_f64());
    let eos_to_first_text_emit_secs = first_text_emit.map(|t| t.duration_since(eos).as_secs_f64());

    Ok(UtteranceRunOutcome {
        measurement: UtteranceMeasurement {
            idx,
            is_warmup,
            source_wav: prep.label.clone(),
            audio_duration_secs: prep.duration_secs,
            push_secs,
            eos_to_first_emit_secs: eos_to_first,
            eos_to_last_emit_secs: eos_to_last,
            first_emit_kind: first_emit_kind.map(|s| s.to_string()),
            eos_to_first_audio_emit_secs,
            eos_to_first_text_emit_secs,
            eos_to_first_tts_secs: eos_to_first_tts,
            eos_to_last_tts_secs: eos_to_last_tts,
            tts_audio_secs,
            tts_frames,
            text_frames,
            text_chars,
            text_first_payload,
            timed_out,
        },
        audio_rx,
        data_rx,
        video_rx,
        capture,
    })
}

// ─── Stats / utilities ──────────────────────────────────────────────────

fn compute_e2e_stats(measured: &[&UtteranceMeasurement], wall_clock_secs: f64) -> EndToEndStats {
    if measured.is_empty() {
        return EndToEndStats {
            measured_utterances: 0,
            ..Default::default()
        };
    }
    // Unified first-emit numbers (any modality)
    let mut emit: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_first_emit_secs)
        .collect();
    let mut last_emit: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_last_emit_secs)
        .collect();
    emit.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    last_emit.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    // Audio-only legacy view
    let mut ttfa: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_first_tts_secs)
        .collect();
    let mut ttla: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_last_tts_secs)
        .collect();
    ttfa.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    ttla.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    let mut kind_audio = 0usize;
    let mut kind_text = 0usize;
    let mut kind_none = 0usize;
    for m in measured {
        match m.first_emit_kind.as_deref() {
            Some("audio") => kind_audio += 1,
            Some("text") => kind_text += 1,
            _ => kind_none += 1,
        }
    }

    let mut audio_emit: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_first_audio_emit_secs)
        .collect();
    let mut text_emit: Vec<f64> = measured
        .iter()
        .filter_map(|m| m.eos_to_first_text_emit_secs)
        .collect();
    audio_emit.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    text_emit.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    let audio_in_secs: f64 = measured.iter().map(|m| m.audio_duration_secs).sum();
    let audio_out_secs: f64 = measured.iter().map(|m| m.tts_audio_secs).sum();

    EndToEndStats {
        measured_utterances: measured.len(),
        eos_to_first_emit_p50_ms: percentile_ms(&emit, 0.50),
        eos_to_first_emit_p95_ms: percentile_ms(&emit, 0.95),
        eos_to_first_emit_p99_ms: percentile_ms(&emit, 0.99),
        eos_to_first_emit_min_ms: emit.first().copied().map(|v| v * 1000.0),
        eos_to_first_emit_max_ms: emit.last().copied().map(|v| v * 1000.0),
        eos_to_last_emit_p50_ms: percentile_ms(&last_emit, 0.50),
        eos_to_last_emit_p95_ms: percentile_ms(&last_emit, 0.95),
        first_emit_kind_audio: kind_audio,
        first_emit_kind_text: kind_text,
        first_emit_kind_none: kind_none,
        eos_to_first_audio_p50_ms: percentile_ms(&audio_emit, 0.50),
        eos_to_first_audio_p95_ms: percentile_ms(&audio_emit, 0.95),
        eos_to_first_audio_p99_ms: percentile_ms(&audio_emit, 0.99),
        eos_to_first_text_p50_ms: percentile_ms(&text_emit, 0.50),
        eos_to_first_text_p95_ms: percentile_ms(&text_emit, 0.95),
        eos_to_first_text_p99_ms: percentile_ms(&text_emit, 0.99),
        eos_to_first_tts_p50_ms: percentile_ms(&ttfa, 0.50),
        eos_to_first_tts_p95_ms: percentile_ms(&ttfa, 0.95),
        eos_to_first_tts_p99_ms: percentile_ms(&ttfa, 0.99),
        eos_to_first_tts_min_ms: ttfa.first().copied().map(|v| v * 1000.0),
        eos_to_first_tts_max_ms: ttfa.last().copied().map(|v| v * 1000.0),
        eos_to_last_tts_p50_ms: percentile_ms(&ttla, 0.50),
        eos_to_last_tts_p95_ms: percentile_ms(&ttla, 0.95),
        response_audio_secs_per_wall_clock: if wall_clock_secs > 0.0 {
            Some(audio_out_secs / wall_clock_secs)
        } else {
            None
        },
        audio_in_secs_per_wall_clock: if wall_clock_secs > 0.0 {
            Some(audio_in_secs / wall_clock_secs)
        } else {
            None
        },
    }
}

fn percentile_ms(sorted_secs: &[f64], q: f64) -> Option<f64> {
    if sorted_secs.is_empty() {
        return None;
    }
    let idx = ((sorted_secs.len() as f64 - 1.0) * q).round() as usize;
    Some(sorted_secs[idx] * 1000.0)
}

fn sample_gpu_info() -> Vec<GpuInfo> {
    use std::process::Command;
    let out = match Command::new("nvidia-smi")
        .args([
            "--query-gpu=name,memory.total,memory.used,utilization.gpu",
            "--format=csv,noheader,nounits",
        ])
        .output()
    {
        Ok(o) if o.status.success() => o.stdout,
        _ => return Vec::new(),
    };
    let text = String::from_utf8_lossy(&out);
    let mut gpus = Vec::new();
    for line in text.lines() {
        let parts: Vec<&str> = line.split(',').map(|s| s.trim()).collect();
        if parts.len() < 4 {
            continue;
        }
        gpus.push(GpuInfo {
            name: parts[0].to_string(),
            memory_total_mib: parts[1].parse().unwrap_or(0),
            memory_used_mib: parts[2].parse().unwrap_or(0),
            utilization_pct: parts[3].parse().unwrap_or(0),
        });
    }
    gpus
}

pub fn write_report(path: impl AsRef<std::path::Path>, report: &RunReport) -> Result<()> {
    let path = path.as_ref();
    let json = serde_json::to_string_pretty(report)?;
    std::fs::write(path, &json)
        .with_context(|| format!("Failed to write report: {}", path.display()))?;
    Ok(())
}

pub fn print_summary(r: &RunReport) {
    let snapshot = serde_json::from_value::<PerfSnapshot>(r.per_node.clone()).ok();
    let e = &r.end_to_end;
    println!("\n┌─ bench summary ──────────────────────────────────────────");
    println!("│ manifest       : {}", r.manifest_path);
    println!(
        "│ utts (measured): {} / {}",
        e.measured_utterances, r.config.utterances
    );
    println!("│ wall clock     : {:.2}s", r.wall_clock_secs);
    // Pick the right label based on which channel utterances emitted on
    // first. Pure ASR = all text. Pure interleaved/TTS = all audio.
    let label = if e.first_emit_kind_text > 0 && e.first_emit_kind_audio == 0 {
        "TTFT (text)    "
    } else if e.first_emit_kind_audio > 0 && e.first_emit_kind_text == 0 {
        "TTFA           "
    } else {
        "TTFx (mixed)   "
    };
    if let (Some(p50), Some(p95), Some(p99)) = (
        e.eos_to_first_emit_p50_ms,
        e.eos_to_first_emit_p95_ms,
        e.eos_to_first_emit_p99_ms,
    ) {
        println!(
            "│ {label} : p50={:.0}ms  p95={:.0}ms  p99={:.0}ms",
            p50, p95, p99
        );
        if e.first_emit_kind_text > 0 || e.first_emit_kind_none > 0 {
            println!(
                "│ first-emit kind: audio={} text={} none={}",
                e.first_emit_kind_audio, e.first_emit_kind_text, e.first_emit_kind_none
            );
        }
    } else {
        println!("│ {label} : (no measured utterances)");
    }
    // Per-channel breakdown — shown only when both channels emitted at
    // least once. Useful for TTS (audio first frame is the real TTFA
    // even when leading text precedes it) and interleaved.
    if let (Some(p50), Some(p95), Some(p99)) = (
        e.eos_to_first_audio_p50_ms,
        e.eos_to_first_audio_p95_ms,
        e.eos_to_first_audio_p99_ms,
    ) {
        println!(
            "│ TTFA  (audio) : p50={:.0}ms  p95={:.0}ms  p99={:.0}ms",
            p50, p95, p99
        );
    }
    if let (Some(p50), Some(p95), Some(p99)) = (
        e.eos_to_first_text_p50_ms,
        e.eos_to_first_text_p95_ms,
        e.eos_to_first_text_p99_ms,
    ) {
        println!(
            "│ TTFT  (text)  : p50={:.0}ms  p95={:.0}ms  p99={:.0}ms",
            p50, p95, p99
        );
    }
    if let Some(rtf_out) = e.response_audio_secs_per_wall_clock {
        println!("│ TTS audio RTF  : {:.2}× wall-clock", rtf_out);
    }
    if let Some(rtf_in) = e.audio_in_secs_per_wall_clock {
        println!("│ Input audio RTF: {:.2}× wall-clock", rtf_in);
    }
    if !r.gpu.is_empty() {
        for (i, g) in r.gpu.iter().enumerate() {
            println!(
                "│ gpu[{}]         : {}  {} MiB / {} MiB  util {}%",
                i, g.name, g.memory_used_mib, g.memory_total_mib, g.utilization_pct
            );
        }
    }
    print_per_node_breakdown(snapshot.as_ref(), &r.node_order);
    for note in &r.notes {
        println!("│ note           : {}", note);
    }
    println!("└──────────────────────────────────────────────────────────");
}

/// Render a per-node `first_output_latency` table from the merged HDR
/// snapshot. Rows are emitted in manifest declaration order so the
/// reader can scan top-to-bottom along the pipeline — the highest-cost
/// row is the stage that owns TTFA.
fn print_per_node_breakdown(snapshot: Option<&PerfSnapshot>, node_order: &[String]) {
    let Some(snap) = snapshot else { return };
    if snap.nodes.is_empty() {
        return;
    }
    println!("│");
    println!("│ per-node first-emit latency (input arrival → first emit, merged):");
    println!(
        "│   {:<22} {:>11} {:>11} {:>11} {:>8} {:>8}",
        "node", "p50", "p95", "p99", "inputs", "outputs",
    );

    // Walk in manifest order first; append any unseen node_ids after.
    let mut ids: Vec<String> = node_order
        .iter()
        .filter(|id| snap.nodes.contains_key(*id))
        .cloned()
        .collect();
    for id in snap.nodes.keys() {
        if !ids.contains(id) {
            ids.push(id.clone());
        }
    }

    let mut sum_p50_us: u64 = 0;
    for id in &ids {
        let Some(ns) = snap.nodes.get(id) else {
            continue;
        };
        let f = &ns.first_output_latency_us;
        sum_p50_us = sum_p50_us.saturating_add(f.p50_us);
        println!(
            "│   {:<22} {:>11} {:>11} {:>11} {:>8} {:>8}",
            truncate(id, 22),
            fmt_latency(f.p50_us),
            fmt_latency(f.p95_us),
            fmt_latency(f.p99_us),
            ns.inputs,
            ns.outputs,
        );
    }
    // Sum-of-p50s isn't the real critical-path latency (nodes can
    // overlap), but it's a useful upper bound and immediately exposes
    // a stage that's eating most of TTFA.
    println!(
        "│   {:<22} {:>11}  (Σ of first-emit p50s; non-pipelined upper bound)",
        "Σ stages",
        fmt_latency(sum_p50_us),
    );
}

/// Render a latency value with a unit suffix that matches its
/// magnitude. Sub-millisecond values are shown in microseconds (so
/// fast-path Rust nodes like the chunker don't all read as `0.0`),
/// the millisecond range gets one decimal, and the second range gets
/// two. Keeps the column width stable for table alignment.
fn fmt_latency(us: u64) -> String {
    if us < 1_000 {
        format!("{} us", us)
    } else if us < 1_000_000 {
        format!("{:.1} ms", (us as f64) / 1_000.0)
    } else {
        format!("{:.2} s", (us as f64) / 1_000_000.0)
    }
}

/// UTF-8-safe truncate. Used to keep the per-node table column-aligned
/// even when a manifest uses very long node ids.
fn truncate(s: &str, n: usize) -> String {
    if s.chars().count() <= n {
        s.to_string()
    } else {
        let mut t: String = s.chars().take(n.saturating_sub(1)).collect();
        t.push('…');
        t
    }
}

// ── Conversational benchmark runner ──────────────────────────────────────

/// Run a multi-turn conversational benchmark from a scenario file.
///
/// Loads the scenario JSON, resolves the manifest, creates a single
/// session, and drives each turn sequentially. For barge-in turns,
/// the input WAV is pushed while the previous turn's agent response
/// is still emitting — the pipeline's VAD detects the overlap and
/// the coordinator handles the interruption.
pub async fn run_conversational_benchmark(
    executor: Arc<PipelineExecutor>,
    scenario_path: PathBuf,
    config: BenchConfig,
) -> Result<RunReport> {
    use std::path::Path;

    let perf_tap = std::env::var("REMOTEMEDIA_PERF_TAP").ok().is_some();
    let perf_window_ms: u32 = std::env::var("REMOTEMEDIA_PERF_WINDOW_MS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(1000);

    if !perf_tap {
        eprintln!(
            "[bench] WARNING: REMOTEMEDIA_PERF_TAP is not set — per-node \
             percentiles will not be collected."
        );
    }

    let started_at_unix_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    // ── Load scenario ────────────────────────────────────────────────────
    let scenario_content = std::fs::read_to_string(&scenario_path)
        .with_context(|| format!("Failed to read scenario: {}", scenario_path.display()))?;
    let scenario: ConversationalScenario =
        serde_json::from_str(&scenario_content).context("Parse scenario JSON")?;

    // Resolve manifest path relative to scenario file location
    let scenario_dir = scenario_path
        .parent()
        .map(Path::to_path_buf)
        .unwrap_or_default();
    let manifest_path = if scenario.manifest.is_absolute() {
        scenario.manifest.clone()
    } else {
        scenario_dir.join(&scenario.manifest)
    };

    let manifest_content = std::fs::read_to_string(&manifest_path)
        .with_context(|| format!("Failed to read manifest: {}", manifest_path.display()))?;
    // Parse manifest using the same path as the CLI does
    let manifest: Manifest =
        serde_json::from_str(&manifest_content).context("Parse manifest JSON")?;

    let metadata_name = Some(manifest.metadata.name.clone());
    let node_order: Vec<String> = manifest.nodes.iter().map(|n| n.id.clone()).collect();
    let manifest = Arc::new(manifest);

    eprintln!(
        "[bench] scenario: {} ({} turns) manifest: {} ({} nodes, {} connections)",
        scenario.scenario,
        scenario.turns.len(),
        manifest_path.display(),
        manifest.nodes.len(),
        manifest.connections.len()
    );

    // ── Prewarm ──────────────────────────────────────────────────────────
    let _pool_keepalive = if config.prewarm {
        eprintln!(
            "[bench] prewarming pipeline (loads models — may take 30-60s for cold caches)..."
        );
        let prewarm_t0 = Instant::now();
        let pool = WarmSessionPool::new(executor.clone());
        match pool.prewarm(manifest.clone()).await {
            Ok(()) => {
                executor.set_default_pool(pool.clone());
                eprintln!(
                    "[bench] prewarm complete in {:.2}s",
                    prewarm_t0.elapsed().as_secs_f32()
                );
                Some(pool)
            }
            Err(e) => {
                eprintln!("[bench] ERROR during prewarm: {}", e);
                return Err(anyhow::anyhow!("WarmSessionPool::prewarm failed: {}", e));
            }
        }
    } else {
        None
    };

    // ── Create session ───────────────────────────────────────────────────
    let session_t0 = Instant::now();
    let mut session = executor
        .create_session(manifest.clone())
        .await
        .map_err(|e| anyhow::anyhow!("create_session failed: {}", e))?;
    eprintln!(
        "[bench] session acquired (warm) in {:.2}s (id={})",
        session_t0.elapsed().as_secs_f32(),
        session.session_id
    );

    let perf_agg = session.perf_aggregator().cloned();
    let outputs = session
        .take_output_receivers()
        .ok_or_else(|| anyhow::anyhow!("output receivers already taken"))?;
    let mut audio_rx = outputs.audio_rx;
    let mut data_rx = outputs.data_rx;
    let mut video_rx = outputs.video_rx;

    // ── Preload all turn WAVs ────────────────────────────────────────────
    let mut turn_samples: Vec<Vec<f32>> = Vec::with_capacity(scenario.turns.len());
    for (i, turn) in scenario.turns.iter().enumerate() {
        let wav_path = if turn.input.is_absolute() {
            turn.input.clone()
        } else {
            scenario_dir.join(&turn.input)
        };
        let bytes = std::fs::read(&wav_path)
            .with_context(|| format!("read wav for turn {}: {}", i, wav_path.display()))?;
        let (mut samples, sr, ch) = parse_wav(&bytes)
            .map_err(|e| anyhow::anyhow!("parse wav {}: {}", wav_path.display(), e))?;
        if ch > 1 {
            samples = downmix_to_mono(&samples, ch as usize);
        }
        if sr != TARGET_SR {
            samples = sinc_resample_mono(&samples, sr, TARGET_SR)
                .with_context(|| format!("resample {} -> {}", sr, TARGET_SR))?;
        }
        eprintln!(
            "[bench] turn {:>2}: {} type={:?} dur={:.2}s samples={}",
            i,
            wav_path.display(),
            turn.turn_type,
            samples.len() as f64 / TARGET_SR as f64,
            samples.len()
        );
        turn_samples.push(samples);
    }

    // ── Run turns ────────────────────────────────────────────────────────
    let bench_t0 = Instant::now();
    let mut turn_measurements: Vec<TurnMeasurement> = Vec::new();

    // Track the previous turn's first audio emit for barge-in trigger timing
    let mut prev_first_audio: Option<Instant> = None;
    // Track the current agent turn_id from coordinator turn_state events
    let mut _current_turn_id: Option<u64> = None;

    // Silence window to detect end of response (same as run_one_utterance)
    const SILENCE_WINDOW: Duration = Duration::from_millis(800);
    const TRAILING_SILENCE_SECS: usize = 1;
    let response_timeout = Duration::from_secs(config.response_timeout_secs);

    for (turn_idx, turn_def) in scenario.turns.iter().enumerate() {
        let samples = &turn_samples[turn_idx];
        let is_barge_in = turn_def.turn_type == TurnType::BargeIn;
        let trigger_at_ms = turn_def.trigger_at_ms.unwrap_or(1500);

        eprintln!(
            "[bench] turn {:>2}/{} type={:?} src={}",
            turn_idx + 1,
            scenario.turns.len(),
            turn_def.turn_type,
            turn_def.input.display()
        );

        // Drain receivers from previous turn
        while audio_rx.try_recv().is_ok() {}
        while data_rx.try_recv().is_ok() {}
        while video_rx.try_recv().is_ok() {}

        // For barge-in turns: wait for trigger condition before pushing audio
        let barge_push_start: Option<Instant> = if is_barge_in {
            if let Some(first_audio) = prev_first_audio {
                let trigger_delay = Duration::from_millis(trigger_at_ms);
                let trigger_time = first_audio + trigger_delay;
                let now = Instant::now();
                if now < trigger_time {
                    eprintln!(
                        "[bench]   barge-in: waiting {:.0}ms for trigger (first_audio was {:.0}s ago)",
                        trigger_delay.as_millis(),
                        now.duration_since(first_audio).as_secs_f64()
                    );
                    tokio::time::sleep(trigger_time - now).await;
                }
                let start = Instant::now();
                eprintln!(
                    "[bench]   barge-in: pushing audio at {:.0}ms after agent first audio",
                    start.duration_since(first_audio).as_millis()
                );
                Some(start)
            } else {
                eprintln!(
                    "[bench]   WARNING: barge-in turn {} but no previous first_audio — pushing immediately",
                    turn_idx
                );
                Some(Instant::now())
            }
        } else {
            None
        };

        // Record barge-in push time for detection latency
        let barge_push_instant = barge_push_start;

        // Push audio with trailing silence (same pattern as run_one_utterance)
        let push_start = Instant::now();
        let trailing_silence_samples = TRAILING_SILENCE_SECS * TARGET_SR as usize;
        let total_samples = samples.len() + trailing_silence_samples;
        let mut eos: Option<Instant> = None;

        for chunk_idx in 0.. {
            let start = chunk_idx * CHUNK_SAMPLES;
            if start >= total_samples {
                break;
            }
            let end = (start + CHUNK_SAMPLES).min(total_samples);

            // Mark EOS at speech/silence boundary
            if eos.is_none() && start >= samples.len() {
                eos = Some(Instant::now());
            }

            let mut chunk: Vec<f32> = Vec::with_capacity(end - start);
            for i in start..end {
                chunk.push(samples.get(i).copied().unwrap_or(0.0));
            }

            let data = RuntimeData::Audio {
                samples: AudioSamples::from(chunk),
                sample_rate: TARGET_SR,
                channels: 1,
                stream_id: None,
                timestamp_us: Some(((start as u64) * 1_000_000) / TARGET_SR as u64),
                arrival_ts_us: None,
                metadata: None,
            };
            session
                .send_input(TransportData::new(data))
                .await
                .map_err(|e| anyhow::anyhow!("send_input: {}", e))?;

            if config.realtime_pace {
                let chunk_dur =
                    Duration::from_micros((CHUNK_SAMPLES as u64 * 1_000_000) / TARGET_SR as u64);
                let expected_elapsed = chunk_dur * (chunk_idx as u32 + 1);
                let actual = push_start.elapsed();
                if expected_elapsed > actual {
                    tokio::time::sleep(expected_elapsed - actual).await;
                }
            }
        }

        let _push_secs = push_start.elapsed().as_secs_f64();
        let eos = eos.unwrap_or_else(Instant::now);

        // ── Receive response ─────────────────────────────────────────────
        // Read output until silence window expires or timeout
        let silence_window = SILENCE_WINDOW;
        let mut first_emit: Option<Instant> = None;
        let mut first_audio_emit: Option<Instant> = None;
        let mut last_emit: Option<Instant> = None;
        let mut _tts_samples_total: usize = 0;
        let mut _tts_sample_rate: u32 = 0;
        let deadline = Instant::now() + response_timeout;

        // Track coordinator turn_state events
        let mut turn_state_turn_id: Option<u64> = None;
        let mut turn_state_phase: Option<String> = None;
        let mut turn_state_cancelled: Option<u64> = None;
        let mut barge_detection_time: Option<Instant> = None;

        // For stale response detection: track if audio arrives after barge detection
        let mut stale_audio_after_barge: bool = false;

        loop {
            let sleep_until = match last_emit {
                Some(t) => t + silence_window,
                None => deadline,
            }
            .min(deadline);
            let now_at_top = Instant::now();
            if now_at_top >= sleep_until {
                break;
            }
            let sleep_for = sleep_until - now_at_top;

            tokio::select! {
                biased;
                rd = audio_rx.recv() => {
                    let Some(rd) = rd else { break; };
                    if let RuntimeData::Audio { samples, sample_rate, .. } = &rd {
                        let now = Instant::now();
                        if first_audio_emit.is_none() {
                            first_audio_emit = Some(now);
                        }
                        if first_emit.is_none() {
                            first_emit = Some(now);
                        }
                        last_emit = Some(now);
                        _tts_samples_total += samples.len();
                        _tts_sample_rate = *sample_rate;

                        // Stale response detection: if barge was detected and
                        // audio still arrives, it's from the old turn
                        if barge_detection_time.is_some() {
                            stale_audio_after_barge = true;
                        }
                    }
                }
                rd = data_rx.recv() => {
                    let Some(rd) = rd else { break; };
                    if let RuntimeData::Json(value) = &rd {
                        // Check for turn_state events from coordinator
                        if let Some(kind) = value.get("kind").and_then(|v| v.as_str()) {
                            if kind == "turn_state" {
                                let ts_now = Instant::now();
                                if let Some(tid) = value.get("turn_id").and_then(|v| v.as_u64()) {
                                    turn_state_turn_id = Some(tid);
                                    _current_turn_id = Some(tid);
                                }
                                if let Some(phase) = value.get("phase").and_then(|v| v.as_str()) {
                                    turn_state_phase = Some(phase.to_string());
                                }
                                if let Some(ctid) = value.get("cancelled_turn_id").and_then(|v| v.as_u64()) {
                                    turn_state_cancelled = Some(ctid);
                                }

                                // Barge-in detection: first turn_state with USER_SPEAKING
                                // phase after we pushed barge audio
                                if is_barge_in
                                    && barge_detection_time.is_none()
                                    && turn_state_phase.as_deref() == Some("USER_SPEAKING")
                                {
                                    barge_detection_time = Some(ts_now);
                                    eprintln!(
                                        "[bench]   barge-in detected: turn_id={} phase={}",
                                        turn_state_turn_id.unwrap_or(0),
                                        turn_state_phase.as_deref().unwrap_or("?")
                                    );
                                }
                            }
                        }
                    }
                    if let RuntimeData::Text(_) = &rd {
                        let now = Instant::now();
                        if first_emit.is_none() && config.output_kind == BenchOutput::Data {
                            first_emit = Some(now);
                        }
                    }
                }
                rd = video_rx.recv() => {
                    let _ = rd; // drain video
                }
                _ = tokio::time::sleep(sleep_for) => {
                    // Timeout — continue loop check
                }
            }
        }

        // ── Compute turn metrics ─────────────────────────────────────────
        let ttfa_secs = first_audio_emit
            .map(|t| t.duration_since(eos).as_secs_f64())
            .unwrap_or(0.0);
        let total_response_secs = last_emit
            .map(|t| t.duration_since(eos).as_secs_f64())
            .unwrap_or(0.0);

        let agent_turn_id = turn_state_turn_id
            .map(|id| id.to_string())
            .unwrap_or_else(|| format!("turn_{}", turn_idx));

        // Barge-in specific metrics
        let barge_in_detection_ms = if is_barge_in {
            if let (Some(detection), Some(push)) = (barge_detection_time, barge_push_instant) {
                Some(detection.duration_since(push).as_secs_f64() * 1000.0)
            } else {
                // Fallback: estimate from push to first new audio
                first_audio_emit.map(|t| {
                    let ref_time = barge_push_instant.unwrap_or(push_start);
                    t.duration_since(ref_time).as_secs_f64() * 1000.0
                })
            }
        } else {
            None
        };

        let cancellation_propagation_ms = if is_barge_in {
            // Time from barge detection to last audio from old turn ceasing
            // Approximate: time from detection to first audio of new response
            if let (Some(detection), Some(first)) = (barge_detection_time, first_audio_emit) {
                Some(first.duration_since(detection).as_secs_f64() * 1000.0)
            } else {
                None
            }
        } else {
            None
        };

        let recovery_ttfa_ms = if is_barge_in {
            // For barge-in, recovery TTFA is from the barge user's EOS to first audio
            Some(ttfa_secs * 1000.0)
        } else {
            None
        };

        let stale_response_suppressed = if is_barge_in {
            Some(!stale_audio_after_barge)
        } else {
            None
        };

        let interrupted_turn_id = if is_barge_in {
            turn_state_cancelled.map(|id| id.to_string())
        } else {
            None
        };

        let measurement = TurnMeasurement {
            turn_idx,
            turn_type: turn_def.turn_type,
            ttfa_ms: ttfa_secs * 1000.0,
            total_response_ms: total_response_secs * 1000.0,
            agent_turn_id,
            barge_in_detection_ms,
            cancellation_propagation_ms,
            recovery_ttfa_ms,
            stale_response_suppressed,
            interrupted_turn_id,
        };

        eprintln!(
            "[bench]   turn {:>2} ttfa={:.0}ms response={:.0}ms turn_id={} \
             barge_detect={:?} stale_suppressed={:?}",
            turn_idx + 1,
            measurement.ttfa_ms,
            measurement.total_response_ms,
            measurement.agent_turn_id,
            measurement
                .barge_in_detection_ms
                .map(|v| format!("{:.0}ms", v)),
            measurement.stale_response_suppressed
        );

        turn_measurements.push(measurement);

        // Update prev_first_audio for next turn's barge-in trigger
        prev_first_audio = first_audio_emit;
    }

    let wall_clock = bench_t0.elapsed().as_secs_f64();

    // ── Compute summary ──────────────────────────────────────────────────
    let normal_ttfa: Vec<f64> = turn_measurements
        .iter()
        .filter(|m| m.turn_type == TurnType::Normal)
        .map(|m| m.ttfa_ms)
        .collect();
    let barge_ttfa: Vec<f64> = turn_measurements
        .iter()
        .filter(|m| m.turn_type == TurnType::BargeIn)
        .map(|m| m.ttfa_ms)
        .collect();

    let _avg_normal = normal_ttfa.first().copied().unwrap_or(0.0);
    let _avg_barge = barge_ttfa.first().copied().unwrap_or(0.0);

    let avg_ttfa = if !turn_measurements.is_empty() {
        turn_measurements.iter().map(|m| m.ttfa_ms).sum::<f64>() / turn_measurements.len() as f64
    } else {
        0.0
    };

    let avg_barge_detection = {
        let detections: Vec<f64> = turn_measurements
            .iter()
            .filter_map(|m| m.barge_in_detection_ms)
            .collect();
        if detections.is_empty() {
            None
        } else {
            Some(detections.iter().sum::<f64>() / detections.len() as f64)
        }
    };

    let ttfa_regression_pct = if !normal_ttfa.is_empty() && !barge_ttfa.is_empty() {
        let avg_n = normal_ttfa.iter().sum::<f64>() / normal_ttfa.len() as f64;
        let avg_b = barge_ttfa.iter().sum::<f64>() / barge_ttfa.len() as f64;
        if avg_n > 0.0 {
            Some(((avg_b - avg_n) / avg_n) * 100.0)
        } else {
            None
        }
    } else {
        None
    };

    let barge_in_count = turn_measurements
        .iter()
        .filter(|m| m.turn_type == TurnType::BargeIn)
        .count();

    let summary = ConversationalSummary {
        total_turns: turn_measurements.len(),
        barge_in_count,
        avg_ttfa_ms: avg_ttfa,
        avg_barge_in_detection_ms: avg_barge_detection,
        ttfa_regression_pct,
    };

    let conversational = ConversationalBlock {
        scenario: scenario.scenario,
        turns: turn_measurements,
        summary,
    };

    // ── Pull perf snapshot ───────────────────────────────────────────────
    let perf_snapshot: Option<PerfSnapshot> = perf_agg.as_ref().map(|agg| agg.peek_snapshot());
    let per_node = perf_snapshot
        .as_ref()
        .map(|snap| serde_json::to_value(snap).unwrap_or(serde_json::Value::Null))
        .unwrap_or(serde_json::Value::Null);

    // ── Tear down ────────────────────────────────────────────────────────
    let _ = session.close().await;

    // ── Build report ─────────────────────────────────────────────────────
    let gpu = sample_gpu_info();

    let mut notes = Vec::new();
    if !perf_tap {
        notes.push("REMOTEMEDIA_PERF_TAP not set — per-node block is null".to_string());
    }
    if perf_tap && perf_window_ms < 60_000 {
        notes.push(format!(
            "REMOTEMEDIA_PERF_WINDOW_MS={perf_window_ms} is short; set 600000 for whole-run merged histograms"
        ));
    }
    if let Some(reg) = ttfa_regression_pct {
        if reg > 20.0 {
            notes.push(format!(
                "TTFA regression of {:.1}% between normal and barge-in turns — possible context overflow or GPU memory pressure",
                reg
            ));
        }
    }

    let report = RunReport {
        schema_version: 1,
        started_at_unix_ms,
        wall_clock_secs: wall_clock,
        manifest_path: manifest_path.display().to_string(),
        manifest_metadata_name: metadata_name,
        config: ConfigBlock {
            utterances: scenario.turns.len(),
            warmup: 0,
            realtime_pace: config.realtime_pace,
            single_shot: config.single_shot,
            output_kind: config.output_kind,
            response_timeout_secs: config.response_timeout_secs,
            inputs: scenario
                .turns
                .iter()
                .map(|t| t.input.display().to_string())
                .collect(),
            perf_tap_enabled: perf_tap,
            perf_window_ms,
        },
        host: HostBlock {
            os: std::env::consts::OS.to_string(),
            arch: std::env::consts::ARCH.to_string(),
            cpu_logical: std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(0),
        },
        gpu,
        utterances: Vec::new(), // Conversational mode uses conversational.turns instead
        end_to_end: EndToEndStats {
            measured_utterances: conversational.turns.len(),
            ..Default::default()
        },
        node_order,
        per_node,
        notes,
        conversational: Some(conversational),
    };

    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn measurement(
        idx: usize,
        is_warmup: bool,
        first_kind: Option<&str>,
        first_secs: Option<f64>,
        audio_first_secs: Option<f64>,
        text_first_secs: Option<f64>,
        timed_out: bool,
    ) -> UtteranceMeasurement {
        UtteranceMeasurement {
            idx,
            is_warmup,
            source_wav: "input.wav".to_string(),
            audio_duration_secs: 1.0,
            push_secs: 0.1,
            eos_to_first_emit_secs: first_secs,
            eos_to_last_emit_secs: first_secs.map(|v| v + 0.5),
            first_emit_kind: first_kind.map(str::to_string),
            eos_to_first_audio_emit_secs: audio_first_secs,
            eos_to_first_text_emit_secs: text_first_secs,
            eos_to_first_tts_secs: if matches!(first_kind, Some("audio")) {
                first_secs
            } else {
                None
            },
            eos_to_last_tts_secs: if matches!(first_kind, Some("audio")) {
                first_secs.map(|v| v + 0.5)
            } else {
                None
            },
            tts_audio_secs: 0.75,
            tts_frames: 3,
            text_frames: usize::from(matches!(first_kind, Some("text"))),
            text_chars: 0,
            text_first_payload: None,
            timed_out,
        }
    }

    #[test]
    fn percentile_ms_uses_sorted_seconds() {
        let values = [0.010, 0.020, 0.030, 0.040, 0.050];
        assert_eq!(percentile_ms(&values, 0.50), Some(30.0));
        assert_eq!(percentile_ms(&values, 0.95), Some(50.0));
        assert_eq!(percentile_ms(&[], 0.50), None);
    }

    #[test]
    fn e2e_stats_exclude_warmup_and_timeouts_when_caller_filters() {
        let all = [
            measurement(
                0,
                true,
                Some("audio"),
                Some(0.500),
                Some(0.500),
                None,
                false,
            ),
            measurement(
                1,
                false,
                Some("audio"),
                Some(0.100),
                Some(0.100),
                None,
                false,
            ),
            measurement(
                2,
                false,
                Some("text"),
                Some(0.300),
                None,
                Some(0.300),
                false,
            ),
            measurement(3, false, None, None, None, None, true),
        ];
        let measured: Vec<&UtteranceMeasurement> = all
            .iter()
            .filter(|m| !m.is_warmup && !m.timed_out)
            .collect();

        let stats = compute_e2e_stats(&measured, 10.0);

        assert_eq!(stats.measured_utterances, 2);
        assert_eq!(stats.first_emit_kind_audio, 1);
        assert_eq!(stats.first_emit_kind_text, 1);
        assert_eq!(stats.first_emit_kind_none, 0);
        assert_eq!(stats.eos_to_first_emit_p50_ms, Some(300.0));
        assert_eq!(stats.eos_to_first_emit_p95_ms, Some(300.0));
        assert_eq!(stats.eos_to_first_audio_p50_ms, Some(100.0));
        assert_eq!(stats.eos_to_first_text_p50_ms, Some(300.0));
    }

    #[test]
    fn downmix_to_mono_averages_interleaved_channels() {
        let stereo = [1.0, -1.0, 0.25, 0.75, -0.5, -0.25];
        let mono = downmix_to_mono(&stereo, 2);
        assert_eq!(mono, vec![0.0, 0.5, -0.375]);
    }

    #[test]
    fn truncate_preserves_short_labels_and_shortens_long_labels() {
        assert_eq!(truncate("short", 10), "short");
        assert_eq!(truncate("abcdefghijkl", 6), "abcde…");
    }

    #[test]
    fn report_serialization_keeps_representative_fields() {
        let report = RunReport {
            schema_version: 1,
            started_at_unix_ms: 123,
            wall_clock_secs: 4.5,
            manifest_path: "manifest.json".to_string(),
            manifest_metadata_name: Some("bench".to_string()),
            config: ConfigBlock {
                utterances: 1,
                warmup: 1,
                realtime_pace: false,
                single_shot: true,
                output_kind: BenchOutput::Audio,
                response_timeout_secs: 120,
                inputs: vec!["input.wav".to_string()],
                perf_tap_enabled: true,
                perf_window_ms: 600_000,
            },
            host: HostBlock {
                os: "linux".to_string(),
                arch: "x86_64".to_string(),
                cpu_logical: 8,
            },
            gpu: Vec::new(),
            utterances: vec![measurement(
                0,
                false,
                Some("audio"),
                Some(0.1),
                Some(0.1),
                None,
                false,
            )],
            end_to_end: EndToEndStats {
                measured_utterances: 1,
                eos_to_first_emit_p50_ms: Some(100.0),
                ..Default::default()
            },
            node_order: vec!["node-a".to_string()],
            per_node: serde_json::Value::Null,
            notes: Vec::new(),
            conversational: None,
        };

        let json = serde_json::to_value(&report).unwrap();

        assert_eq!(json["schema_version"], 1);
        assert_eq!(json["config"]["output_kind"], "audio");
        assert_eq!(json["utterances"][0]["eos_to_first_emit_secs"], 0.1);
        assert_eq!(json["end_to_end"]["eos_to_first_emit_p50_ms"], 100.0);
        assert_eq!(json["node_order"][0], "node-a");
    }

    // ── Conversational scenario parsing tests ────────────────────────────

    #[test]
    fn parse_basic_conversation_scenario() {
        let json = r#"{
            "scenario": "basic_conversation",
            "manifest": "../manifests/qwen_s2s_avatar.json",
            "turns": [
                {"input": "turn1.wav", "turn_type": "normal"},
                {"input": "turn2.wav", "turn_type": "normal"},
                {"input": "turn3.wav", "turn_type": "normal"}
            ]
        }"#;
        let scenario: ConversationalScenario = serde_json::from_str(json).unwrap();
        assert_eq!(scenario.scenario, "basic_conversation");
        assert_eq!(scenario.turns.len(), 3);
        for turn in &scenario.turns {
            assert_eq!(turn.turn_type, TurnType::Normal);
            assert!(turn.trigger_at_ms.is_none());
        }
    }

    #[test]
    fn parse_barge_in_scenario() {
        let json = r#"{
            "scenario": "barge_in_demo",
            "manifest": "../manifests/qwen_s2s_avatar.json",
            "description": "Test barge-in handling",
            "turns": [
                {"input": "turn1.wav", "turn_type": "normal"},
                {"input": "barge.wav", "turn_type": "barge_in", "trigger_at_ms": 1500},
                {"input": "turn3.wav", "turn_type": "normal"}
            ]
        }"#;
        let scenario: ConversationalScenario = serde_json::from_str(json).unwrap();
        assert_eq!(scenario.scenario, "barge_in_demo");
        assert_eq!(
            scenario.description.as_deref(),
            Some("Test barge-in handling")
        );
        assert_eq!(scenario.turns.len(), 3);

        assert_eq!(scenario.turns[0].turn_type, TurnType::Normal);
        assert!(scenario.turns[0].trigger_at_ms.is_none());

        assert_eq!(scenario.turns[1].turn_type, TurnType::BargeIn);
        assert_eq!(scenario.turns[1].trigger_at_ms, Some(1500));

        assert_eq!(scenario.turns[2].turn_type, TurnType::Normal);
    }

    #[test]
    fn parse_scenario_with_optional_fields() {
        let json = r#"{
            "scenario": "minimal",
            "manifest": "manifest.json",
            "turns": [
                {"input": "a.wav", "turn_type": "barge_in"}
            ]
        }"#;
        let scenario: ConversationalScenario = serde_json::from_str(json).unwrap();
        assert!(scenario.description.is_none());
        assert_eq!(scenario.turns[0].turn_type, TurnType::BargeIn);
        assert!(scenario.turns[0].trigger_at_ms.is_none());
        assert!(scenario.turns[0].description.is_none());
    }

    #[test]
    fn turn_measurement_serialization() {
        let m = TurnMeasurement {
            turn_idx: 1,
            turn_type: TurnType::BargeIn,
            ttfa_ms: 450.0,
            total_response_ms: 2500.0,
            agent_turn_id: "turn_2".to_string(),
            barge_in_detection_ms: Some(120.0),
            cancellation_propagation_ms: Some(350.0),
            recovery_ttfa_ms: Some(450.0),
            stale_response_suppressed: Some(true),
            interrupted_turn_id: Some("turn_1".to_string()),
        };
        let json = serde_json::to_value(&m).unwrap();
        assert_eq!(json["turn_idx"], 1);
        assert_eq!(json["turn_type"], "barge_in");
        assert_eq!(json["ttfa_ms"], 450.0);
        assert_eq!(json["barge_in_detection_ms"], 120.0);
        assert_eq!(json["stale_response_suppressed"], true);
        assert_eq!(json["interrupted_turn_id"], "turn_1");

        // Normal turn should have None for barge-in fields
        let normal = TurnMeasurement {
            turn_idx: 0,
            turn_type: TurnType::Normal,
            ttfa_ms: 300.0,
            total_response_ms: 2000.0,
            agent_turn_id: "turn_0".to_string(),
            barge_in_detection_ms: None,
            cancellation_propagation_ms: None,
            recovery_ttfa_ms: None,
            stale_response_suppressed: None,
            interrupted_turn_id: None,
        };
        let normal_json = serde_json::to_value(&normal).unwrap();
        assert_eq!(normal_json["turn_type"], "normal");
        assert!(normal_json["barge_in_detection_ms"].is_null());
        assert!(normal_json["stale_response_suppressed"].is_null());
    }

    #[test]
    fn conversational_summary_computation() {
        let turns = vec![
            TurnMeasurement {
                turn_idx: 0,
                turn_type: TurnType::Normal,
                ttfa_ms: 300.0,
                total_response_ms: 2000.0,
                agent_turn_id: "0".into(),
                barge_in_detection_ms: None,
                cancellation_propagation_ms: None,
                recovery_ttfa_ms: None,
                stale_response_suppressed: None,
                interrupted_turn_id: None,
            },
            TurnMeasurement {
                turn_idx: 1,
                turn_type: TurnType::BargeIn,
                ttfa_ms: 500.0,
                total_response_ms: 3000.0,
                agent_turn_id: "1".into(),
                barge_in_detection_ms: Some(150.0),
                cancellation_propagation_ms: Some(400.0),
                recovery_ttfa_ms: Some(500.0),
                stale_response_suppressed: Some(true),
                interrupted_turn_id: Some("0".into()),
            },
            TurnMeasurement {
                turn_idx: 2,
                turn_type: TurnType::Normal,
                ttfa_ms: 350.0,
                total_response_ms: 2200.0,
                agent_turn_id: "2".into(),
                barge_in_detection_ms: None,
                cancellation_propagation_ms: None,
                recovery_ttfa_ms: None,
                stale_response_suppressed: None,
                interrupted_turn_id: None,
            },
        ];

        let summary = ConversationalSummary {
            total_turns: 3,
            barge_in_count: 1,
            avg_ttfa_ms: (300.0 + 500.0 + 350.0) / 3.0,
            avg_barge_in_detection_ms: Some(150.0),
            ttfa_regression_pct: Some(
                ((500.0 - (300.0 + 350.0) / 2.0) / ((300.0 + 350.0) / 2.0)) * 100.0,
            ),
        };

        assert_eq!(summary.total_turns, 3);
        assert_eq!(summary.barge_in_count, 1);
        assert!((summary.avg_ttfa_ms - 383.33).abs() < 0.1);
        assert_eq!(summary.avg_barge_in_detection_ms, Some(150.0));
        // (500 - 325) / 325 * 100 = 53.85%
        assert!(summary.ttfa_regression_pct.unwrap() > 50.0);

        let block = ConversationalBlock {
            scenario: "test".into(),
            turns,
            summary,
        };
        let json = serde_json::to_value(&block).unwrap();
        assert_eq!(json["scenario"], "test");
        assert_eq!(json["turns"].as_array().unwrap().len(), 3);
        assert_eq!(json["summary"]["total_turns"], 3);
    }

    #[test]
    fn run_report_with_conversational_serializes() {
        let report = RunReport {
            schema_version: 1,
            started_at_unix_ms: 1234567890000,
            wall_clock_secs: 45.5,
            manifest_path: "test.json".into(),
            manifest_metadata_name: Some("test".into()),
            config: ConfigBlock {
                utterances: 3,
                warmup: 0,
                realtime_pace: false,
                single_shot: false,
                output_kind: BenchOutput::Audio,
                response_timeout_secs: 180,
                inputs: vec!["a.wav".into(), "b.wav".into()],
                perf_tap_enabled: true,
                perf_window_ms: 600000,
            },
            host: HostBlock {
                os: "linux".into(),
                arch: "x86_64".into(),
                cpu_logical: 16,
            },
            gpu: vec![],
            utterances: vec![],
            end_to_end: EndToEndStats::default(),
            node_order: vec![],
            per_node: serde_json::Value::Null,
            notes: vec![],
            conversational: Some(ConversationalBlock {
                scenario: "test".into(),
                turns: vec![],
                summary: ConversationalSummary {
                    total_turns: 0,
                    barge_in_count: 0,
                    avg_ttfa_ms: 0.0,
                    avg_barge_in_detection_ms: None,
                    ttfa_regression_pct: None,
                },
            }),
        };
        let json = serde_json::to_value(&report).unwrap();
        assert!(json["conversational"].is_object());
        assert_eq!(json["conversational"]["scenario"], "test");
    }

    #[test]
    fn run_report_without_conversational_serializes() {
        let report = RunReport {
            schema_version: 1,
            started_at_unix_ms: 0,
            wall_clock_secs: 1.0,
            manifest_path: "m.json".into(),
            manifest_metadata_name: None,
            config: ConfigBlock {
                utterances: 1,
                warmup: 0,
                realtime_pace: false,
                single_shot: false,
                output_kind: BenchOutput::Audio,
                response_timeout_secs: 120,
                inputs: vec![],
                perf_tap_enabled: false,
                perf_window_ms: 1000,
            },
            host: HostBlock {
                os: "linux".into(),
                arch: "x86_64".into(),
                cpu_logical: 8,
            },
            gpu: vec![],
            utterances: vec![],
            end_to_end: EndToEndStats::default(),
            node_order: vec![],
            per_node: serde_json::Value::Null,
            notes: vec![],
            conversational: None,
        };
        let json = serde_json::to_value(&report).unwrap();
        assert!(json["conversational"].is_null());
    }
}
