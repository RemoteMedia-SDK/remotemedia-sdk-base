//! Per-utterance output capture for the bench harness.
//!
//! When `--capture-dir <DIR>` is set on `bench`, every `RuntimeData`
//! frame received on `audio_rx` / `data_rx` is mirrored into a sink
//! that buffers it for the current utterance. On utterance end the
//! sink flushes everything to disk so the operator can listen / inspect
//! the model's actual output, A/B Python vs Rust pipelines, and catch
//! acoustic regressions that timing alone cannot.
//!
//! Layout per utterance:
//!
//! ```text
//! <capture_dir>/utt-001-measure/
//!   audio-default.wav           # f32 IEEE-float WAV, one per stream_id
//!   text.txt                    # all RuntimeData::Text concatenated
//!   json.jsonl                  # one RuntimeData::Json per line
//!   video-default-000000.bin    # raw pixel_data per frame
//!   video-default-meta.jsonl    # per-frame metadata (codec, ts, …)
//!   images/img-000.<ext>        # encoded image bytes
//!   tensors.jsonl               # shape/dtype summaries (data sidecar .bin)
//!   binaries/000.bin
//!   manifest.json               # summary: counts, durations, paths
//! ```
//!
//! Only files for the kinds that were actually emitted are created.

use crate::wav;
use anyhow::{Context, Result};
use remotemedia_core::data::RuntimeData;
use serde::Serialize;
use std::collections::BTreeMap;
use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};

/// One bench-run-level capture root. Spawns a fresh `UtteranceCapture`
/// per utterance.
pub struct CaptureRoot {
    pub dir: PathBuf,
    /// Tag appended to per-utterance dirnames so we can A/B compare runs
    /// without overwriting (e.g. "python", "rust", "rust-fp16").
    pub tag: Option<String>,
}

impl CaptureRoot {
    pub fn new(dir: PathBuf, tag: Option<String>) -> Result<Self> {
        fs::create_dir_all(&dir)
            .with_context(|| format!("create capture dir {}", dir.display()))?;
        Ok(Self { dir, tag })
    }

    pub fn for_utterance(&self, idx: usize, is_warmup: bool) -> Result<UtteranceCapture> {
        let kind = if is_warmup { "warmup" } else { "measure" };
        let leaf = match self.tag.as_deref() {
            Some(t) => format!("utt-{:03}-{}-{}", idx + 1, kind, t),
            None => format!("utt-{:03}-{}", idx + 1, kind),
        };
        let dir = self.dir.join(leaf);
        fs::create_dir_all(&dir)
            .with_context(|| format!("create utt capture dir {}", dir.display()))?;
        Ok(UtteranceCapture::new(dir))
    }
}

/// Per-utterance buffer. `record()` is cheap (push into per-kind
/// vec/map). `finish()` writes everything to disk and returns a summary
/// that the bench can fold into its JSON report if desired.
pub struct UtteranceCapture {
    dir: PathBuf,
    /// One Vec<f32> per audio stream_id. None key = default (no stream_id).
    audio: BTreeMap<Option<String>, AudioBuffer>,
    text: Vec<String>,
    json: Vec<serde_json::Value>,
    video: BTreeMap<Option<String>, Vec<VideoFrameRecord>>,
    images: Vec<ImageRecord>,
    tensors: Vec<TensorRecord>,
    binaries: Vec<Vec<u8>>,
    control: Vec<serde_json::Value>,
    files_seen: Vec<serde_json::Value>,
}

struct AudioBuffer {
    samples: Vec<f32>,
    sample_rate: u32,
    channels: u32,
    frames: usize,
}

struct VideoFrameRecord {
    pixel_data: Vec<u8>,
    width: u32,
    height: u32,
    format: String,
    codec: Option<String>,
    frame_number: u64,
    timestamp_us: u64,
    is_keyframe: bool,
}

struct ImageRecord {
    data: Vec<u8>,
    format: String,
    width: u32,
    height: u32,
    timestamp_us: Option<u64>,
}

struct TensorRecord {
    data: Vec<u8>,
    shape: Vec<i64>,
    dtype: String,
}

#[derive(Serialize, Default)]
pub struct CaptureSummary {
    pub utt_dir: String,
    pub audio_streams: Vec<AudioStreamSummary>,
    pub text_bytes: usize,
    pub text_chunks: usize,
    pub json_events: usize,
    pub video_frames: usize,
    pub video_streams: Vec<String>,
    pub images: usize,
    pub tensors: usize,
    pub binaries: usize,
    pub control_messages: usize,
    pub file_refs: usize,
}

#[derive(Serialize)]
pub struct AudioStreamSummary {
    pub stream_id: String,
    pub samples: usize,
    pub sample_rate: u32,
    pub channels: u32,
    pub seconds: f64,
    pub frames: usize,
    pub wav_path: String,
}

impl UtteranceCapture {
    fn new(dir: PathBuf) -> Self {
        Self {
            dir,
            audio: BTreeMap::new(),
            text: Vec::new(),
            json: Vec::new(),
            video: BTreeMap::new(),
            images: Vec::new(),
            tensors: Vec::new(),
            binaries: Vec::new(),
            control: Vec::new(),
            files_seen: Vec::new(),
        }
    }

    /// Mirror one received frame into the capture buffers. Cheap — only
    /// clones the inner payload (Vec<f32>, Vec<u8>, String). Designed to
    /// be called from the bench's recv loop with no I/O on the hot path.
    pub fn record(&mut self, rd: &RuntimeData) {
        match rd {
            RuntimeData::Audio {
                samples,
                sample_rate,
                channels,
                stream_id,
                ..
            } => {
                let entry = self
                    .audio
                    .entry(stream_id.clone())
                    .or_insert_with(|| AudioBuffer {
                        samples: Vec::new(),
                        sample_rate: *sample_rate,
                        channels: *channels,
                        frames: 0,
                    });
                entry.samples.extend_from_slice(samples.as_ref());
                entry.frames += 1;
                // First write wins for (sr, channels). Format changes
                // mid-stream are unusual and would corrupt the WAV; if
                // we ever see one, the warning belongs in the bench
                // summary not silently overwriting.
                if entry.sample_rate == 0 {
                    entry.sample_rate = *sample_rate;
                }
                if entry.channels == 0 {
                    entry.channels = *channels;
                }
            }
            RuntimeData::Text(t) => {
                self.text.push(t.clone());
            }
            RuntimeData::Json(v) => {
                self.json.push(v.clone());
            }
            RuntimeData::Video {
                pixel_data,
                width,
                height,
                format,
                codec,
                frame_number,
                timestamp_us,
                is_keyframe,
                stream_id,
                ..
            } => {
                let entry = self.video.entry(stream_id.clone()).or_default();
                entry.push(VideoFrameRecord {
                    pixel_data: pixel_data.clone(),
                    width: *width,
                    height: *height,
                    format: format!("{:?}", format),
                    codec: codec.as_ref().map(|c| format!("{:?}", c)),
                    frame_number: *frame_number,
                    timestamp_us: *timestamp_us,
                    is_keyframe: *is_keyframe,
                });
            }
            RuntimeData::Image {
                data,
                format,
                width,
                height,
                timestamp_us,
                ..
            } => {
                self.images.push(ImageRecord {
                    data: data.clone(),
                    format: format!("{:?}", format),
                    width: *width,
                    height: *height,
                    timestamp_us: *timestamp_us,
                });
            }
            RuntimeData::Tensor {
                data, shape, dtype, ..
            } => {
                self.tensors.push(TensorRecord {
                    data: data.clone(),
                    shape: shape.iter().map(|&v| v as i64).collect(),
                    dtype: dtype_label(*dtype).to_string(),
                });
            }
            RuntimeData::Numpy {
                data, shape, dtype, ..
            } => {
                self.tensors.push(TensorRecord {
                    data: data.clone(),
                    shape: shape.iter().map(|&v| v as i64).collect(),
                    dtype: dtype.clone(),
                });
            }
            RuntimeData::Binary(b) => {
                self.binaries.push(b.clone());
            }
            RuntimeData::ControlMessage {
                message_type,
                segment_id,
                timestamp_ms,
                metadata,
            } => {
                self.control.push(serde_json::json!({
                    "message_type": format!("{:?}", message_type),
                    "segment_id": segment_id,
                    "timestamp_ms": timestamp_ms,
                    "metadata": metadata,
                }));
            }
            RuntimeData::File { path, .. } => {
                self.files_seen.push(serde_json::json!({ "path": path }));
            }
        }
    }

    /// Flush the captured buffers to disk and return a summary. Idempotent
    /// in the sense that empty kinds skip their files; calling finish twice
    /// would overwrite, so the bench should only call it once per utterance.
    pub fn finish(self) -> Result<CaptureSummary> {
        let mut summary = CaptureSummary {
            utt_dir: self.dir.display().to_string(),
            ..Default::default()
        };

        // Audio — one WAV per stream_id
        for (sid, buf) in &self.audio {
            let stream_label = sid.clone().unwrap_or_else(|| "default".to_string());
            let safe = sanitize_stream(&stream_label);
            let wav_path = self.dir.join(format!("audio-{}.wav", safe));
            let ch = buf.channels.max(1) as u16;
            wav::write_wav_f32_path(&wav_path, &buf.samples, buf.sample_rate, ch)?;
            let seconds = if buf.sample_rate > 0 && buf.channels > 0 {
                buf.samples.len() as f64 / (buf.sample_rate as f64 * buf.channels as f64)
            } else {
                0.0
            };
            summary.audio_streams.push(AudioStreamSummary {
                stream_id: stream_label,
                samples: buf.samples.len(),
                sample_rate: buf.sample_rate,
                channels: buf.channels,
                seconds,
                frames: buf.frames,
                wav_path: wav_path.display().to_string(),
            });
        }

        // Text
        if !self.text.is_empty() {
            let path = self.dir.join("text.txt");
            let blob = self.text.join("");
            fs::write(&path, &blob).with_context(|| format!("write {}", path.display()))?;
            summary.text_bytes = blob.len();
            summary.text_chunks = self.text.len();
        }

        // Json — one event per line
        if !self.json.is_empty() {
            let path = self.dir.join("json.jsonl");
            let mut f =
                File::create(&path).with_context(|| format!("create {}", path.display()))?;
            for v in &self.json {
                writeln!(f, "{}", v)?;
            }
            summary.json_events = self.json.len();
        }

        // Video — raw pixel_data per frame + meta jsonl per stream
        if !self.video.is_empty() {
            for (sid, frames) in &self.video {
                let stream_label = sid.clone().unwrap_or_else(|| "default".to_string());
                let safe = sanitize_stream(&stream_label);
                let meta_path = self.dir.join(format!("video-{}-meta.jsonl", safe));
                let mut meta = File::create(&meta_path)
                    .with_context(|| format!("create {}", meta_path.display()))?;
                for (i, fr) in frames.iter().enumerate() {
                    let bin_name = format!("video-{}-{:06}.bin", safe, i);
                    let bin_path = self.dir.join(&bin_name);
                    fs::write(&bin_path, &fr.pixel_data)
                        .with_context(|| format!("write {}", bin_path.display()))?;
                    let rec = serde_json::json!({
                        "index": i,
                        "file": bin_name,
                        "width": fr.width,
                        "height": fr.height,
                        "format": fr.format,
                        "codec": fr.codec,
                        "frame_number": fr.frame_number,
                        "timestamp_us": fr.timestamp_us,
                        "is_keyframe": fr.is_keyframe,
                        "bytes": fr.pixel_data.len(),
                    });
                    writeln!(meta, "{}", rec)?;
                    summary.video_frames += 1;
                }
                summary.video_streams.push(stream_label);
            }
        }

        // Images
        if !self.images.is_empty() {
            let imgs_dir = self.dir.join("images");
            fs::create_dir_all(&imgs_dir)
                .with_context(|| format!("create {}", imgs_dir.display()))?;
            let meta_path = imgs_dir.join("manifest.jsonl");
            let mut meta = File::create(&meta_path)?;
            for (i, im) in self.images.iter().enumerate() {
                let ext = image_ext(&im.format);
                let name = format!("img-{:03}.{}", i, ext);
                let path = imgs_dir.join(&name);
                fs::write(&path, &im.data)?;
                writeln!(
                    meta,
                    "{}",
                    serde_json::json!({
                        "index": i, "file": name, "format": im.format,
                        "width": im.width, "height": im.height,
                        "timestamp_us": im.timestamp_us, "bytes": im.data.len(),
                    })
                )?;
                summary.images += 1;
            }
        }

        // Tensors — sidecar .bin + jsonl entry
        if !self.tensors.is_empty() {
            let bin_dir = self.dir.join("tensors");
            fs::create_dir_all(&bin_dir)?;
            let meta_path = self.dir.join("tensors.jsonl");
            let mut meta = File::create(&meta_path)?;
            for (i, t) in self.tensors.iter().enumerate() {
                let name = format!("{:03}.bin", i);
                let path = bin_dir.join(&name);
                fs::write(&path, &t.data)?;
                writeln!(
                    meta,
                    "{}",
                    serde_json::json!({
                        "index": i, "file": format!("tensors/{}", name),
                        "shape": t.shape, "dtype": t.dtype, "bytes": t.data.len(),
                    })
                )?;
                summary.tensors += 1;
            }
        }

        // Binaries
        if !self.binaries.is_empty() {
            let bin_dir = self.dir.join("binaries");
            fs::create_dir_all(&bin_dir)?;
            for (i, b) in self.binaries.iter().enumerate() {
                fs::write(bin_dir.join(format!("{:03}.bin", i)), b)?;
                summary.binaries += 1;
            }
        }

        // Control messages
        if !self.control.is_empty() {
            let path = self.dir.join("control.jsonl");
            let mut f = File::create(&path)?;
            for v in &self.control {
                writeln!(f, "{}", v)?;
            }
            summary.control_messages = self.control.len();
        }

        // File references
        if !self.files_seen.is_empty() {
            let path = self.dir.join("files.jsonl");
            let mut f = File::create(&path)?;
            for v in &self.files_seen {
                writeln!(f, "{}", v)?;
            }
            summary.file_refs = self.files_seen.len();
        }

        // Manifest
        let manifest_path = self.dir.join("manifest.json");
        let manifest_json = serde_json::to_string_pretty(&summary)?;
        fs::write(&manifest_path, manifest_json)?;

        Ok(summary)
    }
}

fn sanitize_stream(s: &str) -> String {
    s.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '_' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn dtype_label(dtype: i32) -> &'static str {
    match dtype {
        0 => "float32",
        1 => "int32",
        2 => "int64",
        3 => "uint8",
        4 => "int16",
        5 => "float16",
        6 => "float64",
        _ => "unknown",
    }
}

fn image_ext(format_dbg: &str) -> &'static str {
    let lower = format_dbg.to_ascii_lowercase();
    if lower.contains("jpeg") || lower.contains("jpg") {
        "jpg"
    } else if lower.contains("png") {
        "png"
    } else if lower.contains("webp") {
        "webp"
    } else if lower.contains("raw") {
        "raw"
    } else {
        "bin"
    }
}

/// Top-level helper for bench main loop: call once after creating the
/// `CaptureRoot` to ensure the dir is writable and emit a header file
/// describing the run. Optional sanity check.
pub fn write_run_header(root: &CaptureRoot, manifest_path: &Path) -> Result<()> {
    let header = serde_json::json!({
        "manifest": manifest_path.display().to_string(),
        "tag": root.tag,
        "schema": "remotemedia-bench-capture/v1",
    });
    fs::write(
        root.dir.join("run.json"),
        serde_json::to_string_pretty(&header)?,
    )?;
    Ok(())
}
