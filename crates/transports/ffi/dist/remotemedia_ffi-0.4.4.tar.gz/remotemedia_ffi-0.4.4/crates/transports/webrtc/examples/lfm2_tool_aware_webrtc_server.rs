//! LFM2-Audio tool-aware WebRTC demo server.
//!
//! Wires our tool-awareness fine-tune (`tools/lfm2_tool_aware/runs/v1/final/`)
//! into a turn-based WebRTC pipeline so the browser observer UI can:
//!
//!   * toggle which tools are "available" via the Tool Selector pane
//!     (calls `ctrl.audio.set_system_prompt(prompt)` over typed-RPC,
//!     passing the training-format prompt the LoRA learned to read)
//!   * speak a query and hear the model either:
//!       - acknowledge briefly when a relevant tool IS listed
//!       - refuse politely when the relevant tool is NOT listed
//!       - answer normally for general / chitchat queries
//!
//! Mirrors `lfm2_audio_webrtc_server.rs` topology end-to-end. Only the
//! `audio` node's `hf_repo` (local fine-tuned checkpoint) and default
//! system prompt differ.
//!
//! ## Tool Selector wire format
//!
//! Use the **typed-RPC** path, not raw publish to `audio.in.system_prompt`:
//!
//! ```js
//! await ctrl.audio.set_system_prompt(
//!   "Respond with interleaved text and audio.\n\n" +
//!   "Tools available:\n" + selected.map(t => `- ${t.name}: ${t.desc}`).join("\n") + "\n\n" +
//!   "If a request needs one of these tools, acknowledge briefly and stop. " +
//!   "Otherwise answer normally."
//! );
//! ```
//!
//! On first connect — before any tools have been selected — the
//! system prompt is just `"Respond with interleaved text and audio."`.
//! The fine-tune preserves baseline LFM2-Audio behaviour for general
//! and chitchat queries with no tools listed, so the model will sound
//! like the upstream model until the Tool Selector publishes a tools
//! list. This is intended (it's what the `general` / `chitchat`
//! training classes preserve). The tool-aware behaviours only manifest
//! after the prompt includes a `Tools available:` block.
//!
//! Topology:
//!
//! ```text
//!   mic (48k) ─► resample_in (48k→16k) ─► chunker (512) ─► vad ─► accumulator
//!                                                                     │
//!                                           ┌─────────────────────────┤
//!                                           ▼                         ▼
//!                                       stt_in (Whisper)    resample_up (16→24k)
//!                                                                     │
//!                                                                     ▼
//!                                                          audio (LFM2 fine-tune, 24k)
//!                                                                     │
//!                                                                     ▼
//!                                                          resample_out (24→48k, SINK)
//! ```
//!
//! Control-bus endpoints (same surface as the LFM2 demo server):
//!
//! - subscribe `vad.out`, `accumulator.out`, `stt_in.out`, `audio.out`
//! - publish   `audio.in.system_prompt`  (the Tool Selector publishes here)
//! - publish   `audio.in.reset`, `audio.in.barge_in`
//!
//! # Environment
//!
//! | Variable                   | Default                                                | Description                            |
//! |----------------------------|--------------------------------------------------------|----------------------------------------|
//! | `LFM2_TOOL_AWARE_HF_REPO`  | `tools/lfm2_tool_aware/runs/v1/final`                  | Path or HF repo for the audio model    |
//! | `LFM2_TOOL_AWARE_PROMPT`   | *"Respond with interleaved text and audio."*           | Default system prompt before any tools |
//! | `AUDIO_TIMEOUT_MS`         | `180000`                                               | Cold-start budget for the audio node   |
//!
//! Run:
//!
//! ```bash
//! cargo run --example lfm2_tool_aware_webrtc_server \
//!     -p remotemedia-webrtc --features ws-signaling -- --port 8083
//! ```
//!
//! Then serve `examples/web/lfm2-audio-webrtc/` and point it at
//! `ws://127.0.0.1:8083/ws`.

#![cfg(feature = "ws-signaling")]

use remotemedia_core::manifest::{
    Connection, Manifest, ManifestMetadata, ManifestPythonEnv, NodeManifest,
};
use remotemedia_core::transport::{ExecutorConfig, PipelineExecutor};
use remotemedia_webrtc::config::WebRtcTransportConfig;
use remotemedia_webrtc::signaling::WebSocketSignalingServer;
use std::path::PathBuf;
use std::sync::Arc;

// Force-link remotemedia-python-nodes so its `inventory::submit!` macro
// pulls Python node factories (LFM2AudioNode / WhisperSTTNode / ...) into
// the default streaming registry.
#[allow(unused_imports)]
use remotemedia_python_nodes as _python_nodes_link;

const DEFAULT_SYSTEM_PROMPT: &str = "Respond with interleaved text and audio.";

fn resolve_hf_repo() -> String {
    // Explicit env var wins. Otherwise resolve the in-repo default
    // (tools/lfm2_tool_aware/runs/v1/final) to an absolute path so the
    // LFM2AudioNode worker — which cwd's into the multiprocess runner's
    // temp dir — can still find the checkpoint.
    if let Ok(v) = std::env::var("LFM2_TOOL_AWARE_HF_REPO") {
        return v;
    }
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let repo_root = manifest_dir.ancestors().nth(3); // crates/transports/webrtc -> ... -> repo root
    let candidate = repo_root.map(|root| {
        root.join("tools")
            .join("lfm2_tool_aware")
            .join("runs")
            .join("v1")
            .join("final")
    });
    match candidate {
        Some(path) if path.exists() => path.to_string_lossy().into_owned(),
        Some(path) => {
            eprintln!(
                "[lfm2_tool_aware] WARNING: default fine-tune dir not found at {} — \
                 falling back to base LiquidAI/LFM2.5-Audio-1.5B. Set \
                 LFM2_TOOL_AWARE_HF_REPO to override.",
                path.display()
            );
            "LiquidAI/LFM2.5-Audio-1.5B".to_string()
        }
        None => "LiquidAI/LFM2.5-Audio-1.5B".to_string(),
    }
}

fn build_manifest() -> Manifest {
    let hf_repo = resolve_hf_repo();
    let system_prompt = std::env::var("LFM2_TOOL_AWARE_PROMPT")
        .unwrap_or_else(|_| DEFAULT_SYSTEM_PROMPT.to_string());

    let audio_params = serde_json::json!({
        "hf_repo": hf_repo,
        "system_prompt": system_prompt,
        // Fine-tuned responses are short acknowledgements; capping
        // generation keeps tail-latency low if the model ever wanders.
        "max_new_tokens": 256,
        "sample_rate": 24000,
        "text_only": false,
    });
    let audio_deps = vec![
        "liquid-audio>=0.1".to_string(),
        "transformers>=4.54.0,<5.0".to_string(),
        "torch>=2.1".to_string(),
        "torchaudio>=2.1".to_string(),
        "accelerate>=0.33".to_string(),
        "safetensors<0.5".to_string(),
    ];

    let whisper_params = serde_json::json!({
        "model_id": "openai/whisper-tiny.en",
        "language": "en",
    });
    let whisper_deps = vec![
        "transformers>=4.40.0".to_string(),
        "torch>=2.1".to_string(),
        "accelerate>=0.33".to_string(),
    ];

    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "lfm2-tool-aware-webrtc".to_string(),
            description: Some(
                "Tool-aware LFM2-Audio fine-tune over WebRTC, with the \
                 browser Tool Selector publishing system-prompt updates"
                    .to_string(),
            ),
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "resample_in".to_string(),
                node_type: "FastResampleNode".to_string(),
                params: serde_json::json!({
                    "source_rate": 48000,
                    "target_rate": 16000,
                    "quality": "Medium",
                    "channels": 1,
                }),
                ..Default::default()
            },
            NodeManifest {
                id: "chunker".to_string(),
                node_type: "AudioChunkerNode".to_string(),
                params: serde_json::json!({ "chunkSize": 512 }),
                ..Default::default()
            },
            NodeManifest {
                id: "vad".to_string(),
                node_type: "SileroVADNode".to_string(),
                params: serde_json::json!({
                    "threshold": 0.6,
                    "neg_threshold": 0.35,
                    "sample_rate": 16000,
                    "min_speech_duration_ms": 250,
                    "min_silence_duration_ms": 500,
                    "speech_pad_ms": 150,
                }),
                ..Default::default()
            },
            NodeManifest {
                id: "accumulator".to_string(),
                node_type: "AudioBufferAccumulatorNode".to_string(),
                params: serde_json::json!({
                    "min_utterance_duration_ms": 300,
                    "max_utterance_duration_ms": 30000,
                }),
                ..Default::default()
            },
            NodeManifest {
                id: "resample_up".to_string(),
                node_type: "FastResampleNode".to_string(),
                params: serde_json::json!({
                    "source_rate": 16000,
                    "target_rate": 24000,
                    "quality": "Medium",
                    "channels": 1,
                }),
                ..Default::default()
            },
            NodeManifest {
                id: "audio".to_string(),
                node_type: "LFM2AudioNode".to_string(),
                params: audio_params,
                python_deps: Some(audio_deps),
                ..Default::default()
            },
            NodeManifest {
                id: "stt_in".to_string(),
                node_type: "WhisperSTTNode".to_string(),
                params: whisper_params,
                python_deps: Some(whisper_deps),
                ..Default::default()
            },
            NodeManifest {
                id: "resample_out".to_string(),
                node_type: "FastResampleNode".to_string(),
                params: serde_json::json!({
                    "source_rate": 24000,
                    "target_rate": 48000,
                    "quality": "Medium",
                    "channels": 1,
                }),
                ..Default::default()
            },
        ],
        connections: vec![
            Connection {
                from: "resample_in".to_string(),
                to: "chunker".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "chunker".to_string(),
                to: "vad".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "vad".to_string(),
                to: "accumulator".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "accumulator".to_string(),
                to: "resample_up".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "resample_up".to_string(),
                to: "audio".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "accumulator".to_string(),
                to: "stt_in".to_string(),
                from_port: None,
                to_port: None,
            },
            Connection {
                from: "audio".to_string(),
                to: "resample_out".to_string(),
                from_port: None,
                to_port: None,
            },
        ],
        python_env: Some(ManifestPythonEnv {
            python_version: Some("3.12".to_string()),
            scope: None,
            extra_deps: Vec::new(),
        }),
        // Default::default() fills in `plugins` and any future new
        // Manifest fields so this example doesn't break on additive
        // changes to the manifest schema.
        ..Default::default()
    }
}

/// Mirror lfm2_audio_webrtc_server's PYTHON_ENV defaults so the
/// managed-venv runner has the right interpreter + editable client.
fn default_python_env() {
    let ensure = |k: &str, v: &str| {
        if std::env::var_os(k).is_none() {
            std::env::set_var(k, v);
        }
    };
    ensure("PYTHON_ENV_MODE", "managed");
    ensure("PYTHON_VERSION", "3.12");

    if std::env::var_os("REMOTEMEDIA_PYTHON_SRC").is_none() {
        let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let candidate = manifest_dir
            .ancestors()
            .nth(3)
            .map(|root| root.join("clients").join("python"));
        if let Some(path) = candidate {
            if path.exists() {
                std::env::set_var("REMOTEMEDIA_PYTHON_SRC", path);
            }
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    default_python_env();

    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .with_writer(std::io::stderr)
        .try_init();

    let mut args = std::env::args().skip(1);
    let mut port: u16 = 8083;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--port" | "-p" => {
                port = args
                    .next()
                    .ok_or("--port requires a value")?
                    .parse()
                    .map_err(|e| format!("bad --port: {e}"))?;
            }
            "--host" => {
                let _ = args.next().ok_or("--host requires a value")?;
            }
            "-h" | "--help" => {
                eprintln!(
                    "lfm2_tool_aware_webrtc_server [--host ADDR] [--port PORT]\n\n\
                     env:\n  \
                     LFM2_TOOL_AWARE_HF_REPO   path or HF repo of the fine-tune\n  \
                                               (default: tools/lfm2_tool_aware/runs/v1/final)\n  \
                     LFM2_TOOL_AWARE_PROMPT    default system prompt before any tools selected\n  \
                     AUDIO_TIMEOUT_MS          cold-start budget for the audio node (default 180000)\n  \
                     PYTHON_ENV_MODE=managed   use uv-managed per-node venvs\n  \
                     PYTHON_VERSION=3.12       pin managed-venv Python version\n  \
                     REMOTEMEDIA_PYTHON_SRC    path to `clients/python` for editable install"
                );
                return Ok(());
            }
            other => {
                eprintln!("unrecognized arg: {other}");
                std::process::exit(2);
            }
        }
    }

    let manifest = Arc::new(build_manifest());

    let mut exec_cfg = ExecutorConfig::default();
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or_default();
    exec_cfg.session_id_prefix = format!("s{}", ts);

    let audio_timeout_ms = std::env::var("AUDIO_TIMEOUT_MS")
        .ok()
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(180_000);
    exec_cfg.scheduler_config = exec_cfg
        .scheduler_config
        .clone()
        .with_node_timeout("audio", audio_timeout_ms);

    let executor = Arc::new(PipelineExecutor::with_config(exec_cfg)?);
    let config = Arc::new(WebRtcTransportConfig::default());
    let server = WebSocketSignalingServer::new(port, config, executor, manifest);
    let handle = server.start().await?;

    println!("READY ws://127.0.0.1:{port}/ws");
    println!(
        "Model:          {}",
        std::env::var("LFM2_TOOL_AWARE_HF_REPO").unwrap_or_else(|_| resolve_hf_repo())
    );
    println!("Tip: open the Tool Selector pane in the browser observer to pick");
    println!("     which tools are 'available' for the conversation.");
    println!("Press Ctrl-C to stop.");

    tokio::signal::ctrl_c().await?;
    drop(handle);
    Ok(())
}
