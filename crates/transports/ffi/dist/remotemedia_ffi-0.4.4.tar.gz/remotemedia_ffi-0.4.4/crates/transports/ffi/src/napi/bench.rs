//! Node.js binding for the reusable benchmark harness.

use napi_derive::napi;

/// Run the reusable RemoteMedia benchmark harness from Node.js.
///
/// Returns the benchmark report as a JSON string. `optionsJson` is an
/// optional JSON object string with the same keys as the Python binding:
/// `manifest_path`, `utterances`, `warmup`, `realtime_pace`,
/// `single_shot`, `output_kind`, `response_timeout_secs`, `capture_dir`,
/// `capture_tag`, `output_path`, and `prewarm`.
#[napi]
pub async fn benchmark_pipeline(
    manifest_json: String,
    input_paths: Vec<String>,
    options_json: Option<String>,
) -> napi::Result<String> {
    crate::bench::benchmark_pipeline_json(manifest_json, input_paths, options_json)
        .await
        .map_err(|e| napi::Error::from_reason(format!("Benchmark failed: {}", e)))
}
