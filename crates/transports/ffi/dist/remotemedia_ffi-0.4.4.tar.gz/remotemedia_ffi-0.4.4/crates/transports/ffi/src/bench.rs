//! Shared benchmark helper for Python and Node.js FFI bindings.

use anyhow::{Context, Result};
use remotemedia_bench::{BenchConfig, BenchOutput};
use remotemedia_core::manifest::Manifest;
use remotemedia_core::transport::PipelineExecutor;
use serde::Deserialize;
use std::path::PathBuf;
use std::sync::Arc;

#[derive(Debug, Default, Deserialize)]
pub struct FfiBenchOptions {
    pub manifest_path: Option<String>,
    pub utterances: Option<usize>,
    pub warmup: Option<usize>,
    pub realtime_pace: Option<bool>,
    pub single_shot: Option<bool>,
    pub output_kind: Option<String>,
    pub response_timeout_secs: Option<u64>,
    pub capture_dir: Option<String>,
    pub capture_tag: Option<String>,
    pub output_path: Option<String>,
    pub prewarm: Option<bool>,
}

pub async fn benchmark_pipeline_json(
    manifest_json: String,
    input_paths: Vec<String>,
    options_json: Option<String>,
) -> Result<String> {
    let options = parse_options(options_json)?;
    let started_at_unix_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    let manifest: Manifest =
        serde_json::from_str(&manifest_json).context("failed to parse manifest JSON")?;
    let manifest = Arc::new(manifest);

    let input_paths: Vec<PathBuf> = input_paths.into_iter().map(PathBuf::from).collect();
    let manifest_path = options
        .manifest_path
        .as_deref()
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("<ffi-manifest>"));

    let mut config = BenchConfig::new(manifest_path, input_paths);
    if let Some(v) = options.utterances {
        config.utterances = v;
    }
    if let Some(v) = options.warmup {
        config.warmup = v;
    }
    if let Some(v) = options.realtime_pace {
        config.realtime_pace = v;
    }
    if let Some(v) = options.single_shot {
        config.single_shot = v;
    }
    if let Some(v) = options.output_kind.as_deref() {
        config.output_kind = parse_output_kind(v)?;
    }
    if let Some(v) = options.response_timeout_secs {
        config.response_timeout_secs = v;
    }
    if let Some(v) = options.capture_dir.as_deref() {
        config.capture_dir = Some(PathBuf::from(v));
    }
    if let Some(v) = options.capture_tag {
        config.capture_tag = Some(v);
    }
    if let Some(v) = options.prewarm {
        config.prewarm = v;
    }

    let executor = PipelineExecutor::with_config(remotemedia_bench::default_executor_config(
        started_at_unix_ms,
    ))
    .map_err(|e| anyhow::anyhow!("failed to create PipelineExecutor: {}", e))?;
    let executor = Arc::new(executor);

    let report = remotemedia_bench::run_benchmark(executor, manifest, config).await?;
    if let Some(path) = options.output_path.as_deref() {
        remotemedia_bench::write_report(path, &report)?;
    }
    serde_json::to_string_pretty(&report).context("failed to serialize benchmark report")
}

fn parse_options(options_json: Option<String>) -> Result<FfiBenchOptions> {
    match options_json {
        Some(s) if !s.trim().is_empty() => {
            serde_json::from_str(&s).context("failed to parse benchmark options JSON")
        }
        _ => Ok(FfiBenchOptions::default()),
    }
}

fn parse_output_kind(value: &str) -> Result<BenchOutput> {
    match value {
        "audio" | "Audio" => Ok(BenchOutput::Audio),
        "data" | "text" | "Data" | "Text" => Ok(BenchOutput::Data),
        other => anyhow::bail!("unsupported output_kind '{other}', expected 'audio' or 'data'"),
    }
}
