//! SIP signaling primitives.
//!
//! Full parser/dialog handling is implemented in later tasks. This module is
//! intentionally present now so the crate layout matches the approved
//! transport-oriented OpenSpec design.

use crate::{Error, Result};
use std::collections::HashMap;

/// SIP methods required for the initial gateway.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SipMethod {
    /// Start or modify a call session.
    Invite,
    /// Confirm final response to INVITE.
    Ack,
    /// Terminate an established dialog.
    Bye,
    /// Cancel a pending INVITE.
    Cancel,
    /// Capability keepalive/probe.
    Options,
}

impl SipMethod {
    fn parse(value: &str) -> Option<Self> {
        match value.to_ascii_uppercase().as_str() {
            "INVITE" => Some(Self::Invite),
            "ACK" => Some(Self::Ack),
            "BYE" => Some(Self::Bye),
            "CANCEL" => Some(Self::Cancel),
            "OPTIONS" => Some(Self::Options),
            _ => None,
        }
    }

    /// Return the wire method token.
    pub fn as_str(self) -> &'static str {
        match self {
            SipMethod::Invite => "INVITE",
            SipMethod::Ack => "ACK",
            SipMethod::Bye => "BYE",
            SipMethod::Cancel => "CANCEL",
            SipMethod::Options => "OPTIONS",
        }
    }
}

/// Parsed SIP request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SipRequest {
    /// SIP method.
    pub method: SipMethod,
    /// Request URI.
    pub uri: String,
    /// SIP version.
    pub version: String,
    /// Header map with lowercase keys.
    pub headers: HashMap<String, String>,
    /// All Via headers in wire order. SIP responses must echo every Via.
    pub via_headers: Vec<String>,
    /// Message body.
    pub body: String,
}

/// SIP transaction response produced by the telephony transport.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SipTransactionResponse {
    /// Status code returned to the peer.
    pub status_code: u16,
    /// Wire-format response bytes.
    pub bytes: Vec<u8>,
}

impl SipRequest {
    /// Return a header by case-insensitive name.
    pub fn header(&self, name: &str) -> Option<&str> {
        self.headers
            .get(&name.to_ascii_lowercase())
            .map(String::as_str)
    }

    /// SIP Call-ID header.
    pub fn call_id(&self) -> Option<&str> {
        self.header("call-id").or_else(|| self.header("i"))
    }
}

/// Parse a SIP request from bytes.
pub fn parse_request(bytes: &[u8]) -> Result<SipRequest> {
    let text = std::str::from_utf8(bytes)
        .map_err(|e| Error::Sip(format!("SIP message is not UTF-8: {e}")))?;
    let (head, body) = text
        .split_once("\r\n\r\n")
        .or_else(|| text.split_once("\n\n"))
        .unwrap_or((text, ""));
    let mut lines = head.lines().map(str::trim_end);
    let request_line = lines
        .next()
        .ok_or_else(|| Error::Sip("missing SIP request line".to_string()))?;
    let parts: Vec<&str> = request_line.split_whitespace().collect();
    if parts.len() != 3 {
        return Err(Error::Sip(format!(
            "invalid SIP request line: {request_line}"
        )));
    }
    let method = SipMethod::parse(parts[0])
        .ok_or_else(|| Error::Sip(format!("unsupported SIP method '{}'", parts[0])))?;

    let mut headers = HashMap::new();
    let mut via_headers: Vec<String> = Vec::new();
    let mut current_key: Option<String> = None;
    for line in lines {
        if line.is_empty() {
            continue;
        }

        if line.starts_with(' ') || line.starts_with('\t') {
            let continuation = line.trim();
            if let Some(key) = &current_key {
                headers.entry(key.clone()).and_modify(|value: &mut String| {
                    value.push(' ');
                    value.push_str(continuation);
                });
                if key == "via" {
                    if let Some(value) = via_headers.last_mut() {
                        value.push(' ');
                        value.push_str(continuation);
                    }
                }
            }
            continue;
        }

        let (name, value) = line
            .split_once(':')
            .ok_or_else(|| Error::Sip(format!("invalid SIP header line: {line}")))?;
        let key = normalize_header_name(name);
        current_key = Some(key.clone());
        let value = value.trim().to_string();
        if key == "via" {
            via_headers.push(value.clone());
        }
        headers.insert(key, value);
    }

    Ok(SipRequest {
        method,
        uri: parts[1].to_string(),
        version: parts[2].to_string(),
        headers,
        via_headers,
        body: body.to_string(),
    })
}

/// Build a SIP response reusing dialog headers from a request.
pub fn build_response(
    request: &SipRequest,
    status_code: u16,
    reason: &str,
    body: &str,
    contact_host: Option<&str>,
) -> String {
    let mut response = format!("SIP/2.0 {status_code} {reason}\r\n");
    for via in &request.via_headers {
        response.push_str(&format!("Via: {via}\r\n"));
    }
    for header in ["from", "to", "call-id", "cseq"] {
        if let Some(value) = request.header(header) {
            let name = canonical_header_name(header);
            let value = if header == "to"
                && status_code != 100
                && !value.to_ascii_lowercase().contains("tag=")
            {
                format!("{value};tag=remotemedia")
            } else {
                value.to_string()
            };
            response.push_str(&format!("{name}: {value}\r\n"));
        }
    }
    if request.method == SipMethod::Invite && (200..300).contains(&status_code) {
        let host = contact_host
            .or_else(|| request.uri.split('@').nth(1))
            .unwrap_or("127.0.0.1");
        response.push_str(&format!(
            "Contact: <sip:remotemedia@{};transport=udp>\r\n",
            host
        ));
    }
    response.push_str("Server: RemoteMedia Telephony\r\n");
    response.push_str(&format!("Content-Length: {}\r\n", body.len()));
    if !body.is_empty() {
        response.push_str("Content-Type: application/sdp\r\n");
    }
    response.push_str("\r\n");
    response.push_str(body);
    response
}

/// Build a minimal SIP OPTIONS 200 OK response.
pub fn build_options_ok(request: &SipRequest) -> String {
    let mut response = build_response(request, 200, "OK", "", None);
    response = response.replace(
        "Content-Length: 0\r\n",
        "Allow: INVITE, ACK, BYE, CANCEL, OPTIONS\r\nAccept: application/sdp\r\nContent-Length: 0\r\n",
    );
    response
}

fn normalize_header_name(name: &str) -> String {
    match name.trim().to_ascii_lowercase().as_str() {
        "i" => "call-id".to_string(),
        "f" => "from".to_string(),
        "t" => "to".to_string(),
        "v" => "via".to_string(),
        "m" => "contact".to_string(),
        other => other.to_string(),
    }
}

fn canonical_header_name(name: &str) -> &'static str {
    match name {
        "via" => "Via",
        "from" => "From",
        "to" => "To",
        "call-id" => "Call-ID",
        "cseq" => "CSeq",
        _ => "X-Unknown",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const INVITE: &str = "INVITE sip:bot@example.com SIP/2.0\r\n\
Via: SIP/2.0/UDP 192.0.2.10:5060;branch=z9hG4bK1\r\n\
From: <sip:alice@example.com>;tag=abc\r\n\
To: <sip:bot@example.com>\r\n\
Call-ID: call-123\r\n\
CSeq: 1 INVITE\r\n\
Contact: <sip:alice@192.0.2.10>\r\n\
Content-Type: application/sdp\r\n\
Content-Length: 3\r\n\
\r\n\
abc";

    const PROXIED_INVITE: &str = "INVITE sip:bot@example.com SIP/2.0\r\n\
Via: SIP/2.0/UDP 198.51.100.20:5060;branch=z9hG4bKproxy\r\n\
Via: SIP/2.0/UDP 192.0.2.10:5060;rport=5060;branch=z9hG4bKclient\r\n\
From: <sip:alice@example.com>;tag=abc\r\n\
To: <sip:bot@example.com>\r\n\
Call-ID: call-456\r\n\
CSeq: 2 INVITE\r\n\
Content-Length: 0\r\n\
\r\n";

    #[test]
    fn parses_invite() {
        let request = parse_request(INVITE.as_bytes()).unwrap();
        assert_eq!(request.method, SipMethod::Invite);
        assert_eq!(request.uri, "sip:bot@example.com");
        assert_eq!(request.call_id(), Some("call-123"));
        assert_eq!(
            request.via_headers,
            vec!["SIP/2.0/UDP 192.0.2.10:5060;branch=z9hG4bK1"]
        );
        assert_eq!(request.body, "abc");
    }

    #[test]
    fn builds_response_with_dialog_headers() {
        let request = parse_request(INVITE.as_bytes()).unwrap();
        let response = build_response(&request, 200, "OK", "sdp", None);
        assert!(response.starts_with("SIP/2.0 200 OK"));
        assert!(response.contains("Via: SIP/2.0/UDP 192.0.2.10:5060"));
        assert!(response.contains("To: <sip:bot@example.com>;tag=remotemedia"));
        assert!(response.contains("Contact: <sip:remotemedia@example.com;transport=udp>"));
        assert!(response.contains("Content-Type: application/sdp"));
    }

    #[test]
    fn builds_response_with_all_via_headers_in_order() {
        let request = parse_request(PROXIED_INVITE.as_bytes()).unwrap();
        assert_eq!(
            request.via_headers,
            vec![
                "SIP/2.0/UDP 198.51.100.20:5060;branch=z9hG4bKproxy",
                "SIP/2.0/UDP 192.0.2.10:5060;rport=5060;branch=z9hG4bKclient"
            ]
        );

        let response = build_response(&request, 200, "OK", "sdp", None);
        let first = response
            .find("Via: SIP/2.0/UDP 198.51.100.20:5060;branch=z9hG4bKproxy")
            .unwrap();
        let second = response
            .find("Via: SIP/2.0/UDP 192.0.2.10:5060;rport=5060;branch=z9hG4bKclient")
            .unwrap();
        assert!(first < second);
    }

    #[test]
    fn builds_trying_without_to_tag() {
        let request = parse_request(INVITE.as_bytes()).unwrap();
        let response = build_response(&request, 100, "Trying", "", None);
        assert!(response.starts_with("SIP/2.0 100 Trying"));
        assert!(response.contains("To: <sip:bot@example.com>\r\n"));
        assert!(!response.contains("tag=remotemedia"));
        assert!(!response.contains("Contact:"));
    }

    #[test]
    fn method_round_trips_name() {
        assert_eq!(SipMethod::Invite.as_str(), "INVITE");
    }
}
