//! Qwen speech-to-speech WebRTC demo server with **Live2D avatar lip-sync**.
//!
//! Extends [`qwen_s2s_webrtc_server`] by inserting the avatar pipeline
//! (`EmotionExtractorNode` → `Audio2FaceLipSyncNode` → `Live2DRenderNode`)
//! so the browser receives BOTH the synthesized voice on a WebRTC audio
//! track AND a 30 fps lip-synced avatar video on a WebRTC video track.
//!
//! Topology:
//!
//! ```text
//!   mic (48k) → resample_in (48→16k) → chunker (512) → vad ──┬──→ accumulator
//!                                                            │
//!                                                            │      ▼
//!                                                            │   stt_in (Whisper)
//!                                                            │      │
//!                                                            │      ▼
//!                                                            │   llm (Qwen3.6-27B GGUF, streams text)
//!                                                            │      │
//!                                                            └──→ coordinator (turn phase, sentencer)
//!                                                                   │
//!                                                                   ▼
//!                                                          emotion_extractor
//!                                                          ┌─(text)──→ kokoro_tts (24 kHz)
//!                                                          │              │
//!                                                          │              ├──→ audio (resample 24→48k, AUDIO SINK)
//!                                                          │              │
//!                                                          │              └──→ resample_a2f (24→16k)
//!                                                          │                          │
//!                                                          │                          ▼
//!                                                          │              audio2face_lipsync (Audio2Face ONNX)
//!                                                          │                          │
//!                                                          │                          ▼
//!                                                          └─(emotion)──→ live2d_render (Aria, VIDEO SINK)
//! ```
//!
//! The pipeline routes Kokoro's audio to two sinks: the WebRTC audio
//! output (after resampling to 48 kHz) AND the Audio2Face lip-sync chain
//! (after resampling to 16 kHz). Each blendshape produced by Audio2Face
//! synchronously renders one Video frame in `live2d_render`, stamped
//! with the audio-time pts so the audio track and video track stay
//! in lip-sync end-to-end.
//!
//! Control-bus endpoints exposed to the browser (same as the non-avatar
//! variant, plus the new video stream):
//!
//! - subscribe `vad.out`            — per-chunk speech state
//! - subscribe `stt_in.out`         — user transcript
//! - subscribe `audio.out`          — LLM token stream + TTS audio envelopes
//! - subscribe `coordinator.out`    — authoritative turn_state events
//! - publish `audio.in.barge_in`    — interrupt generation
//! - publish `audio.in.reset`       — wipe chat history
//!
//! # Required model assets
//!
//! - `LIVE2D_CUBISM_CORE_DIR`   (build-time) — unpacked Cubism SDK for Native.
//!                                             **Must be an absolute path** —
//!                                             cubism-core-sys's build script
//!                                             runs in a different cwd than
//!                                             cargo, so relative paths fail.
//! - `LIVE2D_AVATAR_MODEL_PATH` (runtime)    — path to the `.model3.json`
//!                                             (NOT the `.moc3` binary).
//! - `AUDIO2FACE_BUNDLE_PATH`   (runtime)    — directory with the persona-engine
//!                                             Audio2Face bundle (network.onnx,
//!                                             bs_skin_<Identity>.npz, etc.)
//!
//! # Usage
//!
//! ```bash
//! # All paths must be absolute. From the workspace root:
//! LIVE2D_CUBISM_CORE_DIR="$(pwd)/sdk/CubismSdkForNative-5-r.5" \
//! LIVE2D_AVATAR_MODEL_PATH="$(pwd)/models/live2d/aria/aria.model3.json" \
//! AUDIO2FACE_BUNDLE_PATH="$(pwd)/models/audio2face" \
//! QWEN_MODEL_PATH="$(pwd)/models/UD-Q4_K_XL.gguf" \
//! cargo run -p remotemedia-webrtc \
//!     --example qwen_s2s_avatar_webrtc_server \
//!     --features ws-signaling,avatar -- --port 8082
//! ```

#![cfg(feature = "ws-signaling")]

use remotemedia_core::manifest::{
    Connection, Manifest, ManifestMetadata, ManifestPythonEnv, NodeManifest,
};
use remotemedia_core::transport::{ExecutorConfig, PipelineExecutor};
use remotemedia_webrtc::config::WebRtcTransportConfig;
use remotemedia_webrtc::signaling::WebSocketSignalingServer;
use std::sync::Arc;

// Force-link remotemedia-python-nodes so its `inventory::submit!` macro
// pulls Python node factories (WhisperSTTNode, KokoroTTSNode, …) into
// the default streaming registry.
#[allow(unused_imports)]
use remotemedia_python_nodes as _python_nodes_link;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn parse_env_u32(key: &str) -> Option<u32> {
    std::env::var(key).ok().and_then(|v| v.parse().ok())
}

fn parse_env_f32(key: &str) -> Option<f32> {
    std::env::var(key).ok().and_then(|v| v.parse().ok())
}

fn parse_env_bool(key: &str) -> Option<bool> {
    std::env::var(key)
        .ok()
        .and_then(|v| match v.to_lowercase().as_str() {
            "true" | "1" | "yes" => Some(true),
            "false" | "0" | "no" => Some(false),
            _ => None,
        })
}

fn parse_gpu_offload(val: &str) -> serde_json::Value {
    match val.to_lowercase().as_str() {
        "none" | "0" | "cpu" => serde_json::json!("none"),
        "all" | "gpu" => serde_json::json!("all"),
        n => {
            if let Ok(layers) = n.parse::<u16>() {
                serde_json::json!({ "layers": layers })
            } else {
                serde_json::json!("all")
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Manifest builder
// ---------------------------------------------------------------------------

fn build_manifest() -> Result<Manifest, Box<dyn std::error::Error>> {
    // ---- Avatar engine (live2d | cc) ----
    //
    // `AVATAR_ENGINE=cc` switches the renderer node from
    // `Live2DRenderNode` to `CcRenderNode` (Bevy/glTF). The CC engine
    // requires the `avatar-render-cc` Cargo feature on remotemedia-core
    // (default OFF) — when this is `cc` and the feature isn't compiled
    // in, the registry will reject `CcRenderNode` at session start.
    let engine = std::env::var("AVATAR_ENGINE")
        .unwrap_or_else(|_| "live2d".into())
        .to_ascii_lowercase();
    let use_cc = matches!(engine.as_str(), "cc" | "cc5" | "bevy");

    // Renderer node id matches the actual engine so log lines and
    // `barge_in_targets` aren't lying about what's running. Connections
    // and timeouts below all key off this string.
    let renderer_node_id: &'static str = if use_cc { "cc_render" } else { "live2d_render" };

    // Kimodo body-motion engine: text prompt → SMPL-22 skeletal pose
    // stream → CcRenderNode. Opt-in via `MOTION_ENGINE=kimodo`; only
    // wired when `AVATAR_ENGINE=cc` because Live2D doesn't have a
    // skeleton to drive. Computed early so the LLM-prompt + tool
    // wiring below can branch on it.
    let use_kimodo = use_cc
        && std::env::var("MOTION_ENGINE")
            .map(|v| v.eq_ignore_ascii_case("kimodo"))
            .unwrap_or(false);

    // ---- Avatar asset paths (required, depending on engine) ----

    let audio2face_bundle = std::env::var("AUDIO2FACE_BUNDLE_PATH").map_err(|_| {
        "AUDIO2FACE_BUNDLE_PATH not set; point at the persona-engine \
         Audio2Face bundle directory (network.onnx + bs_skin_*.npz + …)"
    })?;
    if !std::path::Path::new(&audio2face_bundle).exists() {
        return Err(format!(
            "AUDIO2FACE_BUNDLE_PATH not found on disk: {}",
            audio2face_bundle
        )
        .into());
    }

    let live2d_model = if !use_cc {
        let p = std::env::var("LIVE2D_AVATAR_MODEL_PATH").map_err(|_| {
            "LIVE2D_AVATAR_MODEL_PATH not set; point at e.g. \
             models/live2d/aria/aria.model3.json (NOT the .moc3 binary)"
        })?;
        if !std::path::Path::new(&p).exists() {
            return Err(format!("LIVE2D_AVATAR_MODEL_PATH not found on disk: {}", p).into());
        }
        p
    } else {
        String::new()
    };
    let (cc_glb_path, cc_arkit_map_path) = if use_cc {
        let glb = std::env::var("CC_AVATAR_GLB_PATH").map_err(|_| {
            "CC_AVATAR_GLB_PATH not set; point at e.g. \
             avatars/<name>.alphabaked.glb (see avatars/README.md)"
        })?;
        let map = std::env::var("CC_AVATAR_ARKIT_MAP_PATH").map_err(|_| {
            "CC_AVATAR_ARKIT_MAP_PATH not set; point at e.g. \
             avatars/<name>.arkit_map.resolved.json"
        })?;
        if !std::path::Path::new(&glb).exists() {
            return Err(format!("CC_AVATAR_GLB_PATH not found on disk: {}", glb).into());
        }
        if !std::path::Path::new(&map).exists() {
            return Err(format!("CC_AVATAR_ARKIT_MAP_PATH not found on disk: {}", map).into());
        }
        (glb, map)
    } else {
        (String::new(), String::new())
    };

    // ---- LLM (llama.cpp / GGUF) ----

    let default_system_prompt = "You are a helpful, friendly voice assistant. \
You speak conversationally and keep responses concise. \
When the user asks for code, commands, or structured data, provide it \
in markdown code blocks. Otherwise, respond in natural prose. \
Express emotion using emoji at the start of sentences (e.g. 🤩, 😊, 😢, 🤔).";

    // Extra prompt clauses appended when the perform_motion tool is wired
    // (cc engine + kimodo). Tells the model to actually call the tool
    // instead of narrating the action in *asterisks* (`*waves*`) — those
    // get spoken aloud by the TTS and never become real animation.
    let motion_prompt_clause = " You can make the avatar physically move \
by calling the `perform_motion` tool with a natural-language description \
of the action (e.g. \"a person waves the right hand\"). Whenever the user \
asks the avatar to wave, point, sit, dance, walk, gesture, or perform any \
physical action — call `perform_motion` instead of describing the action \
in narration. Never write the action between asterisks (e.g. *waves*) — \
the user sees the rendered motion, not the narration. You may speak and \
move at the same time.";

    let model_path = std::env::var("QWEN_MODEL_PATH")
        .unwrap_or_else(|_| "unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL".to_string());

    let gpu_offload = std::env::var("QWEN_GPU_OFFLOAD").unwrap_or_else(|_| "all".to_string());

    let flash_attention = parse_env_bool("QWEN_FLASH_ATTENTION").unwrap_or(true);

    // Compose the system prompt up-front so both the in-process
    // LlamaCpp path AND the OpenAI-compatible path see the same
    // `motion_prompt_clause`-augmented prompt when kimodo is on.
    // Previously the in-process branch saw only the bare system
    // prompt (no perform_motion guidance) and the OpenAI branch
    // built its own — making the in-process model's tool-call rate
    // worse than the external server's even with identical tools.
    let user_prompt_env = std::env::var("QWEN_SYSTEM_PROMPT").ok();
    let resolved_system_prompt = match user_prompt_env.as_deref() {
        Some(p) => p.to_string(),
        None if use_kimodo => format!("{}{}", default_system_prompt, motion_prompt_clause),
        None => default_system_prompt.to_string(),
    };

    // The `perform_motion` ToolSpec advertised to the model. Only
    // wired when kimodo is downstream — without a consumer for the
    // dispatched motion_intent envelope the call would drop on the
    // floor. The schema is identical for both LlamaCppGenerationNode
    // (tools field, parsed Qwen3 `<tool_call>` blocks) and
    // OpenAIChatNode (tools field, OpenAI delta.tool_calls stream).
    //
    // `cancelable: false` instructs the chat backend (OpenAI path)
    // to take a `ProtectGuard` off the per-call cancel gate as soon
    // as a streamed delta names this tool, so a late VAD blip can't
    // abort the motion mid-dispatch — see `tool_spec.rs::default_motion_tool`
    // and avatar.log timeline at 22:56:54 → 22:57:37 for the
    // original incident. The in-process llama.cpp path batches
    // chunks at end-of-turn so the guard isn't load-bearing there;
    // the field is still set for symmetry / future live-streaming.
    let perform_motion_tool = serde_json::json!({
        "name": "perform_motion",
        "description": "Make the avatar perform a physical full-body \
    motion or gesture. The REQUIRED `prompt` parameter is a natural-language description \
    of what the body should do — name the limbs and the action explicitly. Do NOT use \
    this for facial expressions (those come from emoji in your spoken text). Do NOT \
    narrate the action in *asterisks* in your speech if you call this tool — the user \
    sees the motion, not the narration.\n\nExamples of good prompts:\n  \
    - \"a person waves with the right hand at shoulder height\"\n  \
    - \"a person sits down slowly on a chair\"\n  \
    - \"a person points to the left with the right arm\"\n  \
    - \"a person nods their head once\"\n  \
    - \"a person dances briefly in place\"\n\nUse this whenever the user asks the avatar \
    to move, gesture, greet, sit, walk, dance, point, nod, shake their head, or any \
    other physical action. You may call this in parallel with `say` to speak while moving.",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "Natural-language description of the \
    full-body motion. Should mention the body parts involved and the action verb. MUST be a \
    non-empty string. Example: \"a person waves the right hand enthusiastically\".",
                    "minLength": 1
                }
            },
            "required": ["prompt"]
        },
        "kind": "side_effect",
        "cancelable": false
    });
    let tools_array = if use_kimodo {
        serde_json::json!([perform_motion_tool])
    } else {
        serde_json::json!([])
    };
    // Without an explicit tool_choice, several local servers
    // (llama-server, llama-swap, vLLM with custom templates)
    // default to "none" when the field is omitted, which silently
    // drops the tools array from the prompt the model actually
    // sees. The model then has no tool definition, ignores the
    // system prompt's "call perform_motion" instruction, and
    // narrates the action in *asterisks*. `"auto"` matches OpenAI's
    // documented default and works with both Qwen3 templates
    // (in-process llama.cpp) and llama-server's `--jinja` parser.
    let tool_choice = if use_kimodo {
        Some(serde_json::Value::String("auto".to_string()))
    } else {
        None
    };

    let mut llm_params = serde_json::json!({
        "model_path": model_path,
        "backend": {
            "numa": false,
            "gpu_offload": parse_gpu_offload(&gpu_offload),
            "flash_attention": flash_attention,
            "threads": parse_env_u32("QWEN_THREADS"),
            "threads_batch": null,
        },
        "context_size": parse_env_u32("QWEN_CONTEXT_SIZE").unwrap_or(8192),
        "batch_size": 2048,
        "max_tokens": parse_env_u32("QWEN_MAX_TOKENS").unwrap_or(2048),
        "temperature": parse_env_f32("QWEN_TEMPERATURE").unwrap_or(0.6),
        "top_p": parse_env_f32("QWEN_TOP_P").unwrap_or(0.8),
        "top_k": parse_env_u32("QWEN_TOP_K").unwrap_or(20),
        "min_p": parse_env_f32("QWEN_MIN_P").unwrap_or(0.0),
        "repeat_penalty": 1.1,
        "system_prompt": resolved_system_prompt.clone(),
        "seed": 0,
        // Forward tools/tool_choice to the in-process node so the
        // GGUF's Jinja template emits the `# Tools` system block and
        // `LlamaCppGenerationNode` post-processes `<tool_call>...
        // </tool_call>` outputs through `tool_dispatch::dispatch_tool_call`.
        // Without these the in-process model is tool-unaware and
        // narrates motions instead of calling perform_motion.
        "tools": tools_array.clone(),
    });
    if let Some(tc) = tool_choice.as_ref() {
        llm_params["tool_choice"] = tc.clone();
    }

    // When QWEN_LLM_URL is set, route to an external OpenAI-compatible
    // server (llama-server, llama-swap, vLLM, Ollama) instead of loading
    // the GGUF in-process. Avoids a duplicate model load when the GGUF
    // is already hosted by another process.
    //
    //   QWEN_LLM_URL    base URL including /v1
    //                   (e.g. http://127.0.0.1:8888/v1 for llama-swap)
    //   QWEN_LLM_MODEL  model id served at that URL
    //                   (default: "Qwen3.6-27B")
    let (llm_node_type, llm_params) = match std::env::var("QWEN_LLM_URL").ok() {
        Some(base_url) => {
            let model =
                std::env::var("QWEN_LLM_MODEL").unwrap_or_else(|_| "Qwen3.6-27B".to_string());

            let mut openai_params = serde_json::json!({
                "base_url": base_url,
                "model": model,
                "system_prompt": resolved_system_prompt,
                "max_tokens": parse_env_u32("QWEN_MAX_TOKENS").unwrap_or(2048),
                "temperature": parse_env_f32("QWEN_TEMPERATURE").unwrap_or(0.6),
                "top_p": parse_env_f32("QWEN_TOP_P").unwrap_or(0.8),
                "streaming": true,
                "tools": tools_array,
            });
            if let Some(tc) = tool_choice {
                openai_params["tool_choice"] = tc;
            }
            ("OpenAIChatNode", openai_params)
        }
        None => ("LlamaCppGenerationNode", llm_params),
    };

    // ---- Whisper STT ----

    let whisper_params = serde_json::json!({
        "model_id": "openai/whisper-base.en",
        "language": "en",
        "device": "cuda:0",
        "torch_dtype": "float16",
    });
    let whisper_deps = vec![
        "transformers>=4.40.0".to_string(),
        "torch>=2.1".to_string(),
        "accelerate>=0.33".to_string(),
    ];

    // ---- Kokoro TTS (24 kHz output; resampled both ways downstream) ----

    let kokoro_params = serde_json::json!({
        "lang_code": std::env::var("KOKORO_LANG").unwrap_or_else(|_| "a".to_string()),
        "voice": std::env::var("KOKORO_VOICE").unwrap_or_else(|_| "af_heart".to_string()),
        "speed": 1.0,
        "sample_rate": 24000,
        "stream_chunks": true,
        "skip_tokens": ["<|text_end|>", "```"],
    });
    let kokoro_deps = vec![
        "kokoro>=0.9.4".to_string(),
        "soundfile".to_string(),
        "en-core-web-sm @ https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl".to_string(),
    ];

    // ---- Avatar video size ----

    let avatar_width = parse_env_u32("AVATAR_WIDTH").unwrap_or(512);
    let avatar_height = parse_env_u32("AVATAR_HEIGHT").unwrap_or(512);

    // ---- Nodes ----

    let mut nodes: Vec<NodeManifest> = vec![
        // --- Audio input pipeline (mic → VAD → STT → LLM → coordinator) ---
        NodeManifest {
            id: "resample_in".to_string(),
            node_type: "FastResampleNode".to_string(),
            params: serde_json::json!({
                "source_rate": 48000,
                "target_rate": 16000,
                "quality": "Medium",
                "channels": 1,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "chunker".to_string(),
            node_type: "AudioChunkerNode".to_string(),
            params: serde_json::json!({ "chunkSize": 512 }),
            ..Default::default()
        },
        NodeManifest {
            id: "vad".to_string(),
            node_type: "SileroVADNode".to_string(),
            params: serde_json::json!({
                "threshold": 0.6,
                "neg_threshold": 0.35,
                "sample_rate": 16000,
                "min_speech_duration_ms": 250,
                "min_silence_duration_ms": 500,
                "speech_pad_ms": 150,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "accumulator".to_string(),
            node_type: "AudioBufferAccumulatorNode".to_string(),
            params: serde_json::json!({
                "min_utterance_duration_ms": 300,
                "max_utterance_duration_ms": 30000,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "stt_in".to_string(),
            node_type: "WhisperSTTNode".to_string(),
            params: whisper_params,
            python_deps: Some(whisper_deps),
            ..Default::default()
        },
        NodeManifest {
            id: "llm".to_string(),
            node_type: llm_node_type.to_string(),
            params: llm_params,
            ..Default::default()
        },
        NodeManifest {
            id: "coordinator".to_string(),
            node_type: "ConversationCoordinatorNode".to_string(),
            params: serde_json::json!({
                "split_pattern": r"[.!?,;:\n]+",
                "min_sentence_length": 2,
                "yield_partial_on_end": true,
                "llm_silence_timeout_ms": 120000,
                "user_speech_debounce_ms": 150,
                // Barge targets: stop both LLM generation, TTS, and reset
                // the avatar's lip-sync state so the previous turn's
                // mouth animation doesn't bleed into the next.
                "barge_in_targets": ["llm", "kokoro_tts", "audio2face_lipsync", renderer_node_id],
                "first_chunk_min_chars": 25,
            }),
            ..Default::default()
        },
        // --- Avatar pipeline ---
        // Splits the LLM text into a clean text stream + emoji-derived
        // emotion JSON envelopes. Text → kokoro_tts; emotion → live2d_render.
        NodeManifest {
            id: "emotion_extractor".to_string(),
            node_type: "EmotionExtractorNode".to_string(),
            params: serde_json::json!({}),
            ..Default::default()
        },
        NodeManifest {
            id: "kokoro_tts".to_string(),
            node_type: "KokoroTTSNode".to_string(),
            params: kokoro_params,
            python_deps: Some(kokoro_deps),
            ..Default::default()
        },
        // Audio sink: takes the audio2face-passthrough 16 kHz stream
        // and resamples 16→48 kHz for the WebRTC audio track. Named
        // "audio" by convention so WebRTC adapts it as the audio sink
        // (matches the non-avatar variant).
        //
        // We deliberately put this DOWNSTREAM of audio2face (rather
        // than tapping kokoro directly) so the audio the listener
        // hears travels the same chain that produces the lip-sync
        // blendshapes — there's a single point in the pipeline where
        // the audio + face pose stream divide. Routing kokoro
        // straight to the sink decoupled them and caused the audio
        // to outrun the mouth by audio2face's inference latency
        // (~700 ms on CPU, more if a chunk is bigger than one
        // inference window).
        NodeManifest {
            id: "audio".to_string(),
            node_type: "FastResampleNode".to_string(),
            params: serde_json::json!({
                "source_rate": 16000,
                "target_rate": 48000,
                "quality": "Medium",
                "channels": 1,
                // Force-stamp + advertise a dedicated 48 kHz outbound
                // audio track. Without this every audio-producing node in
                // the manifest claims `stream_id="default"`; the scanner
                // keeps the FIRST one (chunker, the 16 kHz mic input
                // chain) and binds the WebRTC peer's outbound track to
                // it. The TTS chain's chunks then route to the wrong
                // 16 kHz track and stall the sink (4864 fan_tx drops in
                // the prior session). Naming the avatar's audio sink
                // explicitly gives it its own track + routing key.
                "audio_stream_id": "avatar",
            }),
            ..Default::default()
        },
        // 24 kHz Kokoro audio → 16 kHz for Audio2Face inference.
        // The audio sink also reads from audio2face's 16 kHz
        // passthrough output (see "audio" node above), so the
        // listener hears exactly the audio that drives the lip-sync.
        NodeManifest {
            id: "resample_a2f".to_string(),
            node_type: "FastResampleNode".to_string(),
            params: serde_json::json!({
                "source_rate": 24000,
                "target_rate": 16000,
                "quality": "Medium",
                "channels": 1,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "audio2face_lipsync".to_string(),
            node_type: "Audio2FaceLipSyncNode".to_string(),
            params: serde_json::json!({
                "bundle_path": audio2face_bundle,
                "identity": std::env::var("AUDIO2FACE_IDENTITY")
                    .unwrap_or_else(|_| "Claire".to_string()),
                "solver": std::env::var("AUDIO2FACE_SOLVER")
                    .unwrap_or_else(|_| "pgd".to_string()),
                // Default ON: the workspace's ort ships with CUDA +
                // CoreML execution providers compiled in, and the
                // inference loader falls back CUDA → CoreML → CPU
                // automatically. Opt out with AUDIO2FACE_USE_GPU=false.
                "use_gpu": parse_env_bool("AUDIO2FACE_USE_GPU").unwrap_or(true),
                "smoothing_alpha": parse_env_f32("AUDIO2FACE_SMOOTHING")
                    .unwrap_or(0.0),
                // CcRenderNode's pose channel is a `tokio::watch`
                // (latest-wins) — without per-emission pacing, all 30
                // frames from a 1 s inference window collapse to the
                // last one and the mouth jumps end-of-window each
                // second. Re-enable pacing until the renderer moves to
                // a pts-keyed pose lookup; the IPC back-pressure risk
                // is bounded because audio2face's process_streaming
                // task is its own tokio task and the per-frame sleep
                // only blocks that one.
                "pace_realtime": true,
            }),
            ..Default::default()
        },
        // Renderer + video sink. Emits RuntimeData::Video with stream_id
        // = "avatar"; the WebRTC server attaches a VideoTrack for it.
        // Node id stays "live2d_render" regardless of engine so the
        // session router's `barge_in_targets` and downstream
        // connections don't need to branch.
        if use_cc {
            NodeManifest {
                id: renderer_node_id.to_string(),
                node_type: "CcRenderNode".to_string(),
                params: serde_json::json!({
                    "glb_path": cc_glb_path,
                    "arkit_map_path": cc_arkit_map_path,
                    "framerate": 30,
                    "video_stream_id": "avatar",
                    "width": avatar_width,
                    "height": avatar_height,
                    // Emit Video frames as soon as the scene is ready,
                    // not blocked on first audio + first blendshape.
                    // Audio is routed via the separate `audio` resample
                    // node so we never need A+V pairing here.
                    "realtime_mode": true,
                }),
                ..Default::default()
            }
        } else {
            NodeManifest {
                id: renderer_node_id.to_string(),
                node_type: "Live2DRenderNode".to_string(),
                params: serde_json::json!({
                    "model_path": live2d_model,
                    "framerate": 30,
                    "video_stream_id": "avatar",
                    "width": avatar_width,
                    "height": avatar_height,
                }),
                ..Default::default()
            }
        },
        // Avatar motion-intent bridge. The browser publishes JSON like
        // `{"action":"walk_to","object_id":"Sofa","speed_mps":1.2}` to
        // `avatar_intent.in` over the Session Control Bus; this node
        // appends each accepted intent as one NDJSON line to the file
        // tailed by `examples/avatar-render-proto`'s IntentWatcher.
        // Echoed on `avatar_intent.out` for observer feedback.
        NodeManifest {
            id: "avatar_intent".to_string(),
            node_type: "AvatarIntentTapNode".to_string(),
            params: serde_json::json!({
                "intents_path": std::env::var("AVATAR_INTENTS_PATH")
                    .unwrap_or_else(|_| "/tmp/avatar_intents.ndjson".to_string()),
                "truncate_on_start": true,
            }),
            ..Default::default()
        },
    ];

    // `use_kimodo` is computed earlier (above the LLM-tool wiring).
    // Kimodo body-motion engine: text prompt → SMPL-22 skeletal pose
    // stream → CcRenderNode. Requires `external/kimodo/.venv` (run
    // scripts/avatars/kimodo_install.sh once).
    if use_kimodo {
        // Quantization wiring. We default LLM2VEC_QUANTIZE to "nf4"
        // here (mirroring scripts/run-avatar-s2s.sh) so the daemon
        // ALWAYS loads ~5GB-VRAM 4-bit weights regardless of how the
        // process was launched — IDE, `cargo run`, manifest tester,
        // CI. The KimodoMotionNode also defaults to nf4 internally;
        // forwarding the env value here keeps the manifest the
        // single source of truth so warm sessions and explicit
        // overrides agree.
        let llm2vec_quantize = std::env::var("LLM2VEC_QUANTIZE")
            .ok()
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| "nf4".to_string());
        let quant_off = matches!(
            llm2vec_quantize.to_ascii_lowercase().as_str(),
            "none" | "off" | "false" | "0",
        );
        // Default text_encoder_device follows the quantization mode:
        // 4-bit/8-bit weights need CUDA, bf16 falls back to cpu.
        let text_encoder_device = std::env::var("TEXT_ENCODER_DEVICE")
            .ok()
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| {
                if quant_off {
                    "cpu".to_string()
                } else {
                    "cuda:0".to_string()
                }
            });
        let mut kimodo_params = serde_json::json!({
            // Diffusion-step knob: 25 is the lowest count that still
            // produces clean motion on this pipeline; 50 doubles the
            // wall-clock cost for a marginal quality bump and 100 is
            // the original demo default. Override with KIMODO_DIFFUSION_STEPS.
            "diffusion_steps": std::env::var("KIMODO_DIFFUSION_STEPS")
                .ok()
                .and_then(|s| s.parse::<i64>().ok())
                .unwrap_or(25),
            "model": std::env::var("KIMODO_MODEL")
                .unwrap_or_else(|_| "Kimodo-SOMA-RP-v1.1".to_string()),
            "text_encoder_device": text_encoder_device,
            "llm2vec_quantize": llm2vec_quantize,
            // Pace pose envelopes at native fps so the renderer
            // doesn't get a 4-second clip in a single tick.
            "pace_realtime": true,
        });
        // Forward pre-quantized local export paths if the shell
        // detected them (~/llm2vec-nf4 or ~/.cache/kimodo_qbench/...).
        // The node also auto-detects internally, but threading them
        // explicitly here surfaces the resolved path in pipeline
        // diagnostics and survives subprocess env scrubbing.
        if let Ok(base) = std::env::var("LLM2VEC_LOCAL_BASE") {
            if !base.is_empty() {
                kimodo_params["llm2vec_local_base"] = base.into();
            }
        }
        if let Ok(peft) = std::env::var("LLM2VEC_LOCAL_PEFT") {
            if !peft.is_empty() {
                kimodo_params["llm2vec_local_peft"] = peft.into();
            }
        }
        nodes.push(NodeManifest {
            id: "kimodo_motion".to_string(),
            node_type: "KimodoMotionNode".to_string(),
            params: kimodo_params,
            ..Default::default()
        });
    }

    // ---- Connections ----

    let mut connections: Vec<Connection> = vec![
        // Input → VAD
        Connection {
            from: "resample_in".into(),
            to: "chunker".into(),
            ..Default::default()
        },
        Connection {
            from: "chunker".into(),
            to: "vad".into(),
            ..Default::default()
        },
        Connection {
            from: "vad".into(),
            to: "accumulator".into(),
            ..Default::default()
        },
        // Coordinator watches VAD events for barge detection
        Connection {
            from: "vad".into(),
            to: "coordinator".into(),
            ..Default::default()
        },
        // STT → LLM → coordinator
        Connection {
            from: "accumulator".into(),
            to: "stt_in".into(),
            ..Default::default()
        },
        Connection {
            from: "stt_in".into(),
            to: "llm".into(),
            ..Default::default()
        },
        Connection {
            from: "llm".into(),
            to: "coordinator".into(),
            ..Default::default()
        },
        // Coordinator → emotion extraction
        Connection {
            from: "coordinator".into(),
            to: "emotion_extractor".into(),
            ..Default::default()
        },
        // Emotion extractor splits into two streams:
        //   - text → kokoro_tts (the audio we synthesize)
        //   - emotion json → live2d_render (sets expression/motion)
        Connection {
            from: "emotion_extractor".into(),
            to: "kokoro_tts".into(),
            ..Default::default()
        },
        Connection {
            from: "emotion_extractor".into(),
            to: renderer_node_id.into(),
            ..Default::default()
        },
        // Kokoro audio path:
        //   kokoro_tts → resample_a2f (24→16 kHz)
        //              → audio2face_lipsync (audio passthrough + blendshape Json)
        //              → live2d_render (CcRenderNode: buffers audio, applies
        //                blendshapes to Bevy, emits paired V+A in tick())
        //              → audio (resample 16→48 kHz)
        //              → WebRTC audio sink
        //
        // CcRenderNode is the single pacer: it drives both V and A
        // off the same frame_number counter at fps rate, so the
        // audio chunks the listener hears advance in lockstep with
        // the rendered face animation. There's no longer a
        // shortcut from kokoro/audio2face directly to the audio
        // sink — that decoupling was what caused the
        // audio-leads-mouth lipsync drift.
        //
        // FastResampleNode passes non-Audio (Video, Json) through
        // unchanged, so the V frames CcRenderNode emits get
        // forwarded to the WebRTC video sink intact.
        Connection {
            from: "kokoro_tts".into(),
            to: "resample_a2f".into(),
            ..Default::default()
        },
        Connection {
            from: "resample_a2f".into(),
            to: "audio2face_lipsync".into(),
            ..Default::default()
        },
        Connection {
            from: "audio2face_lipsync".into(),
            to: renderer_node_id.into(),
            ..Default::default()
        },
        Connection {
            from: renderer_node_id.into(),
            to: "audio".into(),
            ..Default::default()
        },
    ];

    // (Historically there was a `vad → live2d_render` heartbeat edge
    // here so CcRenderNode would get a wall-clock trigger to drain
    // Bevy's frame buffer even while audio2face was idle. The
    // ClockedToOutboundMedia Pacer now drives `tick()` at config.fps
    // unconditionally, so the heartbeat is redundant. Removed because
    // it was also feeding the *user's microphone* into CcRenderNode's
    // audio_buf — which then drained back out through the
    // `live2d_render → audio → webrtc` audio sink, looping the
    // listener's voice back to themselves. Only audio2face_lipsync
    // (TTS path) should feed the renderer's audio buffer.)

    // Kimodo body-motion edges: avatar_intent's echoed JSON output
    // feeds KimodoMotionNode (which filters to `kind == "motion_intent"`
    // and silently drops other intent kinds like `walk_to`). Generated
    // skeletal_pose envelopes flow into the CC renderer.
    //
    // Browsers publish motion_intent JSONs to `avatar_intent.in` via
    // the Session Control Bus; AvatarIntentTapNode echoes accepted
    // intents on its forward output. The LLM publishes motion intents
    // by calling the `perform_motion` tool — `tool_dispatch.rs`
    // emits `RuntimeData::Json({kind:"motion_intent", prompt:<arg>})`
    // on the LLM's fan-out, so we add a direct `llm → kimodo_motion`
    // edge. Kimodo's `_parse_intent` ignores any envelope without a
    // valid `prompt`, so streaming text tokens passing through this
    // edge are no-ops.
    if use_kimodo {
        connections.extend([
            Connection {
                from: "avatar_intent".into(),
                to: "kimodo_motion".into(),
                ..Default::default()
            },
            Connection {
                from: "llm".into(),
                to: "kimodo_motion".into(),
                ..Default::default()
            },
            Connection {
                from: "kimodo_motion".into(),
                to: renderer_node_id.into(),
                ..Default::default()
            },
        ]);
    }

    // ---- Optional debug taps ----
    //
    // When `AVATAR_DEBUG_TAP_DIR` is set, fan-out three points on the
    // mic+TTS path into AudioFileWriterNodes. Use this to localize
    // where audio dies when VAD doesn't fire:
    //
    //   * `tap_mic_16k.wav`   — mic samples after FastResample 48→16k.
    //                           Empty/missing → mic RTP isn't reaching
    //                           the pipeline (server-side decode broken).
    //   * `tap_vad_audio.wav` — pass-through audio out of SileroVAD.
    //                           Has bytes but vad.out is silent → VAD
    //                           is dropping below threshold.
    //   * `tap_tts.wav`       — Kokoro TTS output (24 kHz). Has bytes →
    //                           TTS pipeline is healthy; problem is
    //                           upstream (LLM never produced text).
    //
    // The taps are pass-through nodes, so attaching them is non-invasive.
    if let Ok(dir) = std::env::var("AVATAR_DEBUG_TAP_DIR") {
        let dir = std::path::PathBuf::from(dir);
        std::fs::create_dir_all(&dir).ok();
        eprintln!(
            "[debug] AVATAR_DEBUG_TAP_DIR={} — wiring 3 WAV taps",
            dir.display()
        );

        let tap = |id: &str, fname: &str| NodeManifest {
            id: id.to_string(),
            node_type: "AudioFileWriterNode".to_string(),
            params: serde_json::json!({
                "output_path": dir.join(fname).to_string_lossy().to_string(),
            }),
            ..Default::default()
        };
        nodes.push(tap("tap_mic", "tap_mic_16k.wav"));
        nodes.push(tap("tap_vad", "tap_vad_audio.wav"));
        nodes.push(tap("tap_tts", "tap_tts.wav"));

        connections.extend([
            Connection {
                from: "resample_in".into(),
                to: "tap_mic".into(),
                ..Default::default()
            },
            Connection {
                from: "vad".into(),
                to: "tap_vad".into(),
                ..Default::default()
            },
            Connection {
                from: "kokoro_tts".into(),
                to: "tap_tts".into(),
                ..Default::default()
            },
        ]);
    }

    Ok(Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "qwen-llama-s2s-avatar-webrtc".to_string(),
            description: Some(
                "Speech-to-speech with Live2D avatar lip-sync: \
                 Whisper → Qwen3.6-27B-GGUF → Kokoro TTS → Audio2Face → \
                 Live2D (Aria) over WebRTC"
                    .to_string(),
            ),
            ..Default::default()
        },
        nodes,
        connections,
        python_env: Some(ManifestPythonEnv {
            python_version: Some("3.12".to_string()),
            scope: None,
            extra_deps: Vec::new(),
        }),
    })
}

// ---------------------------------------------------------------------------
// Python env defaults
// ---------------------------------------------------------------------------

fn default_python_env() {
    let ensure = |k: &str, v: &str| {
        if std::env::var_os(k).is_none() {
            std::env::set_var(k, v);
        }
    };
    ensure("PYTHON_ENV_MODE", "managed");
    ensure("PYTHON_VERSION", "3.12");

    if std::env::var_os("REMOTEMEDIA_PYTHON_SRC").is_none() {
        let manifest_dir = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let candidate = manifest_dir
            .ancestors()
            .nth(3)
            .map(|root| root.join("clients").join("python"));
        if let Some(path) = candidate {
            if path.exists() {
                std::env::set_var("REMOTEMEDIA_PYTHON_SRC", path);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    default_python_env();

    // Avatar pipeline log hygiene. The chatty offenders:
    //   * wgpu_core::device::resource: `Device::maintain: waiting for
    //     submission index N` — fires at INFO on every readback,
    //     i.e. ≥30/s during animation.
    //   * wgpu_hal / wgpu / naga — startup INFO spam.
    //   * remotemedia_webrtc::peer::server_peer — DEBUG per-frame
    //     "Sending video frame" / "Video sent successfully".
    //   * mio / webrtc_* — verbose at DEBUG.
    //
    // We always *append* these silencers to whatever the user set in
    // `RUST_LOG`, so a `RUST_LOG=info` from the run script doesn't
    // re-enable the wgpu firehose. Users who genuinely want it can set
    // `RUST_LOG=info,wgpu_core=info` and the later directive wins.
    // The `lipsync.delta` target stays at INFO so the audio↔animation
    // drift is the dominant signal.
    const SILENCERS: &str = ",\
        wgpu_core=warn,\
        wgpu_hal=warn,\
        wgpu=warn,\
        naga=warn,\
        webrtc_ice=info,\
        webrtc_dtls=info,\
        webrtc_sctp=info,\
        webrtc_srtp=info,\
        webrtc_mdns=info,\
        webrtc_util=info,\
        mio=info,\
        remotemedia_webrtc::peer::server_peer=info";
    let env_directives = std::env::var("RUST_LOG").unwrap_or_else(|_| "info".to_string());
    let combined_filter = format!("{env_directives}{SILENCERS}");
    let _ = tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::new(combined_filter))
        .with_writer(std::io::stderr)
        .try_init();

    let mut args = std::env::args().skip(1);
    let mut port: u16 = 8082;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--port" | "-p" => {
                port = args
                    .next()
                    .ok_or("--port requires a value")?
                    .parse()
                    .map_err(|e| format!("bad --port: {e}"))?;
            }
            "--host" => {
                let _ = args.next().ok_or("--host requires a value")?;
            }
            "-h" | "--help" => {
                eprintln!(
                    "qwen_s2s_avatar_webrtc_server [--host ADDR] [--port PORT]\n\n\
                     S2S with Live2D avatar lip-sync:\n  \
                     Whisper STT → Qwen3.6-27B-GGUF (llama.cpp) → Kokoro TTS\n  \
                     → Audio2Face (ONNX) → Live2D (Aria) over WebRTC\n\n\
                     required env (use ABSOLUTE paths — relative paths fail in build scripts):\n  \
                     LIVE2D_AVATAR_MODEL_PATH  path to .model3.json (NOT .moc3)\n  \
                     AUDIO2FACE_BUNDLE_PATH    persona-engine Audio2Face bundle dir\n  \
                     LIVE2D_CUBISM_CORE_DIR    Cubism SDK for Native (build-time, absolute)\n\n\
                     env (optional):\n  \
                     QWEN_MODEL_PATH         GGUF model path (default: unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL)\n  \
                     QWEN_SYSTEM_PROMPT      System message\n  \
                     QWEN_CONTEXT_SIZE       Context window in tokens (default: 8192)\n  \
                     QWEN_MAX_TOKENS         Max tokens per generation (default: 2048)\n  \
                     QWEN_GPU_OFFLOAD        GPU offload: none, all, or layer count (default: all)\n  \
                     QWEN_FLASH_ATTENTION    Enable Flash Attention 2 (default: true)\n  \
                     QWEN_THREADS            Computation threads (default: auto)\n  \
                     QWEN_TEMPERATURE        Sampling temperature (default: 0.6)\n  \
                     QWEN_TOP_P              Nucleus sampling cutoff (default: 0.8)\n  \
                     QWEN_TOP_K              Top-k sampling cutoff (default: 20)\n  \
                     QWEN_MIN_P              Min-p sampling cutoff (default: 0.0)\n  \
                     KOKORO_LANG             Kokoro language code (default: a)\n  \
                     KOKORO_VOICE            Kokoro voice preset (default: af_heart)\n  \
                     AUDIO2FACE_IDENTITY     Claire | James | Mark (default: Claire)\n  \
                     AUDIO2FACE_SOLVER       pgd | bvls (default: pgd)\n  \
                     AUDIO2FACE_USE_GPU      true | false (default: false)\n  \
                     AUDIO2FACE_SMOOTHING    Per-frame ARKit EMA alpha (default: 0.0)\n  \
                     AVATAR_DEBUG_TAP_DIR    if set, writes 3 diagnostic WAV files\n                                             into this dir: tap_mic_16k.wav,\n                                             tap_vad_audio.wav, tap_tts.wav\n  \
                     AVATAR_DISABLE_PREWARM  skip startup pre-warm; first peer\n                                             pays the full ~30-60s init delay\n  \
                     AVATAR_HEIGHT           Render height (default: 512)\n  \
                     AVATAR_WIDTH            Render width (default: 512)\n  \
                     PYTHON_ENV_MODE=managed use uv-managed per-node venvs\n  \
                     PYTHON_VERSION=3.12     pin managed-venv Python version\n  \
                     REMOTEMEDIA_PYTHON_SRC  path to clients/python for editable install"
                );
                return Ok(());
            }
            other => {
                eprintln!("unrecognized arg: {other}");
                std::process::exit(2);
            }
        }
    }

    let manifest = Arc::new(build_manifest()?);

    let mut exec_cfg = ExecutorConfig::default();
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or_default();
    exec_cfg.session_id_prefix = format!("s{}", ts);

    // Per-node scheduler budgets. The avatar nodes are heavy-weight on
    // first call: Audio2Face cold ONNX inference is ~3.6 s on Apple
    // Silicon CPU; Live2D wgpu device init + Aria texture upload is
    // ~1-2 s; LlamaCppGenerationNode loads the full 27B GGUF on first
    // inference (~30-60 s). Subsequent calls are much faster.
    exec_cfg.scheduler_config = exec_cfg
        .scheduler_config
        .with_node_timeout("llm", 300_000)
        .with_node_timeout("kokoro_tts", 120_000)
        .with_node_timeout("audio2face_lipsync", 60_000)
        // Kimodo's daemon cold-loads Kimodo-SOMA-RP-v1.1 (~140s on
        // CUDA) BEFORE its first call returns. The Python wrapper
        // queues incoming intents during init and drains them once
        // ready, but if the Rust per-call timeout fires before the
        // queue drains, the future is dropped and any pose envelopes
        // emitted afterwards have no consumer (orphaned in the IPC
        // channel). 300s budgets cold init + diffusion (50 steps) +
        // 4s realtime-paced emission with margin.
        //
        // Note: WarmSessionPool's prewarm() reports done after Python
        // multiprocess channels open — NOT after the model finishes
        // loading — so warm sessions hand peers a kimodo node that
        // is still cold for several minutes. Until prewarm gates on
        // model-ready, this timeout must absorb a full cold load.
        .with_node_timeout("kimodo_motion", 300_000)
        // Set timeouts for both possible renderer node ids; only the
        // one matching the active AVATAR_ENGINE will actually exist in
        // the manifest. Unused timeouts are no-ops.
        .with_node_timeout("cc_render", 30_000)
        .with_node_timeout("live2d_render", 30_000);

    let executor = Arc::new(PipelineExecutor::with_config(exec_cfg)?);

    // ─── Warm-session pool prewarming ──────────────────────────────────────
    //
    // Heavy nodes in this pipeline (LlamaCpp 27B GGUF, Audio2Face ONNX,
    // Python-multiprocess Whisper/Kokoro, wgpu device) cold-load in 30-60s
    // the first time their initialize() runs. Without prewarming, every
    // first-time WebRTC connection waits for that load before any audio
    // flows.
    //
    // At server startup we:
    //   1. Build a WarmSessionPool wrapping our executor.
    //   2. Run prewarm() once and AWAIT it — blocks the "READY" log until
    //      models are actually loaded, so observability matches reality.
    //   3. set_default_pool() makes executor.create_session() (called
    //      transparently by WebSocketSignalingServer) consume the warm
    //      entry instead of cold-building.
    //
    // Auto-refill is intentionally NOT enabled (no `set_target` call): the
    // avatar server expects one peer at a time, and a background refill
    // would respawn kokoro/kimodo/audio2face right when the peer connects,
    // burning CPU/GPU for a session that may never be claimed. Subsequent
    // reconnects will cold-build; restart the server to reprime the pool.
    //
    // Set AVATAR_DISABLE_PREWARM=1 to skip the prewarm step (useful for
    // debugging cold-load behaviour or testing failure modes).
    //
    // Bind the warm pool to outer scope so its strong Arc lives as long as
    // the server. The executor stores Arc::downgrade(&pool), so dropping
    // the local Arc would silently disable delegation.
    use remotemedia_core::transport::WarmSessionPool;
    let warm_pool_keepalive: Option<Arc<WarmSessionPool>> =
        if !parse_env_bool("AVATAR_DISABLE_PREWARM").unwrap_or(false) {
            let pool = WarmSessionPool::new(executor.clone());
            let t0 = std::time::Instant::now();
            eprintln!("[prewarm] loading avatar pipeline (~30-60s for cold caches) ...");
            match pool.prewarm(manifest.clone()).await {
                Ok(()) => {
                    eprintln!("[prewarm] complete in {:.1}s", t0.elapsed().as_secs_f32());
                    executor.set_default_pool(pool.clone());
                    Some(pool)
                }
                Err(e) => {
                    eprintln!(
                        "[prewarm] failed: {e} — falling back to cold-on-connect; \
                     first peer will see the full ~30-60s init delay"
                    );
                    None
                }
            }
        } else {
            eprintln!("[prewarm] skipped: AVATAR_DISABLE_PREWARM is set");
            None
        };

    let config = Arc::new(WebRtcTransportConfig::default());
    let server = WebSocketSignalingServer::new(port, config, executor, manifest);
    let handle = server.start().await?;

    println!("READY ws://127.0.0.1:{port}/ws");
    println!(
        "Pre-warm:       {}",
        match warm_pool_keepalive.as_ref() {
            Some(_) => "enabled (1 warm session ready; reconnects cold-build)",
            None => "disabled or failed (cold-on-connect)",
        }
    );
    println!("Pipeline:       Whisper STT → Qwen3.6-27B-GGUF (llama.cpp) → Kokoro TTS → Audio2Face → Live2D (Aria)");
    println!(
        "Model path:     {}",
        std::env::var("QWEN_MODEL_PATH")
            .unwrap_or_else(|_| "unsloth/Qwen3.6-27B-GGUF:UD-Q4_K_XL".to_string())
    );
    println!(
        "Avatar model:   {}",
        std::env::var("LIVE2D_AVATAR_MODEL_PATH").unwrap_or_else(|_| "(unset)".into())
    );
    println!(
        "A2F bundle:     {}",
        std::env::var("AUDIO2FACE_BUNDLE_PATH").unwrap_or_else(|_| "(unset)".into())
    );
    println!(
        "A2F identity:   {}",
        std::env::var("AUDIO2FACE_IDENTITY").unwrap_or_else(|_| "Claire".into())
    );
    println!(
        "Avatar size:    {}x{}",
        std::env::var("AVATAR_WIDTH").unwrap_or_else(|_| "512".into()),
        std::env::var("AVATAR_HEIGHT").unwrap_or_else(|_| "512".into())
    );
    println!(
        "GPU offload:    {}",
        std::env::var("QWEN_GPU_OFFLOAD").unwrap_or_else(|_| "all".to_string())
    );
    println!(
        "KOKORO_VOICE:   {}",
        std::env::var("KOKORO_VOICE").unwrap_or_else(|_| "af_heart".to_string())
    );
    println!(
        "PYTHON_ENV_MODE={}",
        std::env::var("PYTHON_ENV_MODE").unwrap_or_else(|_| "(unset)".to_string())
    );
    println!(
        "REMOTEMEDIA_PYTHON_SRC={}",
        std::env::var("REMOTEMEDIA_PYTHON_SRC").unwrap_or_else(|_| "(unset)".to_string())
    );
    println!("Press Ctrl-C to stop.");

    tokio::signal::ctrl_c().await?;
    drop(handle);
    Ok(())
}
