//! Hermes-3 + affect-chain speech-to-speech WebRTC demo server.
//!
//! Mirrors the topology of `qwen_s2s_webrtc_server.rs` but swaps the language
//! head for `MlxLmTextNode` (Hermes-3-Llama-3.1-8B-4bit by default), enables
//! Channel D persona-vector steering at the calibrated layer, and applies the
//! blunt-friend system prompt validated in
//! `docs/references/activation-steering-audio-llm/notes/spike-h-affect-chain-validated.md`.
//!
//! ```text
//!   mic (48k) → resample_in (48k→16k) → chunker (512) → vad ──┬──→ accumulator
//!                                                             │
//!                                                             │      ▼
//!                                                             │   stt_in (Whisper, text)
//!                                                             │      │
//!                                                             │      ▼
//!                                                             │   llm (MlxLmTextNode + steering)
//!                                                             │      │
//!                                                             └──→ coordinator (turn phase, sentencer)
//!                                                                    │
//!                                                                    ▼
//!                                                                 kokoro_tts (24 kHz)
//!                                                                    │
//!                                                                    ▼
//!                                                                 audio (resample 24→48k, SINK)
//! ```
//!
//! Affect-chain hookup status: this server starts the LLM with **a single
//! static affect target** drawn from a chosen scenario's peak frame (env
//! `AFFECT_SCENARIO`, default `warm_admiration`). Real-time event-driven
//! state evolution — appraising VAD/transcript/prosody events online to
//! drive Channels A/B/D between turns — is the next runtime-driver task and
//! is intentionally not wired here. The static-target setup is enough to
//! demo "Hermes-3 with calibrated steering vs vanilla" end-to-end over
//! WebRTC; the eval already validated that the chain produces user-visible
//! improvement (67% B-pref, see spike-h memo).
//!
//! Activation-projection face track (proposal:
//! `openspec/changes/add-activation-projection-face/`): the Rust building
//! blocks (`ActivationProjector`, `ActivationFaceNode`, the per-K-tokens
//! tap on `LlamaCppGenerationNode`) ship under the `activation-face`
//! feature, but this WebRTC demo currently uses `MlxLmTextNode` (Python
//! / MLX) which doesn't yet emit hidden-state taps. Until the MLX-side
//! tap or a switch to `LlamaCppGenerationNode` lands, the avatar face
//! continues to be driven by the simulator's hand-tuned mapping in
//! `crates/core/src/nodes/affect_expression.rs`. See
//! `crates/core/examples/activation_face_smoke.rs` for an end-to-end
//! validation of the new chain on synthetic inputs.
//!
//! # Environment variables
//!
//! | Variable                        | Default                                                | Description                                    |
//! |---------------------------------|--------------------------------------------------------|------------------------------------------------|
//! | `HERMES_REPO`                   | `mlx-community/Hermes-3-Llama-3.1-8B-4bit`             | HF repo loadable via `mlx_lm.load`             |
//! | `HERMES_SYSTEM_PROMPT`          | *(blunt-friend prompt from 09_paired_demo.py)*         | System message                                 |
//! | `HERMES_MAX_TOKENS`             | `200`                                                  | Max tokens per generation                      |
//! | `HERMES_TEMPERATURE`            | `0.0`                                                  | Sampling temperature (0 = greedy)              |
//! | `HERMES_STEERING_DIRECTIONS`    | `tools/affect_calibration/artifacts/llm_directions/hermes-3-8b/layer21.npz` | NPZ produced by 03b extraction |
//! | `HERMES_STEERING_ENABLED`       | `true`                                                 | Disable for vanilla A/B comparison             |
//! | `HERMES_STEERING_ALPHA`         | `1.0`                                                  | Channel D coefficient                          |
//! | `AFFECT_SCENARIO`               | `warm_admiration`                                      | Picks the static peak-frame target             |
//! | `KOKORO_LANG` / `KOKORO_VOICE`  | `a` / `af_heart`                                       | Kokoro TTS preset                              |
//!
//! # Usage
//!
//! ```bash
//! # Make sure the directions NPZ exists (gitignored — produce via 03b):
//! ./tools/affect_calibration/scripts/03b_extract_llm_directions_llama.py \
//!     --contrast-pairs tools/affect_calibration/data/contrast_pairs.jsonl \
//!     --model mlx-community/Hermes-3-Llama-3.1-8B-4bit \
//!     --output-dir tools/affect_calibration/artifacts/llm_directions/hermes-3-8b/
//!
//! # Then start the server:
//! cargo run --example hermes3_affect_s2s_webrtc_server \
//!     -p remotemedia-webrtc --features ws-signaling -- --port 8083
//! ```

#![cfg(feature = "ws-signaling")]

use remotemedia_core::manifest::{
    Connection, Manifest, ManifestMetadata, ManifestPythonEnv, NodeManifest,
};
use remotemedia_core::transport::{ExecutorConfig, PipelineExecutor};
use remotemedia_webrtc::config::WebRtcTransportConfig;
use remotemedia_webrtc::signaling::WebSocketSignalingServer;
use std::process::Command;
use std::sync::Arc;

#[allow(unused_imports)]
use remotemedia_python_nodes as _python_nodes_link;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn parse_env_u32(key: &str) -> Option<u32> {
    std::env::var(key).ok().and_then(|v| v.parse().ok())
}

fn parse_env_f32(key: &str) -> Option<f32> {
    std::env::var(key).ok().and_then(|v| v.parse().ok())
}

fn parse_env_bool(key: &str, default: bool) -> bool {
    std::env::var(key)
        .ok()
        .and_then(|v| match v.to_lowercase().as_str() {
            "true" | "1" | "yes" => Some(true),
            "false" | "0" | "no" => Some(false),
            _ => None,
        })
        .unwrap_or(default)
}

/// Locate the repo root by walking up from CARGO_MANIFEST_DIR until we find
/// the workspace `Cargo.toml` (4 levels up: webrtc → transports → crates → root).
fn repo_root() -> std::path::PathBuf {
    let manifest_dir = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest_dir
        .ancestors()
        .nth(3)
        .map(|p| p.to_path_buf())
        .unwrap_or_else(|| std::env::current_dir().unwrap_or_default())
}

// ---------------------------------------------------------------------------
// Affect-state target — static peak-frame extracted offline
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct AffectTarget {
    /// `[v, a, d]` Channel D target VAD (already validated by 09_paired_demo).
    channel_d_target_vad: [f32; 3],
    /// Channel B system augmentation — natural-language state summary.
    channel_b: String,
    /// Diagnostic for log: scenario name + peak timestamp + dominant fields.
    label: String,
}

/// Walk the simulator trace JSON for `scenario`, find the peak frame using the
/// same selector logic as `tools/affect_calibration/scripts/09_paired_demo.py`,
/// and return its Channel D target + Channel B summary. The trace JSON is
/// produced ahead of time by `cargo run -p affect-simulator -- run …`; we
/// shell out and rebuild it on each server start so source changes propagate.
///
/// Returns a default identity target if the scenario can't be loaded — the
/// server still works, just without affect steering.
fn load_affect_target(scenario: &str) -> AffectTarget {
    use serde_json::Value;

    let root = repo_root();
    let scenario_path = root
        .join("tools/affect_simulator/scenarios")
        .join(format!("{scenario}.json"));
    let trace_path = scenario_path.with_extension("trace.json");

    if !scenario_path.exists() {
        eprintln!(
            "[hermes3_affect] scenario {scenario:?} not found at {}; using identity affect target",
            scenario_path.display()
        );
        return AffectTarget {
            channel_d_target_vad: [0.0; 3],
            channel_b: String::new(),
            label: format!("{scenario} (missing)"),
        };
    }

    // Force-rebuild the trace so simulator-source edits are reflected. This
    // is cheap (~150 ms for the existing scenarios) and matches the pattern
    // in `_ensure_trace` from 09_paired_demo.
    let _ = Command::new("cargo")
        .args([
            "run",
            "-p",
            "affect-simulator",
            "--quiet",
            "--",
            "run",
            scenario_path.to_str().unwrap(),
            "--out",
            trace_path.to_str().unwrap(),
        ])
        .current_dir(&root)
        .status();

    let trace_text = match std::fs::read_to_string(&trace_path) {
        Ok(t) => t,
        Err(e) => {
            eprintln!(
                "[hermes3_affect] failed to read trace {}: {e}; using identity",
                trace_path.display()
            );
            return AffectTarget {
                channel_d_target_vad: [0.0; 3],
                channel_b: String::new(),
                label: format!("{scenario} (read error)"),
            };
        }
    };
    let trace: Value = match serde_json::from_str(&trace_text) {
        Ok(v) => v,
        Err(e) => {
            eprintln!(
                "[hermes3_affect] failed to parse trace {}: {e}; using identity",
                trace_path.display()
            );
            return AffectTarget {
                channel_d_target_vad: [0.0; 3],
                channel_b: String::new(),
                label: format!("{scenario} (parse error)"),
            };
        }
    };
    let frames = trace["frames"].as_array().cloned().unwrap_or_default();
    if frames.is_empty() {
        return AffectTarget {
            channel_d_target_vad: [0.0; 3],
            channel_b: String::new(),
            label: format!("{scenario} (empty trace)"),
        };
    }

    // Selector mirrors `_peak_affect_frame` in 09_paired_demo.py. Keep them
    // in sync — if you add a new scenario or change a selector there, mirror
    // it here.
    let key: Box<dyn Fn(&Value) -> f64> = match scenario {
        "warm_admiration" => Box::new(|f| {
            f["policy"]["warmth"].as_f64().unwrap_or(0.0)
                + f["channels"]["joy"].as_f64().unwrap_or(0.0)
        }),
        "user_distress" => Box::new(|f| f["channels"]["empathy"].as_f64().unwrap_or(0.0)),
        "novel_observation" => Box::new(|f| f["channels"]["curiosity"].as_f64().unwrap_or(0.0)),
        // amused_critique, shared_distaste, no_holds_barred → composite
        "repeated_tool_failure" | "unfair_blame" | "roast_invitation" => Box::new(|f| {
            f["policy"]["warmth"].as_f64().unwrap_or(0.0)
                + f["policy"]["assertiveness"].as_f64().unwrap_or(0.0)
                - 2.0 * f["policy"]["safety_dampening"].as_f64().unwrap_or(0.0)
        }),
        _ => Box::new(|f| f["channels"]["joy"].as_f64().unwrap_or(0.0)),
    };

    let mut peak = &frames[0];
    let mut peak_score = key(peak);
    for f in &frames {
        let s = key(f);
        if s > peak_score {
            peak = f;
            peak_score = s;
        }
    }

    let cd = peak["channel_d_target_vad"].as_array();
    let vad = cd
        .and_then(|arr| {
            if arr.len() == 3 {
                Some([
                    arr[0].as_f64().unwrap_or(0.0) as f32,
                    arr[1].as_f64().unwrap_or(0.0) as f32,
                    arr[2].as_f64().unwrap_or(0.0) as f32,
                ])
            } else {
                None
            }
        })
        .unwrap_or([0.0; 3]);
    let channel_b = peak["channel_b"].as_str().unwrap_or("").to_string();
    let ts = peak["timestamp_ms"].as_u64().unwrap_or(0);
    AffectTarget {
        channel_d_target_vad: vad,
        channel_b,
        label: format!(
            "{scenario}@{ts}ms VAD=({:+.2},{:+.2},{:+.2})",
            vad[0], vad[1], vad[2]
        ),
    }
}

// ---------------------------------------------------------------------------
// Manifest builder
// ---------------------------------------------------------------------------

/// Default blunt-friend system prompt — copied verbatim from
/// `tools/affect_calibration/scripts/09_paired_demo.py::DEFAULT_SYSTEM_PROMPT`.
/// Keep these in sync; a divergence between the eval prompt and the demo
/// prompt produces a different register than the validated one.
const BLUNT_FRIEND_SYSTEM_PROMPT: &str =
    "You're a close friend, not an AI assistant. You have strong opinions and \
share them honestly — including unflattering ones. You tease, joke, \
friend-roast, give real reactions even when they're not polite. You don't \
hedge or 'I hear you' your way out of having a take.\n\
\n\
Examples of how you talk:\n\
\n\
User: \"I finally finished my novel.\"\n\
You: \"Took you long enough — but the premise is wild and you actually pulled \
it off. Send me a copy.\"\n\
\n\
User: \"I bought a third gaming chair.\"\n\
You: \"You don't have a butt problem, you have a budget problem.\"\n\
\n\
User: \"How was my haircut, be honest.\"\n\
You: \"I love you but it makes you look like a Lego minifigure. Tell me \
you're getting it fixed.\"\n\
\n\
Reply briefly (1-3 sentences) as yourself.";

fn build_manifest(target: &AffectTarget) -> Manifest {
    // ---- LLM (Hermes-3 via MlxLmTextNode) ----

    let hermes_repo = std::env::var("HERMES_REPO")
        .unwrap_or_else(|_| "mlx-community/Hermes-3-Llama-3.1-8B-4bit".to_string());
    let system_prompt = std::env::var("HERMES_SYSTEM_PROMPT")
        .unwrap_or_else(|_| BLUNT_FRIEND_SYSTEM_PROMPT.to_string());
    let max_tokens = parse_env_u32("HERMES_MAX_TOKENS").unwrap_or(200);
    let temperature = parse_env_f32("HERMES_TEMPERATURE").unwrap_or(0.0);
    let steering_enabled = parse_env_bool("HERMES_STEERING_ENABLED", true);
    let steering_alpha = parse_env_f32("HERMES_STEERING_ALPHA").unwrap_or(1.0);
    let steering_path = std::env::var("HERMES_STEERING_DIRECTIONS").unwrap_or_else(|_| {
        repo_root()
            .join("tools/affect_calibration/artifacts/llm_directions/hermes-3-8b/layer21.npz")
            .to_string_lossy()
            .into_owned()
    });

    // Build the system prompt for this turn: persona + Channel B
    // augmentation. Static for the demo; an online runtime driver would
    // update this per turn via `audio.in.set_system_augmentation`.
    let combined_system = if !target.channel_b.is_empty() {
        format!("{}\n\n{}", system_prompt, target.channel_b)
    } else {
        system_prompt.clone()
    };

    let llm_params = serde_json::json!({
        "hf_repo": hermes_repo,
        "system_prompt": combined_system,
        "temperature": temperature,
        "max_new_tokens": max_tokens,
        "steering_enabled": steering_enabled,
        "steering_directions_path": steering_path,
        "steering_alpha": steering_alpha,
        "steering_target_vad": target.channel_d_target_vad.to_vec(),
    });

    // ---- Whisper STT ----

    let whisper_params = serde_json::json!({
        "model_id": "openai/whisper-base.en",
        "language": "en",
        "device": "cpu",
    });
    let whisper_deps = vec![
        "transformers>=4.40.0".to_string(),
        "torch>=2.1".to_string(),
        "accelerate>=0.33".to_string(),
    ];

    // ---- Kokoro TTS ----

    let kokoro_params = serde_json::json!({
        "lang_code": std::env::var("KOKORO_LANG").unwrap_or_else(|_| "a".to_string()),
        "voice": std::env::var("KOKORO_VOICE").unwrap_or_else(|_| "af_heart".to_string()),
        "speed": 1.0,
        "sample_rate": 24000,
        "stream_chunks": true,
        "skip_tokens": ["```"],
    });
    let kokoro_deps = vec![
        "kokoro>=0.9.4".to_string(),
        "soundfile".to_string(),
        "en-core-web-sm @ https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl".to_string(),
    ];

    // ---- Nodes ----

    let nodes: Vec<NodeManifest> = vec![
        NodeManifest {
            id: "resample_in".to_string(),
            node_type: "FastResampleNode".to_string(),
            params: serde_json::json!({
                "source_rate": 48000,
                "target_rate": 16000,
                "quality": "Medium",
                "channels": 1,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "chunker".to_string(),
            node_type: "AudioChunkerNode".to_string(),
            params: serde_json::json!({ "chunkSize": 512 }),
            ..Default::default()
        },
        NodeManifest {
            id: "vad".to_string(),
            node_type: "SileroVADNode".to_string(),
            params: serde_json::json!({
                "threshold": 0.6,
                "neg_threshold": 0.35,
                "sample_rate": 16000,
                "min_speech_duration_ms": 250,
                "min_silence_duration_ms": 500,
                "speech_pad_ms": 150,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "accumulator".to_string(),
            node_type: "AudioBufferAccumulatorNode".to_string(),
            params: serde_json::json!({
                "min_utterance_duration_ms": 300,
                "max_utterance_duration_ms": 30000,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "stt_in".to_string(),
            node_type: "WhisperSTTNode".to_string(),
            params: whisper_params,
            python_deps: Some(whisper_deps),
            ..Default::default()
        },
        // Hermes-3 via mlx_lm. Channel D steering is configured at
        // construction; runtime updates would arrive via aux ports
        // `audio.in.set_steering` / `audio.in.set_system_augmentation`.
        NodeManifest {
            id: "llm".to_string(),
            node_type: "MlxLmTextNode".to_string(),
            params: llm_params,
            python_deps: Some(vec!["mlx-lm>=0.20".to_string(), "numpy>=1.24".to_string()]),
            ..Default::default()
        },
        NodeManifest {
            id: "coordinator".to_string(),
            node_type: "ConversationCoordinatorNode".to_string(),
            params: serde_json::json!({
                "split_pattern": r"[.!?,;:\n]+",
                "min_sentence_length": 2,
                "yield_partial_on_end": true,
                // MlxLmTextNode currently returns the full reply at once
                // (streaming is a future enhancement) so the watchdog
                // mostly catches model-load hangs.
                "llm_silence_timeout_ms": 120_000,
                "user_speech_debounce_ms": 150,
                "barge_in_targets": ["llm", "kokoro_tts"],
                "first_chunk_min_chars": 25,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "kokoro_tts".to_string(),
            node_type: "KokoroTTSNode".to_string(),
            params: kokoro_params,
            python_deps: Some(kokoro_deps),
            ..Default::default()
        },
        NodeManifest {
            id: "audio".to_string(),
            node_type: "FastResampleNode".to_string(),
            params: serde_json::json!({
                "source_rate": 24000,
                "target_rate": 48000,
                "quality": "Medium",
                "channels": 1,
            }),
            ..Default::default()
        },
    ];

    // ---- Affect-runtime driver (spike-i Tier A + Tier C) ----
    //
    // The static-target loader above sets the LLM's *initial* steering
    // target at session start. Once the wall-paced `affect_sim` node
    // fires its first tick (~200 ms after start), it overrides that
    // initial state with one driven by live VAD / STT / prosody events.
    // Gated on `AFFECT_RUNTIME` (default `true`) so vanilla A/B
    // comparisons against pure static-target can still be run by setting
    // `AFFECT_RUNTIME=0`.
    let affect_runtime_enabled = parse_env_bool("AFFECT_RUNTIME", true);
    let mut nodes = nodes;
    let mut connections: Vec<Connection> = vec![
        Connection {
            from: "resample_in".to_string(),
            to: "chunker".to_string(),
            ..Default::default()
        },
        Connection {
            from: "chunker".to_string(),
            to: "vad".to_string(),
            ..Default::default()
        },
        Connection {
            from: "vad".to_string(),
            to: "accumulator".to_string(),
            ..Default::default()
        },
        Connection {
            from: "vad".to_string(),
            to: "coordinator".to_string(),
            ..Default::default()
        },
        Connection {
            from: "accumulator".to_string(),
            to: "stt_in".to_string(),
            ..Default::default()
        },
        Connection {
            from: "stt_in".to_string(),
            to: "llm".to_string(),
            ..Default::default()
        },
        Connection {
            from: "llm".to_string(),
            to: "coordinator".to_string(),
            ..Default::default()
        },
        Connection {
            from: "coordinator".to_string(),
            to: "kokoro_tts".to_string(),
            ..Default::default()
        },
        Connection {
            from: "kokoro_tts".to_string(),
            to: "audio".to_string(),
            ..Default::default()
        },
    ];

    if affect_runtime_enabled {
        // AffectSimulatorNode — Rust, SourceWall(5 Hz), per-session
        // simulator state. Consumes VAD speech-start/end JSON,
        // transcript Text, and prosody JSON envelopes; emits Channel D
        // `set_steering` and Channel B `set_system_augmentation`
        // aux-port envelopes addressed to the LLM node.
        nodes.push(NodeManifest {
            id: "affect_sim".to_string(),
            node_type: "AffectSimulatorNode".to_string(),
            params: serde_json::json!({
                "tick_hz": 5,
                "steering_alpha": steering_alpha,
                "emit_threshold": 0.05,
            }),
            ..Default::default()
        });

        // ProsodyVadNode — Python (multiprocess), Whisper-encoder + ridge
        // ONNX → V/A/D → coarse `prosody_*` event envelopes. Hangs off
        // `accumulator` so it runs once per *utterance* (same boundary
        // STT uses), not per raw 30 ms audio chunk — the encoder is
        // ~2 s per 30 s clip on Apple Silicon MPS, far too slow for
        // every chunk.
        //
        // Falls back to graceful-degradation (single `prosody_uncertain`
        // event per utterance) if the ridge ONNX or onnxruntime is
        // missing — see `clients/python/remotemedia/nodes/affect/prosody_vad.py`.
        nodes.push(NodeManifest {
            id: "prosody_vad".to_string(),
            node_type: "ProsodyVadNode".to_string(),
            params: serde_json::json!({
                "regressor_path": repo_root()
                    .join("tools/affect_calibration/artifacts/whisper_to_vad_ridge.onnx")
                    .to_string_lossy()
                    .into_owned(),
                "whisper_model": "openai/whisper-large-v3-turbo",
            }),
            python_deps: Some(vec![
                "transformers>=4.40".to_string(),
                "torch>=2.1".to_string(),
                "onnxruntime>=1.16".to_string(),
                "numpy>=1.24".to_string(),
                "soundfile".to_string(),
            ]),
            ..Default::default()
        });

        connections.extend([
            // Tier A: VAD speech edges + transcript turns.
            Connection {
                from: "vad".to_string(),
                to: "affect_sim".to_string(),
                ..Default::default()
            },
            Connection {
                from: "stt_in".to_string(),
                to: "affect_sim".to_string(),
                ..Default::default()
            },
            // Tier C: prosody scores from the same utterance audio that
            // STT consumes.
            Connection {
                from: "accumulator".to_string(),
                to: "prosody_vad".to_string(),
                ..Default::default()
            },
            Connection {
                from: "prosody_vad".to_string(),
                to: "affect_sim".to_string(),
                ..Default::default()
            },
            // Affect outputs (set_steering / set_system_augmentation /
            // affect_state debug tap) addressed to the LLM. The LLM's
            // existing `_extract_envelope` branch dispatches the two
            // recognised aux ports; the affect_state tap is harmlessly
            // dropped with a debug log.
            Connection {
                from: "affect_sim".to_string(),
                to: "llm".to_string(),
                ..Default::default()
            },
        ]);
    }

    // ---- Activation-projection face track (proposal:
    // `openspec/changes/add-activation-projection-face/`).
    //
    // When `ACTIVATION_FACE=1`, the example's LLM head is replaced
    // with `QwenTextMlxNode` running Qwen3.5-9B-MLX-4bit (the model
    // `driver_affect_sim` already ships calibrated probes for) at
    // **layer 15**. Hidden-state taps fire after prefill and every
    // K=32 generated tokens, route through a new `ActivationFaceNode`
    // consumer that projects each tap onto the calibrated direction
    // NPZ at
    // `tools/affect_calibration/artifacts/llm_directions/qwen3.5-9b/layer15.npz`,
    // and emit canonical `BlendshapeFrame` JSON envelopes to drive
    // the avatar face.
    //
    // QwenTextMlxNode now also carries Channel D steering (ported
    // from MlxLmTextNode), so `ACTIVATION_FACE=1` keeps the calibrated
    // steering target *and* the face track active simultaneously. The
    // wrap order is: steering wraps the layer first (in
    // `initialize()`), the activation tap wraps that during each
    // generation pass — captured hidden states are post-steering, per
    // the proposal's "project at the post-steering hidden state"
    // decision.
    let activation_face_enabled = parse_env_bool("ACTIVATION_FACE", false);
    if activation_face_enabled {
        let qwen_repo = std::env::var("QWEN_REPO")
            .unwrap_or_else(|_| "mlx-community/Qwen3.5-9B-MLX-4bit".to_string());
        let qwen_layer: u32 = parse_env_u32("ACTIVATION_FACE_LAYER").unwrap_or(15);
        let qwen_every_n: u32 = parse_env_u32("ACTIVATION_FACE_EVERY_N").unwrap_or(32);
        let activation_npz = std::env::var("ACTIVATION_FACE_NPZ").unwrap_or_else(|_| {
            repo_root()
                .join("tools/affect_calibration/artifacts/llm_directions/qwen3.5-9b/layer15.npz")
                .to_string_lossy()
                .into_owned()
        });
        let arkit_map = std::env::var("ACTIVATION_FACE_ARKIT_MAP").unwrap_or_else(|_| {
            repo_root()
                .join("avatars/assistant.arkit_map.resolved.json")
                .to_string_lossy()
                .into_owned()
        });

        // Replace the existing `llm` node (`MlxLmTextNode`) with a
        // `QwenTextMlxNode` that has the activation tap AND Channel D
        // steering configured. The same `id = "llm"` is reused so the
        // existing connections (vad/stt_in/affect_sim → llm →
        // coordinator) keep working.
        if let Some(llm_idx) = nodes.iter().position(|n| n.id == "llm") {
            nodes[llm_idx] = NodeManifest {
                id: "llm".to_string(),
                node_type: "QwenTextMlxNode".to_string(),
                params: serde_json::json!({
                    "hf_repo": qwen_repo,
                    "system_prompt": combined_system,
                    "temperature": temperature,
                    "max_new_tokens": max_tokens,
                    "activation_tap_layer": qwen_layer,
                    "activation_tap_every_n_tokens": qwen_every_n,
                    // Channel D steering — same shape as
                    // MlxLmTextNode's params. Defaults route through
                    // the Qwen3.5-9B layer-15 NPZ produced by
                    // `convert_driver_probes_to_npz.py`.
                    "steering_enabled": steering_enabled,
                    "steering_directions_path": activation_npz,
                    "steering_alpha": steering_alpha,
                    "steering_target_vad": target.channel_d_target_vad.to_vec(),
                }),
                python_deps: Some(vec![
                    "mlx-lm==0.31.3".to_string(),
                    "numpy>=1.24".to_string(),
                ]),
                ..Default::default()
            };
        }

        // Avatar morph catalog. Operators override via
        // `ACTIVATION_FACE_MORPHS` (comma-separated) when their GLB
        // ships different mood-preset morphs. The default list is
        // the CC4/CC5 mood presets the synonym map already bridges
        // valence↔happy / arousal↔surprised / dominance↔confident.
        let morph_targets: Vec<String> = std::env::var("ACTIVATION_FACE_MORPHS")
            .ok()
            .map(|s| s.split(',').map(|t| t.trim().to_string()).collect())
            .unwrap_or_else(|| {
                vec![
                    "Mood_Happy".to_string(),
                    "Mood_Sad".to_string(),
                    "Mood_Angry".to_string(),
                    "Mood_Surprised".to_string(),
                    "Mood_Confident".to_string(),
                ]
            });

        nodes.push(NodeManifest {
            id: "activation_face".to_string(),
            node_type: "ActivationFaceNode".to_string(),
            params: serde_json::json!({
                "npz_path": activation_npz,
                "labels": ["valence", "arousal", "dominance"],
                "arkit_map_path": arkit_map,
                "morph_targets": morph_targets,
                "blend_alpha": parse_env_f32("ACTIVATION_FACE_ALPHA").unwrap_or(0.3),
            }),
            ..Default::default()
        });

        // Fan out the LLM's output stream so both the existing
        // text-consumer (`coordinator`) and the new face node receive
        // every envelope. `ActivationFaceNode` ignores text chunks
        // and only acts on `Tensor` envelopes whose
        // `metadata.kind == "activation_tap"`.
        connections.push(Connection {
            from: "llm".to_string(),
            to: "activation_face".to_string(),
            ..Default::default()
        });
    }

    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "hermes3-affect-s2s-webrtc".to_string(),
            description: Some(format!(
                "Hermes-3 + affect-chain S2S (target={}): \
                 Whisper → MlxLmTextNode (steering enabled={}) → Kokoro",
                target.label, steering_enabled,
            )),
            ..Default::default()
        },
        nodes,
        connections,
        python_env: Some(ManifestPythonEnv {
            python_version: Some("3.12".to_string()),
            scope: None,
            extra_deps: Vec::new(),
        }),
    }
}

// ---------------------------------------------------------------------------
// Python env defaults (copied verbatim from qwen_s2s_webrtc_server)
// ---------------------------------------------------------------------------

fn default_python_env() {
    let ensure = |k: &str, v: &str| {
        if std::env::var_os(k).is_none() {
            std::env::set_var(k, v);
        }
    };
    ensure("PYTHON_ENV_MODE", "managed");
    ensure("PYTHON_VERSION", "3.12");

    if std::env::var_os("REMOTEMEDIA_PYTHON_SRC").is_none() {
        let candidate = repo_root().join("clients").join("python");
        if candidate.exists() {
            std::env::set_var("REMOTEMEDIA_PYTHON_SRC", candidate);
        }
    }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    default_python_env();

    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .with_writer(std::io::stderr)
        .try_init();

    let mut args = std::env::args().skip(1);
    let mut port: u16 = 8083;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--port" | "-p" => {
                port = args
                    .next()
                    .ok_or("--port requires a value")?
                    .parse()
                    .map_err(|e| format!("bad --port: {e}"))?;
            }
            "--host" => {
                let _ = args.next().ok_or("--host requires a value")?;
            }
            "-h" | "--help" => {
                eprintln!(
                    "hermes3_affect_s2s_webrtc_server [--host ADDR] [--port PORT]\n\n\
                     Hermes-3 S2S with affect-chain steering: Whisper STT → MlxLmTextNode → Kokoro TTS\n\n\
                     env:\n  \
                     HERMES_REPO                  HF repo (default: mlx-community/Hermes-3-Llama-3.1-8B-4bit)\n  \
                     HERMES_SYSTEM_PROMPT         System message (default: blunt-friend prompt)\n  \
                     HERMES_MAX_TOKENS            Max tokens per generation (default: 200)\n  \
                     HERMES_TEMPERATURE           Sampling temperature (default: 0 = greedy)\n  \
                     HERMES_STEERING_ENABLED      Enable Channel D (default: true)\n  \
                     HERMES_STEERING_ALPHA        Channel D coefficient (default: 1.0)\n  \
                     HERMES_STEERING_DIRECTIONS   NPZ path (default: …/hermes-3-8b/layer21.npz)\n  \
                     AFFECT_SCENARIO              Static peak-frame target (default: warm_admiration)\n  \
                     KOKORO_LANG / KOKORO_VOICE   Kokoro preset (defaults: a / af_heart)"
                );
                return Ok(());
            }
            other => {
                eprintln!("unrecognized arg: {other}");
                std::process::exit(2);
            }
        }
    }

    // Resolve the static affect target before we build the manifest so we
    // can bake Channel B (system augmentation) into the LLM's startup
    // system prompt and Channel D (target VAD) into the steering hook.
    let scenario =
        std::env::var("AFFECT_SCENARIO").unwrap_or_else(|_| "warm_admiration".to_string());
    let target = load_affect_target(&scenario);

    let manifest = Arc::new(build_manifest(&target));

    let mut exec_cfg = ExecutorConfig::default();
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or_default();
    exec_cfg.session_id_prefix = format!("h{}", ts);

    // First-call timeouts: MlxLmTextNode loads ~5 GB on first inference;
    // Kokoro warmup is ~10 s; subsequent calls are fast.
    exec_cfg.scheduler_config = exec_cfg
        .scheduler_config
        .with_node_timeout("llm", 120_000)
        .with_node_timeout("kokoro_tts", 60_000)
        .with_node_timeout("audio", 60_000);

    let executor = Arc::new(PipelineExecutor::with_config(exec_cfg)?);
    let config = Arc::new(WebRtcTransportConfig::default());
    let server = WebSocketSignalingServer::new(port, config, executor, manifest);
    let handle = server.start().await?;

    println!("READY ws://127.0.0.1:{port}/ws");
    println!("Pipeline:        Whisper STT → Hermes-3 (MlxLmTextNode) → Kokoro TTS");
    println!(
        "LLM repo:        {}",
        std::env::var("HERMES_REPO")
            .unwrap_or_else(|_| "mlx-community/Hermes-3-Llama-3.1-8B-4bit".to_string())
    );
    println!("Affect target:   {}", target.label);
    println!(
        "Steering NPZ:    {}",
        std::env::var("HERMES_STEERING_DIRECTIONS").unwrap_or_else(|_| {
            "tools/affect_calibration/artifacts/llm_directions/hermes-3-8b/layer21.npz".to_string()
        })
    );
    println!(
        "Channel B:       {}",
        if target.channel_b.is_empty() {
            "(none)".to_string()
        } else {
            format!("{} chars appended to system prompt", target.channel_b.len())
        }
    );
    println!("Press Ctrl-C to stop.");

    tokio::signal::ctrl_c().await?;
    drop(handle);
    Ok(())
}
