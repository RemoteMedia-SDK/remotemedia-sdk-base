# remotemedia-modality

Transport-agnostic, modality-organised primitives shared by every
RemoteMedia provider node (in-tree + loadable cdylib plugins).

## Why this crate exists

Loadable plugins **must not** link `remotemedia-core` (it would
drag the entire host into every cdylib). But plugins still need
the per-modality wire types — `HistoryEntry`, `TranscriptionSegment`,
`VoiceSpec`, … — to match what the host's downstream nodes consume.
This crate is the shared vocabulary: pure types + serde + small
pure-Rust helpers, no HTTP, no vendor SDK, no Candle/ORT.

Built on `remotemedia-types` (RuntimeData / Error / channel tags),
which has the same invariants.

## Modules

| Feature      | Module        | Covers                                                                                   |
|--------------|---------------|------------------------------------------------------------------------------------------|
| `llm`        | `llm`         | Chat history, OpenAI-shaped tool specs, streaming tool-call dispatch.                    |
| `stt`        | `stt`         | TranscriptionSegment, streaming partial+final accumulator, common STT config.            |
| `tts`        | `tts`         | VoiceSpec, AudioFormat, streaming chunk emit helpers, common TTS config.                 |
| `t2i`        | `t2i`         | GenerationParams, scheduler enum, common text-to-image config.                           |
| `vision`     | `vision`      | Classification, preprocessing knobs, vision config.                                      |
| `embedding`  | `embedding`   | FeatureVector (shared with vision feature extractors), PoolingStrategy, L2-normalize, embedding config. |

Default features = `[]`. Every consumer opts in to exactly the
modules it emits or consumes.

## Consumers (current + planned)

| Consumer                                       | Features                                                |
|------------------------------------------------|----------------------------------------------------------|
| `crates/core/` (in-tree `OpenAIChatNode`, …)   | `llm`, `embedding` (planned)                             |
| `examples/foundry-local-loadable/`             | `llm`; `stt`, `embedding` when those nodes ship          |
| `examples/whisper-loadable/` (planned migrate) | `stt`                                                    |
| `examples/candle-transformers-loadable/`       | All six                                                  |
| Future provider plugins (OpenAI, Anthropic, …) | Per surface                                              |

## Design

See
[`docs/superpowers/specs/2026-05-20-remotemedia-modality-crate-extension-design.md`](../../docs/superpowers/specs/2026-05-20-remotemedia-modality-crate-extension-design.md)
for the full design rationale, including why this is one crate
with feature-gated submodules rather than one crate per modality.
