//! Unit tests for node parameter validation
//!
//! Tests organized by User Story per tasks.md

mod test_enum;
mod test_error_messages;
mod test_nested;
mod test_range;
mod test_required;
mod test_type_errors;
