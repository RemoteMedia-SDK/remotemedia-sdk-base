//! End-to-end via the `examples/manifests/avatar_voice.json` manifest.
//!
//! This is the headline integration test for Phase 6.4: load the
//! production manifest, drive audio through it for a window, then stop
//! audio for a window. The avatar must transition Speaking → Idle
//! (not Cold) when the weights snapshot ages out, because the idle
//! pose is wired in as the freshness fallback.
//!
//! The manifest is loaded at runtime from disk so the test
//! double-checks that the JSON shape we ship is parseable and
//! complete.

use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::audio_samples::AudioSamples;
use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{parse, NodeManifest};
use remotemedia_core::nodes::streaming_registry::create_default_streaming_registry;
use remotemedia_core::transport::session_router::{
    DataPacket, SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY,
};

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

const MANIFEST_PATH: &str = "../../examples/manifests/avatar_voice.json";

fn load_manifest() -> remotemedia_core::manifest::Manifest {
    let path = std::env::current_dir().unwrap().join(MANIFEST_PATH);
    let text = std::fs::read_to_string(&path).unwrap_or_else(|e| {
        panic!("failed to read manifest at {:?}: {}", path, e);
    });
    parse(&text).expect("valid manifest JSON")
}

fn audio_chunk(amplitude: f32, pts_us: u64) -> RuntimeData {
    RuntimeData::Audio {
        samples: AudioSamples::Vec(vec![amplitude; 320]),
        sample_rate: 16_000,
        channels: 1,
        stream_id: None,
        timestamp_us: Some(pts_us),
        arrival_ts_us: None,
        metadata: None,
    }
}

#[tokio::test]
async fn avatar_voice_manifest_loads_and_drives_render_path() {
    let manifest = load_manifest();
    // Sanity: the three expected nodes are present.
    let ids: Vec<&str> = manifest
        .nodes
        .iter()
        .map(|n: &NodeManifest| n.id.as_str())
        .collect();
    assert!(ids.contains(&"audio2face"));
    assert!(ids.contains(&"idle"));
    assert!(ids.contains(&"avatar"));
    // 2 snapshot connections: a2f.weights -> avatar.weights and idle.idle_pose -> avatar.idle_pose.
    assert_eq!(manifest.connections.len(), 2);

    let session_id = "avatar-voice-e2e".to_string();
    let manifest = Arc::new(manifest);
    let registry = Arc::new(create_default_streaming_registry());

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    let input_tx = router.get_input_sender();
    let handle = router.start();

    // 250 ms of audio, then 250 ms of silence. weights_fresh_us in
    // the manifest is 200 ms, so the snapshot should age out roughly
    // 200 ms after the last audio chunk → expect a clean
    // Speaking → Idle handoff.
    let audio_driver = {
        let input_tx = input_tx.clone();
        let session_id = session_id.clone();
        tokio::spawn(async move {
            let start = std::time::Instant::now();
            let mut seq: u64 = 0;
            while start.elapsed() < Duration::from_millis(250) {
                let pts = start.elapsed().as_micros() as u64;
                let pkt = DataPacket {
                    data: audio_chunk(0.1, pts),
                    from_node: "external".to_string(),
                    to_node: Some("audio2face".to_string()),
                    session_id: session_id.clone(),
                    sequence: seq,
                    sub_sequence: 0,
                    metadata: std::collections::HashMap::new(),
                };
                seq += 1;
                if input_tx.send(pkt).await.is_err() {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(20)).await;
            }
        })
    };

    let mut frames: Vec<(u64, Vec<u8>)> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(700);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Video {
                    pixel_data,
                    timestamp_us,
                    ..
                } = out
                {
                    frames.push((timestamp_us, pixel_data));
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    let _ = audio_driver.await;

    let n = frames.len();
    // 30 Hz × 700 ms = 21 frames; allow ±50% slack.
    assert!(n >= 10, "expected ≥10 avatar frames; got {}", n);

    let speaking = frames.iter().filter(|(_, p)| p == &[0xAA]).count();
    let idle = frames.iter().filter(|(_, p)| p == &[0xBB]).count();
    let cold = frames.iter().filter(|(_, p)| p == &[0x00]).count();

    // The whole point of the wired idle path: once weights age out,
    // the avatar must fall back to the idle pose, not cold.
    assert!(
        speaking >= 3,
        "expected ≥3 speaking frames during 250 ms audio; got speaking={} idle={} cold={} of {}",
        speaking,
        idle,
        cold,
        n
    );
    assert!(
        idle >= 3,
        "expected ≥3 idle frames after audio stopped; got speaking={} idle={} cold={} of {}",
        speaking,
        idle,
        cold,
        n
    );
    // Cold frames are allowed only at the very start — once the first
    // idle publish lands, the avatar must always observe at least
    // idle_pose.
    assert!(
        cold <= 3,
        "too many cold-start frames: speaking={} idle={} cold={} of {}",
        speaking,
        idle,
        cold,
        n
    );

    drop(input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
