//! `CcRenderNode` integration tests driven through `MockRenderer`.
//!
//! These tests assert the streaming-node contract:
//!   - blendshape envelopes get converted into per-mesh ARKit poses
//!     (52 channel names → weights) and forwarded to the renderer
//!   - rendered frames the renderer drains get re-emitted as
//!     `RuntimeData::Video` with the configured `stream_id`,
//!     `Rgba32` pixel format, and pts stamped relative to the
//!     anchor of the first pose seen
//!   - barge_in clears the pose to neutral + resets the pts anchor
//!   - non-blendshape envelopes (audio_clock, emotion, unknown
//!     kinds) are silently dropped — `CcRenderNode` doesn't run a
//!     state machine like `Live2DRenderNode` does
//!
//! Real Bevy / GPU rendering is out of scope here — see
//! `cc_render_smoke_test` (gated on `CC_AVATAR_GLB_PATH` being set
//! in the env) for the live integration.

#![cfg(feature = "avatar-render-cc-test-support")]

use std::sync::Arc;
use std::sync::Mutex;

use remotemedia_core::data::video::PixelFormat;
use remotemedia_core::data::RuntimeData;
use remotemedia_core::nodes::cc_render::{CcRenderConfig, CcRenderNode, MockRenderer};
use remotemedia_core::nodes::lip_sync::{BlendshapeFrame, ARKIT_BLENDSHAPE_NAMES};
use remotemedia_core::nodes::{AsyncStreamingNode, Tick};
use remotemedia_core::transport::session_control::{wrap_aux_port, BARGE_IN_PORT};

// Local alias matching `lip_sync::blendshape::ARKIT_52` (which isn't
// re-exported from the lip_sync module).
const ARKIT_52: usize = 52;

fn config() -> CcRenderConfig {
    CcRenderConfig {
        glb_path: std::path::PathBuf::new(),
        arkit_map_path: std::path::PathBuf::new(),
        width: 16,
        height: 16,
        fps: 30,
        video_stream_id: "avatar.video".into(),
        scene_glb_path: None,
        realtime_mode: false,
    }
}

fn make_node() -> (Arc<MockRenderer>, CcRenderNode) {
    let mock = Arc::new(MockRenderer::new());
    let node = CcRenderNode::with_renderer(config(), mock.clone());
    (mock, node)
}

fn frame_envelope(weights_set: &[(&str, f32)], pts_ms: u64) -> RuntimeData {
    let mut arr = [0f32; ARKIT_52];
    for (name, w) in weights_set {
        let idx = ARKIT_BLENDSHAPE_NAMES
            .iter()
            .position(|n| n == name)
            .expect("ARKit name");
        arr[idx] = *w;
    }
    let frame = BlendshapeFrame::new(arr, pts_ms, None);
    RuntimeData::Json(frame.to_json())
}

async fn drive(node: &CcRenderNode, input: RuntimeData) -> Vec<RuntimeData> {
    // Pose-state path: process_streaming consumes blendshape / barge
    // envelopes to update internal state. Frame emission happens in
    // `tick()` (pacing-domains migration), so we follow each input
    // with one synthetic tick and return the emitted frames.
    node.process_streaming(input, None, |_out| Ok(()))
        .await
        .expect("process_streaming");
    tick(node).await
}

/// Pacer-side path: invoke `tick()` once and collect emitted frames.
async fn tick(node: &CcRenderNode) -> Vec<RuntimeData> {
    let collected = Arc::new(Mutex::new(Vec::new()));
    let cc = collected.clone();
    let cb: Box<dyn FnMut(RuntimeData) -> std::result::Result<(), remotemedia_core::Error> + Send> =
        Box::new(move |out| {
            cc.lock().unwrap().push(out);
            Ok(())
        });
    let synthetic_tick = Tick {
        clock_id: "wall:30".into(),
        pts_us: 0,
        frame_idx: 0,
        deadline_us: 33_000,
    };
    node.tick(synthetic_tick, None, cb).await.expect("tick");
    let v = collected.lock().unwrap().clone();
    v
}

#[tokio::test]
async fn blendshape_envelope_is_pushed_as_arkit_pose() {
    let (mock, node) = make_node();

    drive(
        &node,
        frame_envelope(&[("jawOpen", 0.7), ("mouthSmileLeft", 0.4)], 1000),
    )
    .await;

    let poses = mock.pushed_poses();
    assert_eq!(poses.len(), 1);
    let p = &poses[0];
    assert_eq!(p.pts_ms, 1000);
    assert!((p.weights["jawOpen"] - 0.7).abs() < 1e-6);
    assert!((p.weights["mouthSmileLeft"] - 0.4).abs() < 1e-6);
    // All ARKit channels should be present in the map (the converter
    // populates every channel — zero for any not in the input).
    assert_eq!(p.weights.len(), ARKIT_BLENDSHAPE_NAMES.len());
    assert_eq!(p.weights["browInnerUp"], 0.0);
}

#[tokio::test]
async fn frame_to_pose_clamps_out_of_range_weights() {
    // BlendshapeFrame doesn't enforce [0,1]; the node clamps at the
    // boundary so the renderer never sees raw model predictions.
    let (mock, node) = make_node();
    let mut arr = [0f32; ARKIT_52];
    let idx = ARKIT_BLENDSHAPE_NAMES
        .iter()
        .position(|n| *n == "jawOpen")
        .unwrap();
    arr[idx] = 1.7; // out of range
    let frame = BlendshapeFrame::new(arr, 0, None);
    drive(&node, RuntimeData::Json(frame.to_json())).await;

    let pose = &mock.pushed_poses()[0];
    assert_eq!(pose.weights["jawOpen"], 1.0);
}

#[tokio::test]
async fn rendered_frames_are_emitted_as_video_with_configured_stream_id() {
    let (mock, node) = make_node();

    // Queue one frame BEFORE driving; the node drains after pushing pose.
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0xAA, 1000));

    let outs = drive(&node, frame_envelope(&[("jawOpen", 0.5)], 1000)).await;
    assert_eq!(outs.len(), 1);
    match &outs[0] {
        RuntimeData::Video {
            width,
            height,
            format,
            stream_id,
            timestamp_us,
            frame_number,
            pixel_data,
            ..
        } => {
            assert_eq!(*width, 16);
            assert_eq!(*height, 16);
            assert_eq!(*format, PixelFormat::Rgba32);
            assert_eq!(stream_id.as_deref(), Some("avatar.video"));
            assert_eq!(*frame_number, 0);
            // First frame anchors the pts → cursor=0 → 0us.
            assert_eq!(*timestamp_us, 0);
            assert_eq!(pixel_data.len(), 16 * 16 * 4);
            assert_eq!(pixel_data[0], 0xAA);
        }
        other => panic!("expected Video, got {:?}", other),
    }
}

#[tokio::test]
async fn frame_pts_anchors_at_first_pose_then_increments() {
    let (mock, node) = make_node();

    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x01, 5_000));
    let outs = drive(&node, frame_envelope(&[("jawOpen", 0.5)], 5_000)).await;
    let RuntimeData::Video {
        timestamp_us,
        frame_number,
        ..
    } = &outs[0]
    else {
        panic!()
    };
    assert_eq!(*timestamp_us, 0);
    assert_eq!(*frame_number, 0);

    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x02, 5_500));
    let outs = drive(&node, frame_envelope(&[("jawOpen", 0.5)], 5_500)).await;
    let RuntimeData::Video {
        timestamp_us,
        frame_number,
        ..
    } = &outs[0]
    else {
        panic!()
    };
    // 500 ms after anchor → 500_000 us.
    assert_eq!(*timestamp_us, 500_000);
    assert_eq!(*frame_number, 1);
}

#[tokio::test]
async fn multiple_queued_frames_emit_in_order() {
    let (mock, node) = make_node();
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x01, 1));
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x02, 2));
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x03, 3));

    let outs = drive(&node, frame_envelope(&[("jawOpen", 0.0)], 1)).await;
    assert_eq!(outs.len(), 3);
    let fills: Vec<u8> = outs
        .iter()
        .map(|o| match o {
            RuntimeData::Video { pixel_data, .. } => pixel_data[0],
            _ => 0xFF,
        })
        .collect();
    assert_eq!(fills, vec![0x01, 0x02, 0x03]);
}

#[tokio::test]
async fn barge_in_envelope_pushes_neutral_pose() {
    let (mock, node) = make_node();

    // Establish a non-neutral pose first.
    drive(&node, frame_envelope(&[("jawOpen", 0.9)], 1000)).await;
    assert!((mock.pushed_poses()[0].weights["jawOpen"] - 0.9).abs() < 1e-6);

    // Now barge: should push a fully-zero pose.
    drive(
        &node,
        RuntimeData::Json(serde_json::json!({"kind":"barge_in"})),
    )
    .await;
    let poses = mock.pushed_poses();
    assert_eq!(poses.len(), 2);
    // After barge, the latest pose must have all weights zero.
    assert!(poses[1].weights.values().all(|w| *w == 0.0));
}

#[tokio::test]
async fn wrapped_aux_port_barge_envelope_is_handled() {
    // The session router wraps barge envelopes in an aux-port wire
    // format (see Live2DRenderNode's symmetric test). CcRenderNode
    // should accept the wrapped form too, via aux_port_of.
    let (mock, node) = make_node();
    drive(&node, frame_envelope(&[("jawOpen", 0.5)], 1)).await;

    let inner = RuntimeData::Json(serde_json::json!({"kind":"barge_in"}));
    let wrapped = wrap_aux_port(BARGE_IN_PORT, inner);
    drive(&node, wrapped).await;

    let poses = mock.pushed_poses();
    assert_eq!(poses.len(), 2);
    assert!(poses[1].weights.values().all(|w| *w == 0.0));
}

#[tokio::test]
async fn unknown_envelope_kinds_are_silently_dropped() {
    let (mock, node) = make_node();

    // None of these are blendshape or barge_in, so the node should
    // ignore them entirely (no pose pushed, no frames produced).
    let cases = vec![
        RuntimeData::Json(serde_json::json!({"kind":"audio_clock","pts_ms":1234})),
        RuntimeData::Json(serde_json::json!({"kind":"emotion","emoji":"😊"})),
        RuntimeData::Json(serde_json::json!({"kind":"totally_unknown"})),
        // Plain text isn't an envelope at all.
        RuntimeData::Text("hello".into()),
    ];
    for envelope in cases {
        let outs = drive(&node, envelope).await;
        assert!(outs.is_empty());
    }
    assert!(mock.pushed_poses().is_empty());
}

#[tokio::test]
async fn tick_drains_pending_frames_independent_of_input() {
    // After the pacing-domains migration, frame emission is detached
    // from input arrival: tick() drains whatever frames the renderer
    // has produced, regardless of whether (or what) input was just
    // received. This is the wall-fallback / wire-clock path that
    // keeps idle video flowing during silence.
    let (mock, node) = make_node();
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x77, 100));

    // tick alone, no input first → still drains.
    let outs = tick(&node).await;
    assert_eq!(outs.len(), 1, "tick must drain queued frames without input");

    // Pose-only input + tick.
    mock.queue_frame(MockRenderer::dummy_frame(16, 16, 0x88, 200));
    let outs = drive(&node, frame_envelope(&[], 200)).await;
    assert_eq!(outs.len(), 1);
}

/// Build a `kind="skeletal_pose"` JSON envelope with all-identity
/// quaternions — same shape `KimodoMotionNode` emits.
fn skeletal_pose_envelope(pts_ms: u64) -> RuntimeData {
    let mut joints = Vec::with_capacity(22);
    for _ in 0..22 {
        joints.push(serde_json::json!([0.0, 0.0, 0.0, 1.0]));
    }
    RuntimeData::Json(serde_json::json!({
        "kind": "skeletal_pose",
        "joint_quats_xyzw": joints,
        "root_pos": [0.0, 0.92, 0.0],
        "frame_idx": 0,
        "fps": 30.0,
        "intent_id": "test-intent",
        "pts_ms": pts_ms,
    }))
}

#[tokio::test]
async fn skeletal_pose_envelope_pushed_to_renderer() {
    // Sending a skeletal_pose envelope should land on the mock as a
    // Some(SkeletalPose), and barge-in should clear it back to None.
    let (mock, node) = make_node();

    let _ = drive(&node, skeletal_pose_envelope(1234)).await;
    let pushed = mock.pushed_skeletal_poses();
    assert_eq!(pushed.len(), 1, "one skeletal pose should land on renderer");
    let pose = pushed[0].as_ref().expect("Some(SkeletalPose)");
    assert_eq!(pose.pts_ms, 1234);
    assert_eq!(pose.joint_quats.len(), 22);
    // Identity quat is (0,0,0,1) — pelvis should round-trip exactly.
    assert_eq!(pose.joint_quats[0], [0.0, 0.0, 0.0, 1.0]);
    // root_pos round-trips from envelope.
    assert_eq!(pose.root_pos, [0.0, 0.92, 0.0]);

    // Barge-in clears the active stream so the AnimationPlayer can resume.
    let barge = wrap_aux_port(BARGE_IN_PORT, RuntimeData::Text("stop".into()));
    let _ = drive(&node, barge).await;
    let pushed = mock.pushed_skeletal_poses();
    assert_eq!(pushed.len(), 2);
    assert!(
        pushed[1].is_none(),
        "barge-in must push None to clear stream"
    );
}

#[tokio::test]
async fn malformed_skeletal_pose_envelope_dropped() {
    // Missing joints / wrong shape: drop the frame, don't crash, don't
    // push anything to the renderer.
    let (mock, node) = make_node();

    // Wrong joint count.
    let bad1 = RuntimeData::Json(serde_json::json!({
        "kind": "skeletal_pose",
        "joint_quats_xyzw": [[0.0, 0.0, 0.0, 1.0]],  // only 1 joint
        "pts_ms": 1,
    }));
    let _ = drive(&node, bad1).await;

    // Joint quat with only 3 components.
    let mut joints = Vec::with_capacity(22);
    for _ in 0..22 {
        joints.push(serde_json::json!([0.0, 0.0, 1.0]));
    }
    let bad2 = RuntimeData::Json(serde_json::json!({
        "kind": "skeletal_pose",
        "joint_quats_xyzw": joints,
        "pts_ms": 2,
    }));
    let _ = drive(&node, bad2).await;

    assert_eq!(
        mock.pushed_skeletal_poses().len(),
        0,
        "malformed skeletal envelopes must not reach renderer"
    );
}

#[test]
fn node_type_string_matches_factory() {
    use remotemedia_core::nodes::AsyncStreamingNode;
    let (_, node) = make_node();
    assert_eq!(node.node_type(), "CcRenderNode");
}
