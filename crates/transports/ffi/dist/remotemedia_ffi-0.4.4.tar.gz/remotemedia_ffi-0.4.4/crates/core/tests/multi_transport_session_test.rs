//! Integration test for concurrent multi-transport usage of shared pipeline sessions.
//!
//! Simulates three different transport types (WebRTC, Telephony, and FFI) joining
//! a single pipeline session by sharing the same logical room key. Verifies that
//! inputs sent by one transport are received by the other transports with correct
//! participant metadata (id, role, track_id, modality) intact.

use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::transport::{
    Participant, PipelineExecutor, SharedPipelineStreamSession,
    StreamSession, TransportData,
};
use std::sync::Arc;

fn passthrough_manifest() -> Manifest {
    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "multi-transport-test".to_string(),
            ..Default::default()
        },
        nodes: vec![NodeManifest {
            id: "passthrough".to_string(),
            node_type: "PassThrough".to_string(),
            params: serde_json::json!({}),
            ..Default::default()
        }],
        connections: vec![],
        python_env: None,
        plugins: Vec::new(),
    }
}

#[tokio::test]
async fn test_multi_transport_shared_session() {
    let executor = Arc::new(PipelineExecutor::new().unwrap());
    let manifest = Arc::new(passthrough_manifest());

    // Create a shared session key (representing a logical room/meeting/session ID)
    let key = "room-multi-transport";

    // 1. Get or create the shared session from the executor
    let shared = executor
        .get_or_create_shared_session(key, Arc::clone(&manifest))
        .await
        .unwrap();

    assert_eq!(shared.key(), key);
    let session_id = shared.session_id().to_string();
    assert!(!session_id.is_empty());

    // 2. Setup the three distinct transport participants
    // - WebRTC participant
    let webrtc_participant = Participant::new("webrtc-peer-1", "client")
        .with_modality("audio")
        .with_track_id("webrtc-track-123")
        .with_display_name("WebRTC User");
    let mut webrtc_session = SharedPipelineStreamSession::new(&shared, webrtc_participant.clone());

    // - Telephony participant
    let telephony_participant = Participant::new("telephony-leg-1", "user")
        .with_modality("audio")
        .with_track_id("sip-call-abc")
        .with_display_name("Telephony User");
    let mut telephony_session = SharedPipelineStreamSession::new(&shared, telephony_participant.clone());

    // - FFI / Python participant
    let ffi_participant = Participant::new("ffi-python-1", "agent")
        .with_modality("audio")
        .with_display_name("Python Agent");
    let mut ffi_session = SharedPipelineStreamSession::new(&shared, ffi_participant.clone());

    // Verify all stream sessions share the exact same underlying pipeline session ID
    assert_eq!(webrtc_session.session_id(), session_id);
    assert_eq!(telephony_session.session_id(), session_id);
    assert_eq!(ffi_session.session_id(), session_id);

    // 3. Test sending and receiving between them
    // Send an audio frame from the FFI client
    let ffi_audio = TransportData::new(RuntimeData::Audio {
        samples: vec![0.5; 160].into(),
        sample_rate: 24000,
        channels: 1,
        stream_id: None,
        timestamp_us: None,
        arrival_ts_us: None,
        metadata: None,
    });
    ffi_session.send_input(ffi_audio).await.unwrap();

    // Since the manifest uses a PassThrough node, the input will be echoed back as output.
    // The shared session broadcasts this output to all participant subscribers.
    
    // --- STEP 1: All participants receive the FFI audio (24000) ---
    // Check FFI receiver
    let output = ffi_session.recv_output().await.unwrap().unwrap();
    if let RuntimeData::Audio { sample_rate, .. } = output.data {
        assert_eq!(sample_rate, 24000);
    } else {
        panic!("Expected audio output");
    }
    assert_eq!(output.get_metadata("participant.id"), Some(&"ffi-python-1".to_string()));
    assert_eq!(output.get_metadata("participant.role"), Some(&"agent".to_string()));
    assert_eq!(output.get_metadata("participant.modality"), Some(&"audio".to_string()));

    // Check WebRTC receiver
    let output = webrtc_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"ffi-python-1".to_string()));
    assert_eq!(output.get_metadata("participant.role"), Some(&"agent".to_string()));

    // Check Telephony receiver
    let output = telephony_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"ffi-python-1".to_string()));

    // Send an audio frame from the WebRTC client
    let webrtc_audio = TransportData::new(RuntimeData::Audio {
        samples: vec![0.0; 160].into(),
        sample_rate: 8000,
        channels: 1,
        stream_id: None,
        timestamp_us: None,
        arrival_ts_us: None,
        metadata: None,
    });
    webrtc_session.send_input(webrtc_audio).await.unwrap();

    // --- STEP 2: All participants receive the WebRTC audio (8000) ---
    // Check FFI receiver
    let output = ffi_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"webrtc-peer-1".to_string()));
    assert_eq!(output.get_metadata("participant.role"), Some(&"client".to_string()));
    assert_eq!(output.get_metadata("participant.modality"), Some(&"audio".to_string()));

    // Check WebRTC receiver
    let output = webrtc_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"webrtc-peer-1".to_string()));

    // Check Telephony receiver
    let output = telephony_session.recv_output().await.unwrap().unwrap();
    if let RuntimeData::Audio { sample_rate, channels, .. } = output.data {
        assert_eq!(sample_rate, 8000);
        assert_eq!(channels, 1);
    } else {
        panic!("Expected audio output");
    }
    assert_eq!(output.get_metadata("participant.id"), Some(&"webrtc-peer-1".to_string()));
    assert_eq!(output.get_metadata("participant.role"), Some(&"client".to_string()));
    assert_eq!(output.get_metadata("participant.modality"), Some(&"audio".to_string()));
    assert_eq!(output.get_metadata("participant.track_id"), Some(&"webrtc-track-123".to_string()));

    // Send an audio frame from the Telephony client
    let telephony_audio = TransportData::new(RuntimeData::Audio {
        samples: vec![0.1; 160].into(),
        sample_rate: 16000,
        channels: 1,
        stream_id: None,
        timestamp_us: None,
        arrival_ts_us: None,
        metadata: None,
    });
    telephony_session.send_input(telephony_audio).await.unwrap();

    // --- STEP 3: All participants receive the Telephony audio (16000) ---
    // Check FFI receiver
    let output = ffi_session.recv_output().await.unwrap().unwrap();
    if let RuntimeData::Audio { sample_rate, .. } = output.data {
        assert_eq!(sample_rate, 16000);
    } else {
        panic!("Expected audio output");
    }
    assert_eq!(output.get_metadata("participant.id"), Some(&"telephony-leg-1".to_string()));
    assert_eq!(output.get_metadata("participant.role"), Some(&"user".to_string()));
    assert_eq!(output.get_metadata("participant.track_id"), Some(&"sip-call-abc".to_string()));

    // Check WebRTC receiver
    let output = webrtc_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"telephony-leg-1".to_string()));

    // Check Telephony receiver
    let output = telephony_session.recv_output().await.unwrap().unwrap();
    assert_eq!(output.get_metadata("participant.id"), Some(&"telephony-leg-1".to_string()));

    // 4. Verify clean shutdown
    webrtc_session.close().await.unwrap();
    telephony_session.close().await.unwrap();
    ffi_session.close().await.unwrap();

    assert!(!webrtc_session.is_active());
    assert!(!telephony_session.is_active());
    assert!(!ffi_session.is_active());

    shared.close().await.unwrap();
    assert!(!shared.is_active().await);
}
