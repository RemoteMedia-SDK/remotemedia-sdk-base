//! Integration: `IdleAnimationNode` registered in the default streaming
//! registry runs end-to-end through the session router's wall pacer at
//! its configured rate, emitting well-formed `idle_pose` envelopes that
//! reach the client output channel.
//!
//! This is the smoke test for Phase 6.1 of the pacing-domains spec:
//! a real (non-fixture) `SourceWall` node, registered through the
//! standard `CoreNodesProvider` inventory, paced by the runtime, with
//! output flowing through the standard fan-out + sink path.

use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::streaming_registry::create_default_streaming_registry;
use remotemedia_core::transport::session_router::{SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY};

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

fn idle_pipeline(rate_hz: u32) -> Manifest {
    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "idle-animation-e2e".to_string(),
            ..Default::default()
        },
        nodes: vec![NodeManifest {
            id: "idle".to_string(),
            node_type: "IdleAnimationNode".to_string(),
            // Tight blink window so the test can verify both blinking
            // and non-blinking frames within the 600ms run.
            params: serde_json::json!({
                "rate_hz": rate_hz,
                "breathe_period_sec": 0.5,
                "blink_period_frames": 4,
                "blink_duration_frames": 1,
            }),
            ..Default::default()
        }],
        connections: Vec::<Connection>::new(),
        python_env: None,
        plugins: Vec::new(),
    }
}

/// `IdleAnimationNode` ticks at its configured rate via the session
/// router's wall pacer. Outputs reach the client channel as
/// `RuntimeData::Json` carrying the idle_pose envelope.
#[tokio::test]
async fn idle_animation_runs_via_default_registry() {
    let session_id = "idle-animation-e2e".to_string();
    let manifest = Arc::new(idle_pipeline(20));
    let registry = Arc::new(create_default_streaming_registry());

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (mut router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    let _input_tx = router.get_input_sender();
    let handle = router.start();

    // Collect ~600ms worth of ticks at 20Hz = 12 expected frames.
    let mut envelopes: Vec<serde_json::Value> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(600);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Json(v) = out {
                    envelopes.push(v);
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    // Sanity: we got *some* output and *not too much* (allow ±50% slack
    // for CI scheduling jitter).
    let n = envelopes.len();
    assert!(
        n >= 6 && n <= 18,
        "idle animation produced {} frames in 600ms; expected ~12 (20Hz)",
        n
    );

    // Every envelope must be well-formed.
    for v in &envelopes {
        assert_eq!(
            v.get("kind").and_then(|x| x.as_str()),
            Some("idle_pose"),
            "envelope missing kind=idle_pose: {:?}",
            v
        );
        assert!(v.get("frame_idx").and_then(|x| x.as_u64()).is_some());
        assert!(v.get("pts_us").and_then(|x| x.as_u64()).is_some());
        assert!(v.get("phase").and_then(|x| x.as_f64()).is_some());
        assert!(v.get("blink").and_then(|x| x.as_f64()).is_some());
    }

    // We configured `blink_period_frames=4 / blink_duration_frames=1`,
    // so roughly 25% of frames should be in a blink (blink == 1.0). With
    // 12 expected frames, we should see at least one blinking frame and
    // at least several non-blinking frames.
    let blinking = envelopes
        .iter()
        .filter(|v| v.get("blink").and_then(|x| x.as_f64()).unwrap_or(0.0) > 0.5)
        .count();
    let non_blinking = n - blinking;
    assert!(
        blinking >= 1,
        "expected at least one blink in {} frames; got 0",
        n
    );
    assert!(
        non_blinking >= 3,
        "expected several non-blinking frames in {} frames; got {}",
        n,
        non_blinking
    );

    drop(_input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
