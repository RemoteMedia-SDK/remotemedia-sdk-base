//! Integration: snapshot connections wired by the session router from
//! manifest. A `SourceWall` producer publishes typed values to an
//! `OutputPort<u32>`; a tick-driven consumer reads via
//! `remotemedia_traits::runtime_context::snapshot::<u32>(ctx, port)` on its own clock and forwards the
//! observed value to the client output as a sentinel envelope.
//!
//! This is the smoke test for Phase 4.4 of the pacing-domains spec:
//! the session router walks `manifest.connections`, consults the
//! consumer factory's `input_port_kinds()`, and for any `Snapshot`
//! port installs the producer's `Arc<dyn SnapshotPort>` into the
//! consumer's `NodeRuntimeContext::input_snapshots` rather than wiring
//! an mpsc channel.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::ports::{OutputPort, PortKind, SnapshotPort};
use remotemedia_core::nodes::streaming_node::{StreamingNode, StreamingNodeFactory};
use remotemedia_core::nodes::{
    NodeRuntimeContext, NodeRuntimeContextRead, PacingNature, StreamingNodeRegistry, Tick,
};
use remotemedia_core::transport::session_router::{SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY};
use remotemedia_core::Error;
use serde_json::Value;

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

/// Producer: SourceWall(hz) node. Publishes a monotonically increasing
/// `u32` to its `value` snapshot output port on every tick.
struct ValueSourceNode {
    node_id: String,
    rate_hz: u32,
    value_out: OutputPort<u32>,
    counter: AtomicU64,
}

impl ValueSourceNode {
    fn new(node_id: String, rate_hz: u32) -> Self {
        Self {
            node_id,
            rate_hz,
            value_out: OutputPort::empty(),
            counter: AtomicU64::new(0),
        }
    }
}

#[async_trait::async_trait]
impl StreamingNode for ValueSourceNode {
    fn node_type(&self) -> &str {
        "ValueSourceNode"
    }
    fn node_id(&self) -> &str {
        &self.node_id
    }
    fn pacing_nature(&self) -> PacingNature {
        PacingNature::SourceWall(self.rate_hz)
    }
    fn is_multi_input(&self) -> bool {
        false
    }
    async fn process_async(
        &self,
        _data: RuntimeData,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("source-only".into()))
    }
    async fn process_multi_async(
        &self,
        _inputs: HashMap<String, RuntimeData>,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("source-only".into()))
    }
    async fn tick(
        &self,
        tick: Tick,
        _ctx: &dyn NodeRuntimeContextRead,
        _cb: Box<dyn FnMut(RuntimeData) -> Result<(), Error> + Send>,
    ) -> Result<(), Error> {
        let n = self.counter.fetch_add(1, Ordering::Relaxed) as u32;
        self.value_out.publish(n, tick.pts_us);
        Ok(())
    }
    fn snapshot_outputs(&self) -> HashMap<String, Arc<dyn SnapshotPort>> {
        let mut m: HashMap<String, Arc<dyn SnapshotPort>> = HashMap::new();
        m.insert("value".to_string(), Arc::new(self.value_out.input()));
        m
    }
}

struct ValueSourceFactory;

impl StreamingNodeFactory for ValueSourceFactory {
    fn create(
        &self,
        node_id: String,
        params: &Value,
        _session_id: Option<String>,
    ) -> Result<Box<dyn StreamingNode>, Error> {
        let hz = params.get("rate_hz").and_then(|v| v.as_u64()).unwrap_or(20) as u32;
        Ok(Box::new(ValueSourceNode::new(node_id, hz)))
    }
    fn node_type(&self) -> &str {
        "ValueSourceNode"
    }
    fn output_port_kinds(&self) -> HashMap<String, PortKind> {
        let mut m = HashMap::new();
        m.insert("value".to_string(), PortKind::Snapshot);
        m
    }
}

/// Consumer: SourceWall(hz) node. Reads `value` snapshot via its ctx and
/// emits the observed integer to the client as a Json envelope. If the
/// snapshot is unset it emits `null`.
struct SnapshotConsumerNode {
    node_id: String,
    rate_hz: u32,
}

#[async_trait::async_trait]
impl StreamingNode for SnapshotConsumerNode {
    fn node_type(&self) -> &str {
        "SnapshotConsumerNode"
    }
    fn node_id(&self) -> &str {
        &self.node_id
    }
    fn pacing_nature(&self) -> PacingNature {
        PacingNature::SourceWall(self.rate_hz)
    }
    fn is_multi_input(&self) -> bool {
        false
    }
    async fn process_async(
        &self,
        _data: RuntimeData,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("tick-only".into()))
    }
    async fn process_multi_async(
        &self,
        _inputs: HashMap<String, RuntimeData>,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("tick-only".into()))
    }
    async fn tick(
        &self,
        _tick: Tick,
        ctx: &dyn NodeRuntimeContextRead,
        mut cb: Box<dyn FnMut(RuntimeData) -> Result<(), Error> + Send>,
    ) -> Result<(), Error> {
        let snap = remotemedia_traits::runtime_context::snapshot::<u32>(ctx, "upstream_value");
        let value = snap.map(|s| s.value);
        let env = serde_json::json!({
            "kind": "consumed",
            "value": value,
        });
        cb(RuntimeData::Json(env))?;
        Ok(())
    }
}

struct SnapshotConsumerFactory;

impl StreamingNodeFactory for SnapshotConsumerFactory {
    fn create(
        &self,
        node_id: String,
        params: &Value,
        _session_id: Option<String>,
    ) -> Result<Box<dyn StreamingNode>, Error> {
        let hz = params.get("rate_hz").and_then(|v| v.as_u64()).unwrap_or(20) as u32;
        Ok(Box::new(SnapshotConsumerNode {
            node_id,
            rate_hz: hz,
        }))
    }
    fn node_type(&self) -> &str {
        "SnapshotConsumerNode"
    }
    fn input_port_kinds(&self) -> HashMap<String, PortKind> {
        let mut m = HashMap::new();
        m.insert("upstream_value".to_string(), PortKind::Snapshot);
        m
    }
}

/// `to_port = "upstream_value"` declared `Snapshot` on the consumer
/// factory and `from_port = "value"` declared `Snapshot` on the
/// producer factory: the session router must wire the producer's
/// `OutputPort<u32>` read handle into the consumer's
/// `NodeRuntimeContext::input_snapshots["upstream_value"]`. The
/// consumer then observes the producer's published values on every
/// tick.
#[tokio::test]
async fn snapshot_connection_round_trips_through_session_router() {
    let session_id = "snapshot-wiring-e2e".to_string();
    let manifest = Arc::new(Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "snapshot-wiring".to_string(),
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "src".to_string(),
                node_type: "ValueSourceNode".to_string(),
                params: serde_json::json!({ "rate_hz": 50 }),
                ..Default::default()
            },
            NodeManifest {
                id: "snk".to_string(),
                node_type: "SnapshotConsumerNode".to_string(),
                params: serde_json::json!({ "rate_hz": 20 }),
                ..Default::default()
            },
        ],
        connections: vec![Connection {
            from: "src".to_string(),
            to: "snk".to_string(),
            from_port: Some("value".to_string()),
            to_port: Some("upstream_value".to_string()),
        }],
        python_env: None,
        plugins: Vec::new(),
    });

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(ValueSourceFactory));
    registry.register(Arc::new(SnapshotConsumerFactory));
    let registry = Arc::new(registry);

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    let _input_tx = router.get_input_sender();
    let handle = router.start();

    // Collect ~600 ms of consumer output (consumer ticks at 20 Hz so we
    // expect ~12 envelopes; producer ticks at 50 Hz so by the time the
    // consumer observes its first snapshot the producer has already
    // published several values).
    let mut envelopes: Vec<serde_json::Value> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(600);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Json(v) = out {
                    if v.get("kind").and_then(|x| x.as_str()) == Some("consumed") {
                        envelopes.push(v);
                    }
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    // Got at least a few consumer ticks.
    assert!(
        envelopes.len() >= 6,
        "expected ≥6 consumer ticks in 600ms; got {}",
        envelopes.len()
    );

    // Snapshot wiring proof: the consumer must observe a non-null
    // value (the wire is populated). We additionally check that the
    // observed values are non-decreasing — the producer counter only
    // goes up — so we know reads aren't returning a stale or random
    // value from somewhere unrelated.
    let mut last: Option<u64> = None;
    let mut saw_some_value = false;
    for v in &envelopes {
        match v.get("value").and_then(|x| x.as_u64()) {
            Some(n) => {
                saw_some_value = true;
                if let Some(prev) = last {
                    assert!(
                        n >= prev,
                        "snapshot value went backwards: {} -> {}",
                        prev,
                        n
                    );
                }
                last = Some(n);
            }
            None => {
                // Allowed only at the very start before the producer
                // has emitted its first publish.
                assert!(
                    !saw_some_value,
                    "consumer observed null after seeing a value: {:?}",
                    v
                );
            }
        }
    }
    assert!(
        saw_some_value,
        "consumer never saw a snapshot value — wire wasn't installed"
    );

    drop(_input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}

/// Negative path: a consumer with the same input port name but no
/// `Snapshot` declaration falls back to streaming wiring (creates an
/// mpsc channel) and never receives a snapshot. We don't test the
/// streaming-fallback channel directly here — the existing
/// `idle_animation_runs_via_default_registry` integration test covers
/// that path. This test pins the contract that the `Snapshot`
/// declaration is what flips the wiring.
#[tokio::test]
async fn unset_snapshot_input_returns_none() {
    // Consumer that declares NO snapshot inputs. With no declaration,
    // the router uses Stream wiring; the consumer's
    // `remotemedia_traits::runtime_context::snapshot::<u32>(ctx, "upstream_value")` always returns None
    // because `input_snapshots` is empty.
    struct StreamConsumer {
        node_id: String,
        rate_hz: u32,
    }

    #[async_trait::async_trait]
    impl StreamingNode for StreamConsumer {
        fn node_type(&self) -> &str {
            "StreamConsumer"
        }
        fn node_id(&self) -> &str {
            &self.node_id
        }
        fn pacing_nature(&self) -> PacingNature {
            PacingNature::SourceWall(self.rate_hz)
        }
        fn is_multi_input(&self) -> bool {
            false
        }
        async fn process_async(
            &self,
            _: RuntimeData,
            _: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData, Error> {
            Err(Error::Execution("tick-only".into()))
        }
        async fn process_multi_async(
            &self,
            _: HashMap<String, RuntimeData>,
            _: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData, Error> {
            Err(Error::Execution("tick-only".into()))
        }
        async fn tick(
            &self,
            _: Tick,
            ctx: &dyn NodeRuntimeContextRead,
            mut cb: Box<dyn FnMut(RuntimeData) -> Result<(), Error> + Send>,
        ) -> Result<(), Error> {
            let snap = remotemedia_traits::runtime_context::snapshot::<u32>(ctx, "upstream_value");
            let env = serde_json::json!({ "kind": "consumed", "value": snap.map(|s| s.value) });
            cb(RuntimeData::Json(env))?;
            Ok(())
        }
    }

    struct StreamConsumerFactory;
    impl StreamingNodeFactory for StreamConsumerFactory {
        fn create(
            &self,
            node_id: String,
            _: &Value,
            _: Option<String>,
        ) -> Result<Box<dyn StreamingNode>, Error> {
            Ok(Box::new(StreamConsumer {
                node_id,
                rate_hz: 20,
            }))
        }
        fn node_type(&self) -> &str {
            "StreamConsumer"
        }
        // No `input_port_kinds` override — defaults to Stream.
    }

    let session_id = "snapshot-wiring-negative".to_string();
    let manifest = Arc::new(Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "snapshot-wiring-negative".to_string(),
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "src".to_string(),
                node_type: "ValueSourceNode".to_string(),
                params: serde_json::json!({ "rate_hz": 50 }),
                ..Default::default()
            },
            NodeManifest {
                id: "snk".to_string(),
                node_type: "StreamConsumer".to_string(),
                params: serde_json::json!({}),
                ..Default::default()
            },
        ],
        // Without `to_port` declared as Snapshot on the factory the
        // router treats this as a stream connection.
        connections: vec![Connection {
            from: "src".to_string(),
            to: "snk".to_string(),
            from_port: Some("value".to_string()),
            to_port: Some("upstream_value".to_string()),
        }],
        python_env: None,
        plugins: Vec::new(),
    });

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(ValueSourceFactory));
    registry.register(Arc::new(StreamConsumerFactory));
    let registry = Arc::new(registry);

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (router, _shutdown_tx) =
        SessionRouter::new(session_id, manifest, registry, output_router).unwrap();
    let _input_tx = router.get_input_sender();
    let handle = router.start();

    let mut envelopes: Vec<serde_json::Value> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(400);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Json(v) = out {
                    if v.get("kind").and_then(|x| x.as_str()) == Some("consumed") {
                        envelopes.push(v);
                    }
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    assert!(
        !envelopes.is_empty(),
        "consumer never ticked — pacer broken"
    );
    for v in &envelopes {
        assert!(
            v.get("value").map(|x| x.is_null()).unwrap_or(true),
            "consumer with no Snapshot declaration unexpectedly received: {:?}",
            v
        );
    }

    drop(_input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
