//! Shared helpers for integration tests against `SessionRouter`.
//!
//! `SessionRouter::new` now takes a `ClientOutputRouter` (kind-split:
//! audio/video/data) instead of a single `mpsc::Sender<RuntimeData>`.
//! Most pre-existing tests just want "any output" from a single channel,
//! so this helper merges the three kind-rx channels back into one
//! `mpsc::Receiver<RuntimeData>` via a forwarder task.
//!
//! Included by tests via `#[path = "router_test_utils.rs"] mod router_test_utils;`.

#![allow(dead_code)]

use remotemedia_core::data::RuntimeData;
use remotemedia_core::transport::ClientOutputRouter;
use tokio::sync::mpsc;

/// Create a `ClientOutputRouter` plus a single merged `Receiver<RuntimeData>`
/// that drains Audio + Video + Data into one stream.
///
/// `capacity` sizes each underlying kind channel and the merged channel.
pub fn make_test_output_router(
    capacity: usize,
) -> (ClientOutputRouter, mpsc::Receiver<RuntimeData>) {
    let (router, rxs) = ClientOutputRouter::new(capacity);
    let merged_capacity = capacity.saturating_mul(3).max(1);
    let (merged_tx, merged_rx) = mpsc::channel(merged_capacity);
    let mut audio_rx = Some(rxs.audio_rx);
    let mut video_rx = Some(rxs.video_rx);
    let mut data_rx = Some(rxs.data_rx);
    tokio::spawn(async move {
        loop {
            // Once all three kind-rx channels have closed, stop.
            if audio_rx.is_none() && video_rx.is_none() && data_rx.is_none() {
                break;
            }
            tokio::select! {
                maybe = async { audio_rx.as_mut().unwrap().recv().await }, if audio_rx.is_some() => {
                    match maybe {
                        Some(d) => { if merged_tx.send(d).await.is_err() { return; } }
                        None => { audio_rx = None; }
                    }
                },
                maybe = async { video_rx.as_mut().unwrap().recv().await }, if video_rx.is_some() => {
                    match maybe {
                        Some(d) => { if merged_tx.send(d).await.is_err() { return; } }
                        None => { video_rx = None; }
                    }
                },
                maybe = async { data_rx.as_mut().unwrap().recv().await }, if data_rx.is_some() => {
                    match maybe {
                        Some(d) => { if merged_tx.send(d).await.is_err() { return; } }
                        None => { data_rx = None; }
                    }
                },
            }
        }
    });
    (router, merged_rx)
}
