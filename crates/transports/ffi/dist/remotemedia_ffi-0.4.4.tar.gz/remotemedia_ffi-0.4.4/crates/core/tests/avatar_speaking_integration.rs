//! Integration: full reactive→clocked seam through the manifest.
//!
//! `Audio2FaceNode` (Reactive) consumes injected audio chunks and
//! publishes `AvatarWeights` to its snapshot output. `AvatarNode`
//! (SourceWall fallback pacer until Phase 5.4 wire-bound pacer ships)
//! reads those weights via `ctx.snapshot::<AvatarWeights>("weights")`
//! on every tick. When weights are fresh the avatar emits a Speaking
//! frame (sentinel `0xAA`); when audio stops and the weights snapshot
//! becomes stale, it falls back to the cold-start sentinel `0x00`
//! (no idle node in this manifest) within the freshness window.
//!
//! Smoke test for Phase 6.3 of the pacing-domains spec: end-to-end
//! reactive lipsync producer ↔ tick-driven avatar via the default
//! registry and manifest snapshot wiring.

use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::audio_samples::AudioSamples;
use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::streaming_registry::create_default_streaming_registry;
use remotemedia_core::transport::session_router::{
    DataPacket, SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY,
};

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

fn manifest() -> Manifest {
    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "avatar-speaking-e2e".to_string(),
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "a2f".to_string(),
                node_type: "Audio2FaceNode".to_string(),
                params: serde_json::json!({ "mouth_open_scale": 6.0 }),
                ..Default::default()
            },
            NodeManifest {
                id: "avatar".to_string(),
                node_type: "AvatarNode".to_string(),
                params: serde_json::json!({
                    "rate_hz": 30,
                    "weights_fresh_us": 200_000,
                    "width": 256,
                    "height": 256,
                }),
                ..Default::default()
            },
        ],
        // Snapshot wire: a2f.weights -> avatar.weights. The router
        // resolves this to PortKind::Snapshot via the consumer's
        // input_port_kinds() and installs the producer's read handle
        // into the avatar's NodeRuntimeContext::input_snapshots.
        connections: vec![Connection {
            from: "a2f".to_string(),
            to: "avatar".to_string(),
            from_port: Some("weights".to_string()),
            to_port: Some("weights".to_string()),
        }],
        python_env: None,
        plugins: Vec::new(),
    }
}

fn audio_chunk(sample_value: f32, pts_us: u64) -> RuntimeData {
    RuntimeData::Audio {
        samples: AudioSamples::Vec(vec![sample_value; 320]),
        sample_rate: 16_000,
        channels: 1,
        stream_id: None,
        timestamp_us: Some(pts_us),
        arrival_ts_us: None,
        metadata: None,
    }
}

/// While audio is flowing the avatar must observe fresh weights and
/// emit speaking frames (sentinel `0xAA`). When audio stops, the
/// snapshot ages out and the avatar transitions to cold (no idle node
/// is wired in this manifest) within the freshness window.
#[tokio::test]
async fn avatar_renders_speaking_when_audio_flows() {
    let session_id = "avatar-speaking-e2e".to_string();
    let manifest = Arc::new(manifest());
    let registry = Arc::new(create_default_streaming_registry());

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    let input_tx = router.get_input_sender();
    let handle = router.start();

    // Drive audio chunks at ~50 Hz for 400 ms — well within
    // weights_fresh_us = 200ms so every avatar tick sees fresh
    // weights and emits Speaking.
    let audio_driver = tokio::spawn({
        let input_tx = input_tx.clone();
        let session_id = session_id.clone();
        async move {
            let start = std::time::Instant::now();
            let mut seq: u64 = 0;
            while start.elapsed() < Duration::from_millis(400) {
                let pts = start.elapsed().as_micros() as u64;
                let pkt = DataPacket {
                    data: audio_chunk(0.1, pts),
                    from_node: "external".to_string(),
                    to_node: Some("a2f".to_string()),
                    session_id: session_id.clone(),
                    sequence: seq,
                    sub_sequence: 0,
                    metadata: std::collections::HashMap::new(),
                };
                seq += 1;
                if input_tx.send(pkt).await.is_err() {
                    break;
                }
                tokio::time::sleep(Duration::from_millis(20)).await;
            }
        }
    });

    // Collect ~600 ms total — 400 ms with audio + 200 ms of silence.
    let mut frames: Vec<(u64, Vec<u8>)> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(600);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Video {
                    pixel_data,
                    timestamp_us,
                    width,
                    height,
                    ..
                } = out
                {
                    assert_eq!(width, 256);
                    assert_eq!(height, 256);
                    frames.push((timestamp_us, pixel_data));
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    let _ = audio_driver.await;

    let n = frames.len();
    assert!(
        n >= 12 && n <= 24,
        "avatar produced {} frames in 600ms; expected ~18 (30 Hz)",
        n
    );

    let speaking = frames.iter().filter(|(_, p)| p == &[0xAA]).count();
    let cold = frames.iter().filter(|(_, p)| p == &[0x00]).count();
    let idle = frames.iter().filter(|(_, p)| p == &[0xBB]).count();

    assert_eq!(
        idle, 0,
        "no idle node wired; avatar must never enter idle path; got {} idle frames",
        idle
    );
    // While audio is flowing the avatar should emit speaking frames.
    // The exact number depends on scheduling, but the majority of the
    // first 400 ms (12 of the 18 expected frames at 30 Hz) must be
    // speaking. Allow generous slack: at least 6 speaking frames,
    // proving the snapshot wiring delivers fresh weights.
    assert!(
        speaking >= 6,
        "expected at least 6 speaking frames while audio flowed; got speaking={} cold={} of {}",
        speaking,
        cold,
        n
    );
    // Some cold frames are acceptable at the very start (before the
    // first audio chunk lands) and at the end (after audio stops and
    // weights age out).
    assert!(
        cold <= n - speaking + 2,
        "unexpected pixel sentinel distribution: speaking={} cold={} idle={} total={}",
        speaking,
        cold,
        idle,
        n
    );

    drop(input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
