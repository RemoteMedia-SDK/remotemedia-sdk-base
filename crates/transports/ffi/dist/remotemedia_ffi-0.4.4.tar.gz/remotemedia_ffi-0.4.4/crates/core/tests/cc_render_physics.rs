//! End-to-end physics integration tests. Gated on
//! `avatar-render-cc-physics` + a runtime check for headed render
//! (skipped in CI without GPU).

#![cfg(feature = "avatar-render-cc-physics")]

#[test]
fn install_does_not_panic() {
    use bevy::prelude::*;

    use remotemedia_core::nodes::cc_render::renderer::PlayVolume;
    use remotemedia_core::nodes::cc_render::PhysicsConfig;

    let mut app = App::new();
    app.add_plugins(MinimalPlugins);
    app.add_plugins(TransformPlugin);
    // Rapier's `async-collider` feature reads `Assets<Mesh>`, which
    // requires AssetPlugin + the Mesh asset registration that ships
    // with MeshPlugin. MinimalPlugins doesn't include either.
    app.add_plugins(bevy::asset::AssetPlugin::default());
    app.init_asset::<bevy::render::mesh::Mesh>();
    app.add_plugins(bevy::scene::ScenePlugin);

    let cfg = PhysicsConfig {
        gravity: [0.0, -9.81, 0.0],
        timestep_hz: 60,
        max_substeps_per_frame: 4,
        ground_y: Some(0.0),
        play_volume: Some(PlayVolume {
            half_extents_xz: 1.0,
            ceiling_y: 2.0,
        }),
        sidecar_path: None,
        ..Default::default()
    };

    remotemedia_core::nodes::cc_render::bevy_app_install_physics(
        &mut app,
        cfg,
        std::path::PathBuf::new(),
    );

    // One Update tick should run cleanly.
    app.update();

    // Verify the Startup system actually spawned the static colliders.
    // 1 ground + 4 walls + 1 ceiling = 6 entities. spawn_ground always
    // runs; spawn_walls only when play_volume is Some (which it is here).
    let world = app.world_mut();
    let mut q = world.query::<&Name>();
    let names: Vec<String> = q.iter(world).map(|n| n.as_str().to_string()).collect();
    assert!(
        names.iter().any(|n| n == "PhysicsGround"),
        "ground not spawned; got: {:?}",
        names
    );
    let wall_count = names.iter().filter(|n| n.starts_with("Wall")).count();
    assert_eq!(
        wall_count, 5,
        "expected 4 walls + ceiling; got {} (names: {:?})",
        wall_count, names
    );
}

#[test]
fn spawn_prop_falls_to_ground() {
    use bevy::prelude::*;
    use remotemedia_core::nodes::cc_render::renderer::{
        GrabOrRelease, PropCmd, PropId, PropShape, SceneState,
    };
    use remotemedia_core::nodes::cc_render::PhysicsConfig;

    let mut app = App::new();
    app.add_plugins(MinimalPlugins);
    app.add_plugins(TransformPlugin);
    // Required for bevy_rapier3d 0.28 async-collider feature.
    app.add_plugins(bevy::asset::AssetPlugin::default());
    app.init_asset::<bevy::render::mesh::Mesh>();
    app.add_plugins(bevy::scene::ScenePlugin);

    let cfg = PhysicsConfig {
        gravity: [0.0, -9.81, 0.0],
        timestep_hz: 60,
        max_substeps_per_frame: 4,
        ground_y: Some(0.0),
        play_volume: None,
        sidecar_path: None,
        ..Default::default()
    };

    let (prop_tx, prop_rx) = tokio::sync::mpsc::unbounded_channel::<PropCmd>();
    let (_dspn_tx, dspn_rx) = tokio::sync::mpsc::unbounded_channel::<PropId>();
    let (_grab_tx, grab_rx) = tokio::sync::mpsc::unbounded_channel::<GrabOrRelease>();
    let (state_tx, state_rx) = tokio::sync::watch::channel(SceneState::default());

    remotemedia_core::nodes::cc_render::bevy_app_install_physics(
        &mut app,
        cfg,
        std::path::PathBuf::new(),
    );
    remotemedia_core::nodes::cc_render::bevy_app_install_physics_channels(
        &mut app, prop_rx, dspn_rx, grab_rx, state_tx,
    );

    // Spawn a sphere 1m above the ground.
    let mut t = identity4x4();
    // 4x4 column-major: column 3 holds the translation.
    t[3][1] = 1.0;
    prop_tx
        .send(PropCmd {
            id: "ball".into(),
            shape: PropShape::Sphere { radius: 0.05 },
            initial_transform: t,
            mass_kg: 0.2,
            grasp: None,
            friction: 0.7,
            restitution: 0.1,
        })
        .unwrap();

    // Step the app for ~1.5 seconds of physics (60 Hz timestep, 90 ticks).
    for _ in 0..90 {
        app.update();
    }

    let state = state_rx.borrow().clone();
    let ball = state
        .props
        .iter()
        .find(|p| p.id == "ball")
        .expect("ball should exist");
    let y = ball.transform[3][1];
    assert!(y < 0.10, "ball should be near ground, but y={}", y);
}

#[test]
fn meshglb_prop_uses_placeholder_ball() {
    // PropShape::MeshGlb is a documented async-collider follow-up; today
    // it falls back to a 5cm ball + sets `loading: true` on the snapshot.
    // Lock that placeholder behavior in so a future async-collider patch
    // doesn't silently drop the loading flag (downstream consumers look
    // at it to defer grab attempts).
    use bevy::prelude::*;
    use remotemedia_core::nodes::cc_render::renderer::{
        GrabOrRelease, PropCmd, PropId, PropShape, SceneState,
    };
    use remotemedia_core::nodes::cc_render::PhysicsConfig;

    let mut app = App::new();
    app.add_plugins(MinimalPlugins);
    app.add_plugins(TransformPlugin);
    app.add_plugins(bevy::asset::AssetPlugin::default());
    app.init_asset::<bevy::render::mesh::Mesh>();
    app.add_plugins(bevy::scene::ScenePlugin);

    let cfg = PhysicsConfig {
        ground_y: Some(0.0),
        play_volume: None,
        ..Default::default()
    };

    let (prop_tx, prop_rx) = tokio::sync::mpsc::unbounded_channel::<PropCmd>();
    let (_dspn_tx, dspn_rx) = tokio::sync::mpsc::unbounded_channel::<PropId>();
    let (_grab_tx, grab_rx) = tokio::sync::mpsc::unbounded_channel::<GrabOrRelease>();
    let (state_tx, state_rx) = tokio::sync::watch::channel(SceneState::default());

    remotemedia_core::nodes::cc_render::bevy_app_install_physics(
        &mut app,
        cfg,
        std::path::PathBuf::new(),
    );
    remotemedia_core::nodes::cc_render::bevy_app_install_physics_channels(
        &mut app, prop_rx, dspn_rx, grab_rx, state_tx,
    );

    // Spawn a MeshGlb prop. The path doesn't have to exist — the
    // current implementation falls back to a placeholder before any
    // asset load happens.
    let mut t = identity4x4();
    t[3][1] = 0.5; // 50cm above ground so it has somewhere to fall to
    prop_tx
        .send(PropCmd {
            id: "phantom_mesh".into(),
            shape: PropShape::MeshGlb {
                path: std::path::PathBuf::from("/nonexistent/avatar.glb"),
                scale: 1.0,
            },
            initial_transform: t,
            mass_kg: 0.5,
            grasp: None,
            friction: 0.7,
            restitution: 0.1,
        })
        .unwrap();

    // Two ticks: one for the spawn cmd to drain, one for scene_state
    // to publish.
    for _ in 0..3 {
        app.update();
    }

    let state = state_rx.borrow().clone();
    let mesh = state
        .props
        .iter()
        .find(|p| p.id == "phantom_mesh")
        .expect("phantom_mesh prop should exist in snapshot");
    assert!(
        mesh.loading,
        "MeshGlb prop should have loading=true (async-collider placeholder); got {:?}",
        mesh,
    );
}

fn identity4x4() -> [[f32; 4]; 4] {
    [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]
}
