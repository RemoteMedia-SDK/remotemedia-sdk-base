//! Smoke test for `AffectSimulatorNode` (spike-i Tier A).
//!
//! Drives the node through a deterministic 3-turn fake conversation
//! without standing up the full WebRTC pipeline:
//!
//! 1. T+0.0s — VAD `is_speech_start = true` (the first one of the
//!    session, decoded as `EventKind::UserGreeting`).
//! 2. T+0.4s — VAD `is_speech_end = true` (decoded as `UserQuestion`).
//! 3. T+0.6s — Transcript text "I just lost my job" (decoded as
//!    `UserQuestion` for Tier A; Tier B will route this through a
//!    classifier that maps it to `UserDistress`).
//! 4. T+1.6s — Transcript text "thanks for listening" (another
//!    `UserQuestion` for now).
//!
//! Between events we fire `tick()` at the simulator's 5 Hz rate
//! (200 ms apart) so each phase produces visible state evolution. The
//! emitted aux-port envelopes are printed in human-readable form, plus
//! the per-tick V/A/D target so you can eyeball the trajectory.
//!
//! ```bash
//! cargo run --example affect_sim_smoke -p remotemedia-core \
//!     --features affect-sim
//! ```
//!
//! Expected first-tick output (target VAD will vary slightly with the
//! simulator's exact dynamics step):
//!
//! ```text
//! [t=  200ms] tick #0 — events: [UserGreeting]
//!   set_steering        target=[+0.10, 0.00, +0.07] alpha=1.00
//!   set_system_aug      "Current interaction state: ..."
//!   debug_tap           V=+0.05 A=0.07 D=+0.02
//!     warmth=0.34 assert=0.31 safety=0.00 expr=0.45
//! ```

#[cfg(not(feature = "affect-sim"))]
fn main() {
    eprintln!(
        "this example requires the `affect-sim` feature; \
         re-run with `--features affect-sim`"
    );
    std::process::exit(2);
}

#[cfg(feature = "affect-sim")]
#[tokio::main(flavor = "current_thread")]
async fn main() {
    use std::sync::Arc;

    use remotemedia_core::data::RuntimeData;
    use remotemedia_core::nodes::{
        AffectSimulatorConfig, AffectSimulatorNode, NodeRuntimeContext, PacingNature,
        SessionAffectState, StreamingNode, Tick,
    };
    use remotemedia_core::transport::session_control::aux_port_of;
    use remotemedia_core::Result;

    // Build the node directly. In a real pipeline the factory + the
    // session router construct everything for us; here we wire it by
    // hand so the example has zero dependencies on transports.
    let cfg = AffectSimulatorConfig::default();
    println!(
        "AffectSimulatorNode(tick_hz={}, alpha={:.2}, emit_threshold={:.3})",
        cfg.tick_hz, cfg.steering_alpha, cfg.emit_threshold,
    );
    println!(
        "pacing_nature = {:?}",
        AffectSimulatorNode::new("affect_sim", cfg.clone()).pacing_nature()
    );
    let node = AffectSimulatorNode::new("affect_sim", cfg);

    // Per-(node, session) state. The session router constructs this via
    // `make_session_state`; we new it up directly and inject into a
    // test context. Multi-session servers would have one of these per
    // active browser session.
    let mut ctx = NodeRuntimeContext::for_test("smoke", "affect_sim");
    ctx.session_state = Arc::new(SessionAffectState::default());

    // Scripted timeline: each entry is `(absolute_ms, RuntimeData)`.
    // A `None` slot marks a pure idle tick — no event delivered.
    let timeline: Vec<(u64, Option<RuntimeData>)> = vec![
        // T+0.0s — first speech_start of the session → UserGreeting.
        (
            0,
            Some(RuntimeData::Json(serde_json::json!({
                "is_speech_start": true,
                "is_speech_end": false,
            }))),
        ),
        // T+0.2s — pure idle tick so the regulator can take a breath.
        (200, None),
        // T+0.4s — speech_end → UserQuestion fires.
        (
            400,
            Some(RuntimeData::Json(serde_json::json!({
                "is_speech_start": false,
                "is_speech_end": true,
            }))),
        ),
        // T+0.6s — first transcript turn (folds into UserQuestion at Tier A).
        (600, Some(RuntimeData::Text("I just lost my job".into()))),
        // Idle settle.
        (800, None),
        (1000, None),
        (1200, None),
        (1400, None),
        // T+1.6s — second transcript turn.
        (1600, Some(RuntimeData::Text("thanks for listening".into()))),
        (1800, None),
        (2000, None),
        (2200, None),
        // Run a few extra idle ticks so we can observe decay-toward-baseline.
        (2400, None),
        (2600, None),
        (2800, None),
        (3000, None),
    ];

    let collected: Arc<std::sync::Mutex<Vec<RuntimeData>>> =
        Arc::new(std::sync::Mutex::new(Vec::new()));

    for (i, (t_ms, maybe_event)) in timeline.iter().enumerate() {
        // Deliver the event (if any) before this tick fires. In the real
        // pipeline these arrive on the input mpsc; we call the trait
        // method directly because there's no router in the loop.
        if let Some(event) = maybe_event {
            // process_streaming_async returns 0 emits — the node always
            // defers actual emission to tick(). The callback we hand it
            // will never be invoked here.
            let cb_noop: Box<dyn FnMut(RuntimeData) -> Result<()> + Send> = Box::new(|_| Ok(()));
            node.process_streaming_async(event.clone(), &ctx, cb_noop)
                .await
                .expect("process_streaming_async");
        }

        // Empty the buffer for the next tick's emissions.
        collected.lock().unwrap().clear();
        let collected_clone = collected.clone();
        let cb: Box<dyn FnMut(RuntimeData) -> Result<()> + Send> = Box::new(move |out| {
            collected_clone.lock().unwrap().push(out);
            Ok(())
        });

        let tick = Tick {
            clock_id: format!("wall:{}", AffectSimulatorConfig::default().tick_hz),
            pts_us: t_ms * 1000,
            frame_idx: i as u64,
            deadline_us: (t_ms + 200) * 1000,
        };
        node.tick(tick, &ctx, cb).await.expect("tick");

        // Render this tick's emissions.
        let emissions = collected.lock().unwrap();
        let label = match maybe_event {
            Some(RuntimeData::Json(v)) => {
                if v.get("is_speech_start").and_then(|b| b.as_bool()) == Some(true) {
                    "VAD speech_start".to_string()
                } else if v.get("is_speech_end").and_then(|b| b.as_bool()) == Some(true) {
                    "VAD speech_end".to_string()
                } else {
                    "JSON event".to_string()
                }
            }
            Some(RuntimeData::Text(t)) => format!("Text  {:?}", t),
            Some(_) => "OTHER".to_string(),
            None => "(idle)".to_string(),
        };
        println!("[t={:>5}ms] tick #{:>2}  in: {}", t_ms, i, label);

        for out in emissions.iter() {
            match aux_port_of(out).as_deref() {
                Some("set_steering") => {
                    if let RuntimeData::Json(v) = out {
                        let payload = v.get("payload").unwrap_or(&serde_json::Value::Null);
                        let target = payload
                            .get("target_vad")
                            .and_then(|x| x.as_array())
                            .map(|arr| {
                                let f =
                                    |i: usize| arr.get(i).and_then(|x| x.as_f64()).unwrap_or(0.0);
                                [f(0), f(1), f(2)]
                            })
                            .unwrap_or([0.0; 3]);
                        let alpha = payload.get("alpha").and_then(|x| x.as_f64()).unwrap_or(0.0);
                        println!(
                            "             set_steering        V={:+.3} A={:+.3} D={:+.3}  α={:.2}",
                            target[0], target[1], target[2], alpha,
                        );
                    }
                }
                Some("set_system_augmentation") => {
                    if let RuntimeData::Json(v) = out {
                        let text = v
                            .get("payload")
                            .and_then(|p| p.get("text"))
                            .and_then(|x| x.as_str())
                            .unwrap_or("");
                        // First line of the summary is "Current
                        // interaction state:"; show one diagnostic
                        // line beyond that so the trajectory is
                        // visible without flooding the console.
                        let preview: String =
                            text.lines().skip(1).take(2).collect::<Vec<_>>().join(" | ");
                        println!(
                            "             set_system_aug      {}",
                            preview.trim_start_matches("- "),
                        );
                    }
                }
                None => {
                    // Debug tap (kind: affect_state) — render a compact
                    // V/A/D + key policy knobs line.
                    if let RuntimeData::Json(v) = out {
                        let kind = v.get("kind").and_then(|x| x.as_str()).unwrap_or("");
                        if kind == "affect_state" {
                            let target = v
                                .get("channel_d_target_vad")
                                .and_then(|x| x.as_array())
                                .map(|arr| {
                                    let f = |i: usize| {
                                        arr.get(i).and_then(|x| x.as_f64()).unwrap_or(0.0)
                                    };
                                    [f(0), f(1), f(2)]
                                })
                                .unwrap_or([0.0; 3]);
                            let policy = v.get("policy");
                            let warmth = field(policy, "warmth");
                            let assert_ = field(policy, "assertiveness");
                            let safety = field(policy, "safety_dampening");
                            let expr = field(policy, "expressiveness");
                            println!(
                                "             debug_tap           V={:+.3} A={:+.3} D={:+.3}  warmth={:.2} assert={:.2} safety={:.2} expr={:.2}",
                                target[0], target[1], target[2],
                                warmth, assert_, safety, expr,
                            );
                        } else if kind == "blendshapes" {
                            // Render top 3 active ARKit blendshapes for
                            // a one-line "what does the face look like
                            // right now" diagnostic. Below 0.05 we drop
                            // (renderer wouldn't show them anyway).
                            use remotemedia_core::nodes::lip_sync::ARKIT_BLENDSHAPE_NAMES;
                            let arr = v
                                .get("arkit_52")
                                .and_then(|x| x.as_array())
                                .cloned()
                                .unwrap_or_default();
                            let mut active: Vec<(usize, f64)> = arr
                                .iter()
                                .enumerate()
                                .filter_map(|(i, x)| x.as_f64().map(|w| (i, w)))
                                .filter(|(_, w)| *w >= 0.05)
                                .collect();
                            active.sort_by(|a, b| {
                                b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal)
                            });
                            let top: Vec<String> = active
                                .iter()
                                .take(3)
                                .map(|(i, w)| format!("{} {:.2}", ARKIT_BLENDSHAPE_NAMES[*i], w))
                                .collect();
                            let face = if top.is_empty() {
                                "(neutral)".to_string()
                            } else {
                                top.join(", ")
                            };
                            println!("             blendshapes         {}", face,);
                        }
                    }
                }
                Some(other) => {
                    println!("             aux({})", other);
                }
            }
        }
    }

    println!("\nsmoke test complete — {} ticks fired", timeline.len());
}

#[cfg(feature = "affect-sim")]
fn field(o: Option<&serde_json::Value>, key: &str) -> f64 {
    o.and_then(|v| v.get(key))
        .and_then(|x| x.as_f64())
        .unwrap_or(0.0)
}
