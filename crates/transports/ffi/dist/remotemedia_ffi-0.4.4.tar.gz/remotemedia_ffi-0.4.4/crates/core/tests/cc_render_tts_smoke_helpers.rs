//! Helpers extracted from `cc_render_tts_smoke.rs` so tests can call
//! them without dragging in GPU/ONNX deps. Lives under `tests/` so
//! Cargo's example auto-discovery doesn't try to compile it as a
//! stand-alone example with `fn main`. Both the example binary and
//! the unit tests reach into this file via `#[path]`. Cargo also
//! treats this file as a test target with no `#[test]` functions
//! (= noop test that builds and runs zero tests), which is fine.

use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use serde_json::json;
use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct ManifestArgs {
    pub glb: PathBuf,
    pub map: PathBuf,
    pub audio2face_bundle: PathBuf,
    /// Reserved for callers that still pass a path; the WAV is now
    /// written by the smoke binary's drain loop directly, so this
    /// field no longer reaches the manifest.
    #[allow(dead_code)]
    pub wav_path: PathBuf,
    pub width: u32,
    pub height: u32,
    pub fps: u32,
    pub tts_voice: String,
    pub tts_lang: String,
    pub tts_speed: f32,
    pub motion: Option<PathBuf>,
    pub motion_prompt: Option<String>,
    pub motion_duration: f32,
    /// When `Some(path)`, add an `AudioFileWriterNode` that taps the
    /// 16 kHz audio stream feeding Audio2Face — useful for confirming
    /// the resampler is producing real samples (vs. silence) when the
    /// avatar isn't lip-syncing as expected.
    pub debug_audio_16k_path: Option<PathBuf>,
    /// When `Some(path)`, add a `VideoFileWriterNode` that taps the
    /// raw `RuntimeData::Video` stream coming out of `CcRenderNode` —
    /// writes a Y4M file that ffmpeg / mpv can play directly. Useful
    /// for distinguishing "renderer produces blank frames" from
    /// "stage-2 ffmpeg encoding glitch".
    pub debug_video_y4m_path: Option<PathBuf>,
    /// When true, add `EnvelopeDebugLogNode` taps that print the Json
    /// envelopes flowing TO `CcRenderNode` — blendshapes (post-
    /// Audio2Face) and, when `motion` / `motion_prompt` is set, the
    /// skeletal_pose stream from MotionPlayerNode / KimodoMotionNode.
    /// Logs at `tracing::info!` on target `envelope_debug`.
    pub debug_envelope_log: bool,
}

const KOKORO_DEPS: &[&str] = &[
    "kokoro>=0.9.4",
    "soundfile",
    "en-core-web-sm @ https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl",
];

pub fn build_manifest(a: &ManifestArgs) -> Manifest {
    let mut nodes: Vec<NodeManifest> = vec![
        NodeManifest {
            id: "kokoro_tts".into(),
            node_type: "KokoroTTSNode".into(),
            params: json!({
                "lang_code":     a.tts_lang,
                "voice":         a.tts_voice,
                "speed":         a.tts_speed,
                "sample_rate":   24_000,
                "stream_chunks": true,
                "skip_tokens":   ["<|text_end|>", "```"],
            }),
            python_deps: Some(KOKORO_DEPS.iter().map(|s| s.to_string()).collect()),
            ..Default::default()
        },
        NodeManifest {
            id: "audio_resample".into(),
            node_type: "FastResampleNode".into(),
            params: json!({
                "source_rate": 24_000,
                "target_rate": 16_000,
                "channels":    1,
                "quality":     "Medium",
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "audio2face_lipsync".into(),
            node_type: "Audio2FaceLipSyncNode".into(),
            params: json!({
                "bundle_path":     a.audio2face_bundle.to_string_lossy(),
                "identity":        "Claire",
                "solver":          "pgd",
                "use_gpu":         false,
                "smoothing_alpha": 0.0,
            }),
            ..Default::default()
        },
        NodeManifest {
            id: "cc_render".into(),
            node_type: "CcRenderNode".into(),
            params: json!({
                "glb_path":        a.glb.to_string_lossy(),
                "arkit_map_path":  a.map.to_string_lossy(),
                "width":           a.width,
                "height":          a.height,
                "fps":             a.fps,
                "video_stream_id": "avatar.video",
            }),
            ..Default::default()
        },
        // NB: the WAV is now written by the smoke binary's drain loop
        // itself (see `cc_render_tts_smoke.rs::run`), gated on the same
        // wallclock origin as the first written video frame so
        // mouth animation + audio share a sample-0 alignment.
        // `AudioFileWriterNode` would tap kokoro directly, which captures
        // audio ~1 s before audio2face has produced any blendshapes —
        // pairing the wav's sample 0 with an idle-pose video frame.
    ];

    // Insert a RenderReadyGateNode between every pose-emitting upstream
    // (audio2face, motion_player, kimodo_motion) and cc_render. The gate
    // buffers blendshape/skeletal_pose envelopes until the smoke binary
    // sends a {kind:"render_ready"} signal (which it does once the
    // renderer's first Video frame appears on output_rx). Without this,
    // Kokoro's burst-style synthesis flushes all envelopes through
    // cc_render's latest-wins watch channel before the renderer warms up.
    nodes.push(NodeManifest {
        id: "render_ready_gate".into(),
        node_type: "RenderReadyGateNode".into(),
        params: json!({
            "gatedKinds":     ["blendshapes", "skeletal_pose"],
            "openKind":       "render_ready",
            "paceRealtime":   true,
            "bufferCapacity": 8192,
        }),
        ..Default::default()
    });

    // One-shot notifier on audio2face's first blendshape — fires the
    // moment audio2face_lipsync has accumulated 1 s of audio and
    // produced its first paced output. The smoke binary uses this as
    // the wallclock origin for the recorded MP4 (audio + video both
    // start FROM here, so kokoro sample 0 pairs with mouth pts_ms=0
    // in the muxed file instead of with an idle-pose pre-roll frame).
    nodes.push(NodeManifest {
        id: "audio2face_first_blendshape_notifier".into(),
        node_type: "EnvelopeFirstNotifierNode".into(),
        params: json!({
            "targetKind":   "blendshapes",
            "sourceLabel":  "audio2face",
        }),
        ..Default::default()
    });

    let mut connections = vec![
        Connection {
            from: "kokoro_tts".into(),
            to: "audio_resample".into(),
            from_port: None,
            to_port: None,
        },
        Connection {
            from: "audio_resample".into(),
            to: "audio2face_lipsync".into(),
            from_port: None,
            to_port: None,
        },
        // Pose stream: audio2face → gate → cc_render. The gate is also
        // the sink for the explicit `render_ready` open signal that the
        // smoke binary fans out via `to_node: None` once the renderer
        // is up.
        Connection {
            from: "audio2face_lipsync".into(),
            to: "render_ready_gate".into(),
            from_port: None,
            to_port: None,
        },
        Connection {
            from: "render_ready_gate".into(),
            to: "cc_render".into(),
            from_port: None,
            to_port: None,
        },
        // First-blendshape signal — parallel sink off audio2face so the
        // smoke binary can detect "lipsync has begun" and send the
        // render_ready open signal to the gate. The notifier emits
        // a single `{kind:"first_emit",source:"audio2face"}` envelope.
        Connection {
            from: "audio2face_lipsync".into(),
            to: "audio2face_first_blendshape_notifier".into(),
            from_port: None,
            to_port: None,
        },
    ];

    // NB: kokoro_tts no longer needs an extra passthrough sink — the
    // audio path is `kokoro → audio_resample → audio2face → gate →
    // cc_render`, where audio2face passes audio through and cc_render
    // is the terminal sink that emits paired Video+Audio chunks at
    // content time.

    if let Some(jsonl) = a.motion.as_ref() {
        nodes.push(NodeManifest {
            id: "motion_player".into(),
            node_type: "MotionPlayerNode".into(),
            params: json!({
                "jsonlPath":     jsonl.to_string_lossy(),
                "fps":           a.fps,
                "loopForever":   false,
                "paceRealtime":  true,
            }),
            ..Default::default()
        });
        connections.push(Connection {
            from: "motion_player".into(),
            to: "render_ready_gate".into(),
            from_port: None,
            to_port: None,
        });
    } else if let Some(_prompt) = a.motion_prompt.as_ref() {
        nodes.push(NodeManifest {
            id: "kimodo_motion".into(),
            node_type: "KimodoMotionNode".into(),
            params: json!({
                "default_duration_sec": a.motion_duration,
                // 50 steps is Kimodo's default but takes ~41 s of CPU
                // diffusion plus ~30 s of cold-cache model load. The
                // smoke test only needs the motion to render, not a
                // perfect clip — drop to 25 steps for ~20 s diffusion.
                "diffusion_steps": 25,
            }),
            ..Default::default()
        });
        connections.push(Connection {
            from: "kimodo_motion".into(),
            to: "render_ready_gate".into(),
            from_port: None,
            to_port: None,
        });

        // One-shot notifier — emits a `{kind:"first_emit",...}` envelope
        // on output_rx the moment kimodo finishes diffusion. The smoke
        // binary listens for this signal before sending the Text packet
        // so audio (Kokoro) and motion (Kimodo) start in lockstep.
        nodes.push(NodeManifest {
            id: "kimodo_first_pose_notifier".into(),
            node_type: "EnvelopeFirstNotifierNode".into(),
            params: json!({
                "targetKind":   "skeletal_pose",
                "sourceLabel":  "kimodo_motion",
            }),
            ..Default::default()
        });
        connections.push(Connection {
            from: "kimodo_motion".into(),
            to: "kimodo_first_pose_notifier".into(),
            from_port: None,
            to_port: None,
        });
    }

    // Debug-tap: 16 kHz post-resample audio. Parallel sink alongside
    // audio2face_lipsync so audio2face still gets its input.
    if let Some(p) = a.debug_audio_16k_path.as_ref() {
        nodes.push(NodeManifest {
            id: "audio_16k_tap".into(),
            node_type: "AudioFileWriterNode".into(),
            params: json!({"output_path": p.to_string_lossy()}),
            ..Default::default()
        });
        connections.push(Connection {
            from: "audio_resample".into(),
            to: "audio_16k_tap".into(),
            from_port: None,
            to_port: None,
        });
    }

    // Debug-tap: raw Y4M of the renderer's video stream. Wired AFTER
    // cc_render so the y4m file shows exactly what the renderer is
    // emitting before stage-2 ffmpeg touches it. y4m_writer becomes a
    // sink (no downstream); cc_render's video also still flows to
    // output_rx via the SessionRouter's sink fan-out — until y4m is
    // wired, then cc_render is no longer terminal. The drain loop's
    // ffmpeg stage-1 doesn't care: video frames pass through y4m_writer
    // unchanged (it's a passthrough sink) and reach output_rx as the
    // sink's emission.
    if let Some(p) = a.debug_video_y4m_path.as_ref() {
        nodes.push(NodeManifest {
            id: "video_y4m_tap".into(),
            node_type: "VideoFileWriterNode".into(),
            params: json!({
                "output_path": p.to_string_lossy(),
                "fps": a.fps,
            }),
            ..Default::default()
        });
        connections.push(Connection {
            from: "cc_render".into(),
            to: "video_y4m_tap".into(),
            from_port: None,
            to_port: None,
        });
    }

    // Debug-tap: blendshape envelope logger. Parallel sink alongside
    // cc_render so audio2face_lipsync's output fans to BOTH (the
    // renderer + the logger). Throttled to once per second at 30 Hz.
    if a.debug_envelope_log {
        nodes.push(NodeManifest {
            id: "blendshape_log".into(),
            node_type: "EnvelopeDebugLogNode".into(),
            params: json!({
                "label":  "blendshapes->cc_render",
                "kind":   "blendshapes",
                "every":  10,
                "topK":   5,
            }),
            ..Default::default()
        });
        connections.push(Connection {
            from: "audio2face_lipsync".into(),
            to: "blendshape_log".into(),
            from_port: None,
            to_port: None,
        });

        // When motion is wired in (either source), tap that stream too.
        if a.motion.is_some() {
            nodes.push(NodeManifest {
                id: "motion_log".into(),
                node_type: "EnvelopeDebugLogNode".into(),
                params: json!({
                    "label":  "motion_player->cc_render",
                    "kind":   "skeletal_pose",
                    "every":  10,
                    "topK":   1,
                }),
                ..Default::default()
            });
            connections.push(Connection {
                from: "motion_player".into(),
                to: "motion_log".into(),
                from_port: None,
                to_port: None,
            });
        } else if a.motion_prompt.is_some() {
            nodes.push(NodeManifest {
                id: "motion_log".into(),
                node_type: "EnvelopeDebugLogNode".into(),
                params: json!({
                    "label":  "kimodo_motion->cc_render",
                    "kind":   "skeletal_pose",
                    "every":  10,
                    "topK":   1,
                }),
                ..Default::default()
            });
            connections.push(Connection {
                from: "kimodo_motion".into(),
                to: "motion_log".into(),
                from_port: None,
                to_port: None,
            });
        }
    }

    Manifest {
        version: "v1".into(),
        metadata: ManifestMetadata {
            name: "cc-render-tts-smoke".into(),
            ..Default::default()
        },
        nodes,
        connections,
        python_env: None,
        plugins: Vec::new(),
    }
}
