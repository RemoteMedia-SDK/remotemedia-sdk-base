//! Integration: Source-wall pacer drives a node's `tick()` method at a
//! configured rate.
//!
//! Builds a one-node session with a `WallTicker` test fixture that
//! declares `pacing_nature = SourceWall(20)` and emits a counter on
//! every tick. Runs the session router for ~500ms, asserts the output
//! count matches 20Hz ±20%.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use async_trait::async_trait;
use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::{
    NodeRuntimeContext, NodeRuntimeContextRead, PacingNature, StreamingNode, StreamingNodeFactory,
    StreamingNodeRegistry, Tick,
};
use remotemedia_core::transport::session_router::{SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY};
use remotemedia_core::Error;
use serde_json::Value;

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

/// Test fixture: declares itself as `SourceWall(20)` and emits a
/// counter on each tick. Used to validate the runtime's wall-pacer
/// path.
struct WallTickerNode {
    node_id: String,
    rate_hz: u32,
    counter: AtomicU64,
}

#[async_trait]
impl StreamingNode for WallTickerNode {
    fn node_type(&self) -> &str {
        "WallTickerNode"
    }
    fn node_id(&self) -> &str {
        &self.node_id
    }

    fn pacing_nature(&self) -> PacingNature {
        PacingNature::SourceWall(self.rate_hz)
    }

    fn is_multi_input(&self) -> bool {
        false
    }

    async fn process_async(
        &self,
        _data: RuntimeData,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        // Reactive path is unused; the wall pacer drives `tick`.
        Err(Error::Execution(
            "WallTickerNode has no reactive input".into(),
        ))
    }

    async fn process_multi_async(
        &self,
        _inputs: std::collections::HashMap<String, RuntimeData>,
        _ctx: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution(
            "WallTickerNode has no reactive input".into(),
        ))
    }

    async fn tick(
        &self,
        tick: Tick,
        _ctx: &dyn NodeRuntimeContextRead,
        mut cb: Box<dyn FnMut(RuntimeData) -> Result<(), Error> + Send>,
    ) -> Result<(), Error> {
        let n = self.counter.fetch_add(1, Ordering::Relaxed);
        cb(RuntimeData::Json(serde_json::json!({
            "frame_idx": tick.frame_idx,
            "pts_us": tick.pts_us,
            "count": n,
        })))?;
        Ok(())
    }
}

struct WallTickerFactory {
    rate_hz: u32,
}

impl StreamingNodeFactory for WallTickerFactory {
    fn create(
        &self,
        node_id: String,
        _params: &Value,
        _session_id: Option<String>,
    ) -> Result<Box<dyn StreamingNode>, Error> {
        Ok(Box::new(WallTickerNode {
            node_id,
            rate_hz: self.rate_hz,
            counter: AtomicU64::new(0),
        }))
    }
    fn node_type(&self) -> &str {
        "WallTickerNode"
    }
}

fn one_node_manifest() -> Manifest {
    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "wall-pacer-e2e".to_string(),
            ..Default::default()
        },
        nodes: vec![NodeManifest {
            id: "ticker".to_string(),
            node_type: "WallTickerNode".to_string(),
            params: serde_json::json!({}),
            ..Default::default()
        }],
        connections: Vec::<Connection>::new(),
        python_env: None,
        plugins: Vec::new(),
    }
}

#[tokio::test]
async fn source_wall_pacer_fires_tick_at_configured_rate() {
    let session_id = "wall-pacer-e2e".to_string();
    let manifest = Arc::new(one_node_manifest());

    // Custom registry with only the WallTicker fixture; spec'd at 20 Hz.
    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(WallTickerFactory { rate_hz: 20 }));
    let registry = Arc::new(registry);

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (mut _router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    // Don't send any input — the wall pacer drives `tick` independent of
    // upstream input.
    let _input_tx = _router.get_input_sender();
    let handle = _router.start();

    // Collect outputs for 600ms. With 20Hz we expect ~12 outputs; allow
    // ±20% slack for tokio scheduling jitter.
    let mut count = 0_u32;
    let deadline = std::time::Instant::now() + Duration::from_millis(600);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(_out)) => count += 1,
            Ok(None) => break,
            Err(_) => break,
        }
    }

    // 20Hz × 0.6s = 12 ticks. Allow ±50% (6..18) for CI jitter.
    assert!(
        count >= 6 && count <= 18,
        "wall pacer fired {} times in 600ms; expected ~12 (20Hz)",
        count
    );

    drop(_input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
