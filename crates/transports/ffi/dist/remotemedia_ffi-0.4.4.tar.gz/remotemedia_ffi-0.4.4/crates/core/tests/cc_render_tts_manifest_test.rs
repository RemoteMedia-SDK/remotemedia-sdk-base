//! Manifest-builder unit tests for cc_render_tts_smoke.
//!
//! The binary itself is feature-gated behind `avatar-render-cc`+
//! `avatar-audio2face`, but the manifest builder is pure logic
//! (depends only on `manifest::*` structs). Lifted into a helper
//! module so tests can call it without GPU/ONNX deps.

#![cfg(all(feature = "avatar-render-cc", feature = "avatar-audio2face"))]

#[path = "cc_render_tts_smoke_helpers.rs"]
mod helpers;

use helpers::{build_manifest, ManifestArgs};
use std::path::PathBuf;

fn base_args() -> ManifestArgs {
    ManifestArgs {
        glb: PathBuf::from("/tmp/x.glb"),
        map: PathBuf::from("/tmp/x.json"),
        audio2face_bundle: PathBuf::from("/tmp/audio2face"),
        wav_path: PathBuf::from("/tmp/x.tts.wav"),
        width: 1280,
        height: 1280,
        fps: 30,
        tts_voice: "af_heart".into(),
        tts_lang: "a".into(),
        tts_speed: 1.0,
        motion: None,
        motion_prompt: None,
        motion_duration: 4.0,
        debug_audio_16k_path: None,
        debug_video_y4m_path: None,
        debug_envelope_log: false,
    }
}

// Base manifest contains 6 nodes:
//   kokoro_tts, audio_resample, audio2face_lipsync, cc_render,
//   render_ready_gate, audio2face_first_blendshape_notifier.
//
// cc_render is the terminal sink for both Video and Audio (audio is
// passed through Audio2FaceLipSyncNode → render_ready_gate → cc_render
// and emitted paired with Video frames at content time).
const BASE_NODE_COUNT: usize = 6;

#[test]
fn debug_taps_add_audio_16k_and_video_y4m_writers() {
    let mut a = base_args();
    a.debug_audio_16k_path = Some(PathBuf::from("/tmp/x.16k.wav"));
    a.debug_video_y4m_path = Some(PathBuf::from("/tmp/x.raw.y4m"));
    let m = build_manifest(&a);
    let ids: Vec<&str> = m.nodes.iter().map(|n| n.id.as_str()).collect();
    assert!(ids.contains(&"audio_16k_tap"));
    assert!(ids.contains(&"video_y4m_tap"));
    assert_eq!(m.nodes.len(), BASE_NODE_COUNT + 2); // base + 2 debug
    assert!(
        m.connections
            .iter()
            .any(|c| c.from == "audio_resample" && c.to == "audio_16k_tap"),
        "audio_resample → audio_16k_tap connection missing"
    );
    assert!(
        m.connections
            .iter()
            .any(|c| c.from == "cc_render" && c.to == "video_y4m_tap"),
        "cc_render → video_y4m_tap connection missing"
    );
    let writer = m.nodes.iter().find(|n| n.id == "audio_16k_tap").unwrap();
    assert_eq!(
        writer.params.get("output_path").and_then(|v| v.as_str()),
        Some("/tmp/x.16k.wav")
    );
    let v_writer = m.nodes.iter().find(|n| n.id == "video_y4m_tap").unwrap();
    assert_eq!(
        v_writer.params.get("output_path").and_then(|v| v.as_str()),
        Some("/tmp/x.raw.y4m")
    );
    assert_eq!(
        v_writer.params.get("fps").and_then(|v| v.as_u64()),
        Some(30)
    );
}

#[test]
fn debug_envelope_log_adds_blendshape_tap() {
    let mut a = base_args();
    a.debug_envelope_log = true;
    let m = build_manifest(&a);
    let log = m
        .nodes
        .iter()
        .find(|n| n.id == "blendshape_log")
        .expect("blendshape_log tap missing");
    assert_eq!(log.node_type, "EnvelopeDebugLogNode");
    assert_eq!(
        log.params.get("kind").and_then(|v| v.as_str()),
        Some("blendshapes")
    );
    assert!(
        m.connections
            .iter()
            .any(|c| c.from == "audio2face_lipsync" && c.to == "blendshape_log"),
        "audio2face_lipsync → blendshape_log connection missing"
    );
    // No motion configured → no skeletal_pose log node.
    assert!(m.nodes.iter().all(|n| n.id != "motion_log"));
}

#[test]
fn debug_envelope_log_adds_motion_tap_when_motion_jsonl() {
    let mut a = base_args();
    a.debug_envelope_log = true;
    a.motion = Some(PathBuf::from("/tmp/wave.jsonl"));
    let m = build_manifest(&a);
    let log = m
        .nodes
        .iter()
        .find(|n| n.id == "motion_log")
        .expect("motion_log tap missing for --motion + --debug-taps");
    assert_eq!(log.node_type, "EnvelopeDebugLogNode");
    assert_eq!(
        log.params.get("kind").and_then(|v| v.as_str()),
        Some("skeletal_pose")
    );
    assert!(
        m.connections
            .iter()
            .any(|c| c.from == "motion_player" && c.to == "motion_log"),
        "motion_player → motion_log connection missing"
    );
}

#[test]
fn base_manifest_has_expected_nodes_and_connections() {
    let m = build_manifest(&base_args());
    let ids: Vec<&str> = m.nodes.iter().map(|n| n.id.as_str()).collect();
    for expected in [
        "kokoro_tts",
        "audio_resample",
        "audio2face_lipsync",
        "cc_render",
        "render_ready_gate",
        "audio2face_first_blendshape_notifier",
    ] {
        assert!(ids.contains(&expected), "missing node {expected}");
    }
    assert!(!ids.contains(&"audio_file_writer"));
    assert!(!ids.contains(&"audio_passthrough"));
    assert_eq!(m.nodes.len(), BASE_NODE_COUNT);
    // Connections: tts→resample, resample→a2f, a2f→gate, gate→cc,
    // a2f→a2f_notifier.
    assert_eq!(m.connections.len(), 5);
    assert!(
        m.connections
            .iter()
            .any(|c| c.from == "audio2face_lipsync"
                && c.to == "audio2face_first_blendshape_notifier"),
        "audio2face → first_blendshape_notifier connection missing"
    );
}

#[test]
fn motion_jsonl_adds_motion_player() {
    let mut a = base_args();
    a.motion = Some(PathBuf::from("/tmp/wave.jsonl"));
    let m = build_manifest(&a);
    assert!(m.nodes.iter().any(|n| n.node_type == "MotionPlayerNode"));
    assert!(m
        .connections
        .iter()
        .any(|c| c.from == "motion_player" && c.to == "render_ready_gate"));
    assert_eq!(m.nodes.len(), BASE_NODE_COUNT + 1);
}

#[test]
fn motion_prompt_adds_kimodo_motion() {
    let mut a = base_args();
    a.motion_prompt = Some("a person waves".into());
    let m = build_manifest(&a);
    assert!(m.nodes.iter().any(|n| n.node_type == "KimodoMotionNode"));
    assert!(m
        .connections
        .iter()
        .any(|c| c.from == "kimodo_motion" && c.to == "render_ready_gate"));
    // +2 nodes: kimodo_motion + kimodo_first_pose_notifier.
    assert_eq!(m.nodes.len(), BASE_NODE_COUNT + 2);
}

#[test]
fn kokoro_carries_python_deps() {
    let m = build_manifest(&base_args());
    let kokoro = m.nodes.iter().find(|n| n.id == "kokoro_tts").unwrap();
    let deps = kokoro.python_deps.as_ref().expect("kokoro python_deps");
    assert!(deps.iter().any(|d| d.starts_with("kokoro")));
    assert!(deps.iter().any(|d| d.starts_with("soundfile")));
}

#[test]
fn audio2face_first_blendshape_notifier_targets_blendshapes() {
    let m = build_manifest(&base_args());
    let n = m
        .nodes
        .iter()
        .find(|n| n.id == "audio2face_first_blendshape_notifier")
        .expect("notifier missing");
    assert_eq!(n.node_type, "EnvelopeFirstNotifierNode");
    assert_eq!(
        n.params.get("targetKind").and_then(|v| v.as_str()),
        Some("blendshapes")
    );
    assert_eq!(
        n.params.get("sourceLabel").and_then(|v| v.as_str()),
        Some("audio2face")
    );
}
