//! Integration: `AvatarNode` consumes `IdleAnimationNode`'s `idle_pose`
//! snapshot via the manifest, and emits an idle-mode `RuntimeData::Video`
//! every tick.
//!
//! Smoke test for Phase 6.2 of the pacing-domains spec: the same
//! default-registry path that the production pipeline uses must wire
//! the snapshot connection correctly and surface a sentinel pixel byte
//! that proves the avatar took the idle render path.

use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::streaming_registry::create_default_streaming_registry;
use remotemedia_core::transport::session_router::{SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY};

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

fn idle_only_pipeline() -> Manifest {
    Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "avatar-idle-only".to_string(),
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "idle".to_string(),
                node_type: "IdleAnimationNode".to_string(),
                params: serde_json::json!({
                    "rate_hz": 30,
                    "blink_period_frames": 4,
                    "blink_duration_frames": 1,
                }),
                ..Default::default()
            },
            NodeManifest {
                id: "avatar".to_string(),
                node_type: "AvatarNode".to_string(),
                params: serde_json::json!({
                    "rate_hz": 20,
                    "width": 256,
                    "height": 256,
                }),
                ..Default::default()
            },
        ],
        // Snapshot wire: idle.idle_pose -> avatar.idle_pose. The router
        // resolves both port names to PortKind::Snapshot via the
        // factories' input_port_kinds() / output_port_kinds() and
        // installs the read handle into the avatar's
        // NodeRuntimeContext::input_snapshots.
        connections: vec![Connection {
            from: "idle".to_string(),
            to: "avatar".to_string(),
            from_port: Some("idle_pose".to_string()),
            to_port: Some("idle_pose".to_string()),
        }],
        python_env: None,
        plugins: Vec::new(),
    }
}

/// AvatarNode wired to IdleAnimationNode's idle_pose snapshot output:
/// every tick emits a Video frame with the idle-mode sentinel byte
/// `0xBB` once the upstream has published its first pose. We allow a
/// small number of `0x00` cold-start frames before the first publish
/// lands (the wall pacer for both nodes is independent and the avatar
/// can tick before idle has emitted its first frame at session start).
#[tokio::test]
async fn avatar_renders_idle_when_idle_pose_is_wired() {
    let session_id = "avatar-idle-e2e".to_string();
    let manifest = Arc::new(idle_only_pipeline());
    let registry = Arc::new(create_default_streaming_registry());

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (router, _shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();
    let _input_tx = router.get_input_sender();
    let handle = router.start();

    // Collect ~600 ms of avatar output. Avatar ticks at 20 Hz so we
    // expect ~12 video frames; allow ±50% slack for CI jitter.
    let mut video_frames: Vec<(u64, Vec<u8>)> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(600);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Video {
                    pixel_data,
                    timestamp_us,
                    width,
                    height,
                    ..
                } = out
                {
                    // The avatar config above sets width/height to 256;
                    // the idle node never emits Video so any Video
                    // frame here is from the avatar.
                    assert_eq!(width, 256);
                    assert_eq!(height, 256);
                    video_frames.push((timestamp_us, pixel_data));
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    let n = video_frames.len();
    assert!(
        n >= 6 && n <= 18,
        "avatar produced {} frames in 600ms; expected ~12 (20 Hz)",
        n
    );

    // The bulk of frames must be idle-mode (sentinel 0xBB). Allow a
    // small number of cold-start frames (sentinel 0x00) at the very
    // beginning before the idle producer's first publish lands —
    // both nodes spawn their wall pacers independently at session
    // start, so the avatar's first tick can race ahead of idle's.
    let cold = video_frames.iter().filter(|(_, p)| p == &[0x00]).count();
    let idle = video_frames.iter().filter(|(_, p)| p == &[0xBB]).count();
    let speaking = video_frames.iter().filter(|(_, p)| p == &[0xAA]).count();

    assert_eq!(
        speaking, 0,
        "no weights publisher in this manifest; saw {} speaking frames: {:?}",
        speaking, video_frames
    );
    assert!(
        idle >= n - 3,
        "expected most frames idle (0xBB); got cold={} idle={} of {}",
        cold,
        idle,
        n
    );
    // No more than the first 3 frames should be cold-start. After
    // the first idle publish the avatar must always observe a fresh
    // pose (idle ticks at 30 Hz vs avatar at 20 Hz, so on every avatar
    // tick the most recent idle publish is at most ~33 ms old).
    assert!(
        cold <= 3,
        "too many cold-start frames: cold={} of {}",
        cold,
        n
    );

    drop(_input_tx);
    let _ = tokio::time::timeout(Duration::from_secs(2), handle).await;
}
