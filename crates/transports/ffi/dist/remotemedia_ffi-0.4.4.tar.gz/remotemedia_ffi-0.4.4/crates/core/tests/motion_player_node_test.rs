//! Unit tests for `MotionPlayerNode`.
//!
//! Pure logic: feed a temp JSONL file → assert envelopes are emitted
//! with bit-exact joint quats and pts_ms.

use remotemedia_core::data::RuntimeData;
use remotemedia_core::nodes::motion::{MotionPlayerConfig, MotionPlayerNode};
use remotemedia_core::nodes::AsyncStreamingNode;
use std::io::Write;
use std::sync::{Arc, Mutex};

/// Helper: write a JSONL file with `n` poses (identity quats, pts_ms = i*33).
fn write_test_jsonl(path: &std::path::Path, n: usize) {
    let mut f = std::fs::File::create(path).expect("create jsonl");
    for i in 0..n {
        let line = serde_json::json!({
            "kind": "skeletal_pose",
            "joint_quats_xyzw": vec![[0.0, 0.0, 0.0, 1.0]; 22],
            "root_pos": [0.0, 0.0, 0.0],
            "pts_ms": i as u64 * 33,
        });
        writeln!(f, "{}", line).unwrap();
    }
}

async fn drive(node: &MotionPlayerNode, data: RuntimeData) -> Vec<RuntimeData> {
    let collected: Arc<Mutex<Vec<RuntimeData>>> = Arc::new(Mutex::new(Vec::new()));
    let cc = collected.clone();
    node.process_streaming(data, None, move |out| {
        cc.lock().unwrap().push(out);
        Ok(())
    })
    .await
    .expect("process_streaming");
    let v = collected.lock().unwrap().clone();
    v
}

#[tokio::test]
async fn emits_one_envelope_per_pose() {
    let dir = tempfile::tempdir().unwrap();
    let jsonl = dir.path().join("motion.jsonl");
    write_test_jsonl(&jsonl, 3);

    let node = MotionPlayerNode::new(MotionPlayerConfig {
        jsonl_path: jsonl,
        fps: 30,
        loop_forever: false,
        pace_realtime: false, // test runs fast — no inter-envelope sleep
    });

    let outs = drive(&node, RuntimeData::Text("kick".into())).await;
    assert_eq!(outs.len(), 3, "should emit 3 envelopes for 3-line JSONL");

    for (i, out) in outs.iter().enumerate() {
        let RuntimeData::Json(v) = out else {
            panic!("expected Json, got {:?}", out);
        };
        assert_eq!(
            v.get("kind").and_then(|k| k.as_str()),
            Some("skeletal_pose")
        );
        assert_eq!(
            v.get("pts_ms").and_then(|p| p.as_u64()),
            Some(i as u64 * 33)
        );
        let arr = v
            .get("joint_quats_xyzw")
            .and_then(|j| j.as_array())
            .unwrap();
        assert_eq!(arr.len(), 22);
    }
}

#[tokio::test]
async fn empty_jsonl_emits_nothing() {
    let dir = tempfile::tempdir().unwrap();
    let jsonl = dir.path().join("empty.jsonl");
    std::fs::File::create(&jsonl).unwrap();

    let node = MotionPlayerNode::new(MotionPlayerConfig {
        jsonl_path: jsonl,
        fps: 30,
        loop_forever: false,
        pace_realtime: false,
    });
    let outs = drive(&node, RuntimeData::Text("kick".into())).await;
    assert_eq!(outs.len(), 0);
}

#[tokio::test]
async fn malformed_lines_are_skipped() {
    let dir = tempfile::tempdir().unwrap();
    let jsonl = dir.path().join("bad.jsonl");
    let mut f = std::fs::File::create(&jsonl).unwrap();
    writeln!(f, "this is not json").unwrap();
    writeln!(
        f,
        "{}",
        serde_json::json!({
            "kind": "skeletal_pose",
            "joint_quats_xyzw": vec![[0.0, 0.0, 0.0, 1.0]; 22],
            "root_pos": [0.0, 0.0, 0.0],
            "pts_ms": 0u64,
        })
    )
    .unwrap();
    writeln!(f, "{{partial json...").unwrap();
    drop(f);

    let node = MotionPlayerNode::new(MotionPlayerConfig {
        jsonl_path: jsonl,
        fps: 30,
        loop_forever: false,
        pace_realtime: false,
    });
    let outs = drive(&node, RuntimeData::Text("kick".into())).await;
    assert_eq!(outs.len(), 1, "only the well-formed line should be emitted");
}

#[tokio::test]
async fn loop_forever_repeats_until_capped() {
    let dir = tempfile::tempdir().unwrap();
    let jsonl = dir.path().join("loop.jsonl");
    write_test_jsonl(&jsonl, 5);

    let node = MotionPlayerNode::new(MotionPlayerConfig {
        jsonl_path: jsonl,
        fps: 30,
        loop_forever: true,
        pace_realtime: false, // unbounded loop — no real sleeping
    });

    // The current implementation is "load once, emit all, loop until break".
    // For a deterministic test, we cap iteration via a callback that
    // returns Err after 17 emissions — proves we'd loop past the 5th line.
    let count = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let count_clone = count.clone();
    let result = node
        .process_streaming(RuntimeData::Text("kick".into()), None, move |_out| {
            let n = count_clone.fetch_add(1, std::sync::atomic::Ordering::AcqRel) + 1;
            if n >= 17 {
                Err(remotemedia_core::Error::Execution(
                    "test cap reached".into(),
                ))
            } else {
                Ok(())
            }
        })
        .await;
    // We expect Err (the cap) — meaning the node looped past iteration 5
    // (3 full passes * 5 lines = 15, plus 2 from the next pass = 17).
    assert!(
        result.is_err(),
        "loop_forever should keep emitting until cap"
    );
    assert_eq!(count.load(std::sync::atomic::Ordering::Acquire), 17);
}

#[test]
fn factory_is_registered_in_core_provider() {
    use remotemedia_core::nodes::core_provider::CoreNodesProvider;
    use remotemedia_core::nodes::provider::NodeProvider;
    use remotemedia_core::nodes::streaming_node::StreamingNodeRegistry;

    let mut reg = StreamingNodeRegistry::new();
    CoreNodesProvider.register(&mut reg);

    let factory = reg
        .get_factory("MotionPlayerNode")
        .expect("MotionPlayerNode factory must be registered by CoreNodesProvider");
    assert_eq!(factory.node_type(), "MotionPlayerNode");
}
