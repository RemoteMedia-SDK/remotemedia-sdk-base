//! Activation-projection face smoke test.
//!
//! Walks the full (projector → routing → BlendshapeFrame) chain.
//! Run with:
//!
//! ```bash
//! cargo run -p remotemedia-core \
//!     --features activation-face \
//!     --example activation_face_smoke
//! ```
//!
//! Picks the NPZ to load via this priority order:
//!
//! 1. `ACTIVATION_NPZ` env var (any path) — explicit override.
//! 2. The Qwen3.5-9B production NPZ at
//!    `tools/affect_calibration/artifacts/llm_directions/qwen3.5-9b/layer15.npz`
//!    if it exists — produced by
//!    `convert_driver_probes_to_npz.py` from
//!    `driver_affect_sim`'s pre-existing probe pickle.
//! 3. A synthetic 3-axis V/A/D NPZ written to a tempdir (last
//!    resort — keeps the smoke binary runnable on a fresh checkout
//!    before any calibration artifact is materialised).
//!
//! Either way, the example:
//!   1. Loads / synthesises an NPZ + resolved ARKit map.
//!   2. Constructs an `ActivationFaceNode`.
//!   3. Feeds three illustrative hidden states and prints the
//!      resulting BlendshapeFrames.
//!
//! See `openspec/changes/add-activation-projection-face/` for the
//! full design + how this stitches into the wider affect chain.

use remotemedia_core::nodes::activation_face::ActivationFaceNode;
use remotemedia_core::nodes::lip_sync::ARKIT_BLENDSHAPE_NAMES;
use remotemedia_core::nodes::llama_cpp::projection::{ActivationProjector, DEFAULT_VAD_LABELS};
use std::io::Write;
use std::path::PathBuf;

fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt::init();

    let tmp_dir =
        std::env::temp_dir().join(format!("activation_face_smoke_{}", std::process::id()));
    std::fs::create_dir_all(&tmp_dir)?;

    // Pick the NPZ source per the priority laid out in the file
    // header: env override → real Qwen3.5-9B NPZ → synthetic.
    let qwen_npz =
        PathBuf::from("tools/affect_calibration/artifacts/llm_directions/qwen3.5-9b/layer15.npz");
    let env_override = std::env::var("ACTIVATION_NPZ").ok().map(PathBuf::from);
    let synthetic_npz = tmp_dir.join("layer_synth.npz");

    let npz_path: PathBuf = if let Some(path) = env_override {
        if !path.exists() {
            anyhow::bail!("ACTIVATION_NPZ={} does not exist", path.display());
        }
        println!("npz source : env override → {}", path.display());
        path
    } else if qwen_npz.exists() {
        println!("npz source : Qwen3.5-9B layer 15 → {}", qwen_npz.display());
        qwen_npz
    } else {
        write_synthetic_npz(&synthetic_npz)?;
        println!(
            "npz source : synthetic V/A/D (real one absent — run \
             tools/affect_calibration/scripts/convert_driver_probes_to_npz.py to generate)",
        );
        synthetic_npz
    };

    let arkit_path = tmp_dir.join("avatar.arkit_map.resolved.json");
    write_synthetic_arkit_map(&arkit_path)?;

    let projector = ActivationProjector::load(&npz_path, DEFAULT_VAD_LABELS)?;
    println!(
        "loaded projector: layer={}, n_embd={}, axes={:?}",
        projector.layer,
        projector.hidden_size,
        projector
            .axes
            .iter()
            .map(|a| a.label.as_str())
            .collect::<Vec<_>>(),
    );
    for axis in &projector.axes {
        println!(
            "  axis {:>10}: raw_norm={:.3} (calibration anchor = raw_norm/2)",
            axis.label, axis.raw_norm
        );
    }

    // Snapshot the axis directions before `projector` is moved into
    // `ActivationFaceNode` so the case-builder below can synthesise
    // axis-aligned hidden states without a back-reference.
    let hidden_size = projector.hidden_size;
    let axis_directions: Vec<Vec<f32>> =
        projector.axes.iter().map(|a| a.direction.clone()).collect();

    // Avatar's morph catalog. The synthetic JSON we wrote above
    // references every entry here, so all three labels route.
    let morphs: Vec<String> = vec![
        "Mood_Happy".to_string(),
        "Mood_Sad".to_string(),
        "Mood_Surprised".to_string(),
    ];

    let face = ActivationFaceNode::new(projector, &arkit_path, &morphs, 0.3)?;

    println!("\nrouting summary (label → matched ARKit indices):");
    for (label, names) in face.routing_summary() {
        if names.is_empty() {
            println!("  {label:<12} -> <unmatched>");
        } else {
            println!("  {label:<12} -> {}", names.join(", "));
        }
    }

    println!(
        "\nblend_alpha = {} (0 = response-only, 1 = input-only, default 0.3)",
        face.blend_alpha()
    );

    // Build illustrative hidden states aligned to each axis's
    // direction so the projection produces predictable scalars
    // regardless of `n_embd` (4 for the synthetic NPZ, 4096 for
    // Qwen3.5-9B's real NPZ). Each test case scales the unit
    // direction vector by an alpha factor — projecting (α · dir)
    // onto the unit direction returns α exactly.
    let make_case = |alphas: [f32; 3]| -> Vec<f32> {
        let mut hidden = vec![0.0f32; hidden_size];
        for (dir, alpha) in axis_directions.iter().zip(alphas.iter()) {
            for (i, &component) in dir.iter().enumerate() {
                hidden[i] += alpha * component;
            }
        }
        hidden
    };

    let cases: Vec<(String, Vec<f32>)> = vec![
        (
            "strong positive valence (response only)".to_string(),
            make_case([10.0, 0.0, 0.0]),
        ),
        (
            "strong negative valence (response only)".to_string(),
            make_case([-10.0, 0.0, 0.0]),
        ),
        ("aroused + dominant".to_string(), make_case([0.0, 6.0, 6.0])),
    ];

    for (label, hidden) in &cases {
        // Just response-side for clarity. The blend with input is
        // exercised in the unit tests.
        let frame = face.process(None, Some(&hidden[..]), 0)?;
        let active: Vec<(usize, f32)> = frame
            .arkit_52
            .iter()
            .enumerate()
            .filter(|(_, w)| **w > 0.05)
            .map(|(i, w)| (i, *w))
            .collect();
        println!("\n[{label}]");
        if active.is_empty() {
            println!("  no morphs above threshold (face stays neutral)");
        } else {
            for (i, w) in active {
                println!(
                    "  arkit[{:>2}] = {:.3}  ({})",
                    i, w, ARKIT_BLENDSHAPE_NAMES[i]
                );
            }
        }
    }

    // Don't leave temp files lying around.
    std::fs::remove_dir_all(&tmp_dir).ok();
    Ok(())
}

#[allow(dead_code)]
fn write_synthetic_npz(path: &PathBuf) -> anyhow::Result<()> {
    use bytemuck::cast_slice;

    // Three axes × 4-dim hidden. Axes aligned to V/A/D names so the
    // synonym map maps them to mood-preset morphs.
    //   valence  → [3, 0, 0, 0]   (norm 3 → unit-norm = [1,0,0,0])
    //   arousal  → [0, 3, 0, 0]
    //   dominance→ [0, 0, 3, 0]
    let directions: [f32; 12] = [3.0, 0.0, 0.0, 0.0, 0.0, 3.0, 0.0, 0.0, 0.0, 0.0, 3.0, 0.0];
    let d_npy = synth_npy("<f4", &[3, 4], cast_slice(&directions));
    let n_embd_npy = synth_npy("<i4", &[], &(4i32).to_le_bytes());
    let layer_npy = synth_npy("<i4", &[], &(21i32).to_le_bytes());

    let file = std::fs::File::create(path)?;
    let mut zw = zip::ZipWriter::new(file);
    let opts: zip::write::FileOptions<()> =
        zip::write::FileOptions::default().compression_method(zip::CompressionMethod::Stored);
    zw.start_file("D.npy", opts)?;
    zw.write_all(&d_npy)?;
    zw.start_file("n_embd.npy", opts)?;
    zw.write_all(&n_embd_npy)?;
    zw.start_file("layer.npy", opts)?;
    zw.write_all(&layer_npy)?;
    zw.finish()?;
    Ok(())
}

fn synth_npy(dtype: &str, shape: &[usize], payload: &[u8]) -> Vec<u8> {
    let shape_str = if shape.is_empty() {
        "()".to_string()
    } else if shape.len() == 1 {
        format!("({},)", shape[0])
    } else {
        let dims: Vec<String> = shape.iter().map(|d| d.to_string()).collect();
        format!("({})", dims.join(", "))
    };
    let header = format!("{{'descr': '{dtype}', 'fortran_order': False, 'shape': {shape_str}, }}");
    let preamble_len = 10;
    let mut header_bytes = header.into_bytes();
    let unpadded = preamble_len + header_bytes.len() + 1;
    let pad = (64 - (unpadded % 64)) % 64;
    header_bytes.extend(std::iter::repeat(b' ').take(pad));
    header_bytes.push(b'\n');
    let mut out = Vec::with_capacity(preamble_len + header_bytes.len() + payload.len());
    out.extend_from_slice(&[0x93, b'N', b'U', b'M', b'P', b'Y']);
    out.push(1);
    out.push(0);
    out.extend_from_slice(&(header_bytes.len() as u16).to_le_bytes());
    out.extend_from_slice(&header_bytes);
    out.extend_from_slice(payload);
    out
}

fn write_synthetic_arkit_map(path: &PathBuf) -> anyhow::Result<()> {
    // Minimal resolved ARKit map. Each ARKit name maps to one CC5
    // mood-preset morph; the synonym map bridges valence↔happy,
    // arousal↔surprised, dominance↔confident at routing time.
    //
    // mouthSmileLeft drives Mood_Happy at coefficient 1.0
    // mouthFrownLeft drives Mood_Sad at 1.0
    // jawOpen drives Mood_Surprised at 0.7 (so we can verify the
    //   morph_weight scaling path through the test JSON output)
    let json = serde_json::json!({
        "mapping": {
            "mouthSmileLeft": [
                {"morph": "Mood_Happy", "weight": 1.0, "meshes": ["Body"]}
            ],
            "mouthFrownLeft": [
                {"morph": "Mood_Sad", "weight": 1.0, "meshes": ["Body"]}
            ],
            "jawOpen": [
                {"morph": "Mood_Surprised", "weight": 0.7, "meshes": ["Body"]}
            ],
        }
    });
    std::fs::write(path, serde_json::to_string_pretty(&json)?)?;
    Ok(())
}
