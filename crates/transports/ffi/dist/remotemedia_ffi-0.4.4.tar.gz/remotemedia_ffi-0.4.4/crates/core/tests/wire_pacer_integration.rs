//! Integration: `ClockedToOutboundMedia` node ticks at the cadence of
//! `media_clock` events published on `SessionControl`.
//!
//! Uses a synthetic publisher (no WebRTC) to drive media_clock at a
//! fixed rate. The session router subscribes the consumer node via
//! `WireTickSource` (Phase 5.4 + 5.1/5.2 wiring) and forwards each
//! tick's emit to the client output channel.
//!
//! Phase 5.5 / 5.9 of the pacing-domains spec: tick at wire cadence;
//! exit cleanly when the producer calls `stop_media_clock`.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

use remotemedia_core::data::RuntimeData;
use remotemedia_core::manifest::{Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::streaming_node::{StreamingNode, StreamingNodeFactory};
use remotemedia_core::nodes::{
    NodeRuntimeContext, NodeRuntimeContextRead, PacingNature, StreamingNodeRegistry, Tick,
};
use remotemedia_core::transport::session_control::{MediaClock, SessionControl};
use remotemedia_core::transport::session_router::{SessionRouter, DEFAULT_ROUTER_OUTPUT_CAPACITY};
use remotemedia_core::Error;
use serde_json::Value;

#[path = "router_test_utils.rs"]
mod router_test_utils;
use router_test_utils::make_test_output_router;

/// Tick-driven node that emits one Json envelope per tick recording
/// `tick.frame_idx`. Returns `ClockedToOutboundMedia` for its pacing
/// nature with a configurable wire-clock binding.
struct WireConsumerNode {
    node_id: String,
    medium: String,
    stream_id: String,
}

#[async_trait::async_trait]
impl StreamingNode for WireConsumerNode {
    fn node_type(&self) -> &str {
        "WireConsumerNode"
    }
    fn node_id(&self) -> &str {
        &self.node_id
    }
    fn pacing_nature(&self) -> PacingNature {
        PacingNature::ClockedToOutboundMedia
    }
    fn clocked_media_addr(&self) -> Option<(String, String)> {
        Some((self.medium.clone(), self.stream_id.clone()))
    }
    fn is_multi_input(&self) -> bool {
        false
    }
    async fn process_async(
        &self,
        _: RuntimeData,
        _: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("tick-only".into()))
    }
    async fn process_multi_async(
        &self,
        _: HashMap<String, RuntimeData>,
        _: &dyn NodeRuntimeContextRead,
    ) -> Result<RuntimeData, Error> {
        Err(Error::Execution("tick-only".into()))
    }
    async fn tick(
        &self,
        tick: Tick,
        _: &dyn NodeRuntimeContextRead,
        mut cb: Box<dyn FnMut(RuntimeData) -> Result<(), Error> + Send>,
    ) -> Result<(), Error> {
        cb(RuntimeData::Json(serde_json::json!({
            "kind": "wire_tick",
            "frame_idx": tick.frame_idx,
            "pts_us": tick.pts_us,
            "clock_id": tick.clock_id,
        })))?;
        Ok(())
    }
}

struct WireConsumerFactory {
    medium: String,
    stream_id: String,
}

impl StreamingNodeFactory for WireConsumerFactory {
    fn create(
        &self,
        node_id: String,
        _: &Value,
        _: Option<String>,
    ) -> Result<Box<dyn StreamingNode>, Error> {
        Ok(Box::new(WireConsumerNode {
            node_id,
            medium: self.medium.clone(),
            stream_id: self.stream_id.clone(),
        }))
    }
    fn node_type(&self) -> &str {
        "WireConsumerNode"
    }
}

/// Drive media_clock from a synthetic producer at 50 Hz for 400 ms,
/// then call stop_media_clock. Verify the consumer:
///   - ticks at the published cadence (≥10 events in 400 ms)
///   - sees the publisher's `frame_idx` and `pts_us` values
///   - exits cleanly when the producer stops (no hang on shutdown)
#[tokio::test]
async fn wire_pacer_drives_node_at_publish_cadence() {
    let session_id = "wire-pacer-e2e".to_string();

    let manifest = Arc::new(Manifest {
        version: "v1".to_string(),
        metadata: ManifestMetadata {
            name: "wire-pacer-e2e".to_string(),
            ..Default::default()
        },
        nodes: vec![NodeManifest {
            id: "consumer".to_string(),
            node_type: "WireConsumerNode".to_string(),
            params: serde_json::json!({}),
            ..Default::default()
        }],
        connections: Vec::new(),
        python_env: None,
        plugins: Vec::new(),
    });

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(WireConsumerFactory {
        medium: "video".to_string(),
        stream_id: "default".to_string(),
    }));
    let registry = Arc::new(registry);

    let (output_router, mut output_rx) = make_test_output_router(DEFAULT_ROUTER_OUTPUT_CAPACITY);
    let (mut router, shutdown_tx) =
        SessionRouter::new(session_id.clone(), manifest, registry, output_router).unwrap();

    // Attach a control bus so the router shares it with the spawned
    // pacer (which subscribes to `video:default` via WireTickSource).
    let control = SessionControl::new(session_id.clone());
    router.attach_control(Arc::clone(&control)).await;

    let _input_tx = router.get_input_sender();
    let handle = router.start();

    // Briefly wait for the session router to initialize and subscribe
    // the consumer to `video:default`. Without this, the producer's
    // first publishes can land before the WireTickSource is registered
    // (broadcast::send returns Err(NoSubs) silently).
    tokio::time::sleep(Duration::from_millis(50)).await;

    // Synthetic producer: publish 50 Hz for 400 ms = 20 events.
    let producer = {
        let control = Arc::clone(&control);
        tokio::spawn(async move {
            let started = std::time::Instant::now();
            let mut idx: u64 = 0;
            while started.elapsed() < Duration::from_millis(400) {
                let pts_us = started.elapsed().as_micros() as u64;
                control.publish_media_clock(
                    "video:default",
                    MediaClock {
                        medium: "video".to_string(),
                        stream_id: "default".to_string(),
                        pts_us,
                        frame_idx: idx,
                        wire_deadline_us: pts_us + 20_000,
                    },
                );
                idx += 1;
                tokio::time::sleep(Duration::from_millis(20)).await;
            }
            // Phase 5.9: stop the wire so the WireTickSource exits.
            control.stop_media_clock("video:default");
        })
    };

    // Collect emitted Json envelopes from the consumer.
    let mut envelopes: Vec<serde_json::Value> = Vec::new();
    let deadline = std::time::Instant::now() + Duration::from_millis(700);
    while std::time::Instant::now() < deadline {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        match tokio::time::timeout(remaining, output_rx.recv()).await {
            Ok(Some(out)) => {
                if let RuntimeData::Json(v) = out {
                    if v.get("kind").and_then(|x| x.as_str()) == Some("wire_tick") {
                        envelopes.push(v);
                    }
                }
            }
            Ok(None) => break,
            Err(_) => break,
        }
    }

    let _ = producer.await;

    // Producer published 20 events at 50 Hz; subscription latency may
    // cause us to miss the first 1-2. Allow generous slack for CI.
    assert!(
        envelopes.len() >= 10,
        "expected ≥10 wire ticks; got {} (subscription latency / lagged)",
        envelopes.len()
    );
    // The producer's frame_idx and pts_us must round-trip through
    // WireTickSource → Pacer → tick(). frame_idx should be monotonic
    // non-decreasing.
    let mut last_idx: Option<u64> = None;
    for v in &envelopes {
        let idx = v.get("frame_idx").and_then(|x| x.as_u64()).unwrap();
        if let Some(prev) = last_idx {
            assert!(
                idx > prev,
                "frame_idx not monotonic: {} after {}",
                idx,
                prev
            );
        }
        last_idx = Some(idx);
        let clock_id = v.get("clock_id").and_then(|x| x.as_str()).unwrap();
        assert_eq!(clock_id, "video:default");
    }

    // The pacer must exit cleanly when the producer stops. We drive
    // shutdown via the dedicated shutdown channel rather than dropping
    // input senders — the attached control bus internally holds a
    // clone of the router's input_tx (via `attach_input_sender`), so
    // input-tx refcount can't drop to zero while `control` is alive.
    // A hung pacer would block teardown indefinitely.
    let _ = shutdown_tx.send(()).await;
    drop(_input_tx);
    let teardown = tokio::time::timeout(Duration::from_secs(2), handle).await;
    assert!(
        teardown.is_ok(),
        "session router did not shut down within 2s"
    );
}
