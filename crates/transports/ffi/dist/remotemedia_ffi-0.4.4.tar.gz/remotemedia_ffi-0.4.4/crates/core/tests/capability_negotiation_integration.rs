//! End-to-end tests for manifest-level capability negotiation.
//!
//! These exercise the surface a typical caller hits: build a manifest with a
//! mismatched audio source rate, run it through `negotiate_manifest`, confirm
//! the system either rewrites the wiring or reports an unresolved warning per
//! the opt-in flags. The intent is to lock down behavior the audit found
//! missing — namely that a VAD→Whisper or chunker→LFM25 manifest with a
//! wrong-rate source gets a FastResampleNode auto-inserted when the operator
//! opts in.

use std::sync::Arc;

use remotemedia_core::capabilities::{
    negotiate_manifest, AudioConstraints, AudioSampleFormat, ConstraintValue, MediaCapabilities,
    MediaConstraints,
};
use remotemedia_core::manifest::{Connection, Manifest, ManifestMetadata, NodeManifest};
use remotemedia_core::nodes::streaming_node::StreamingNodeRegistry;

/// A minimal "fake source" factory: declares an exact output sample rate so we
/// can drive the negotiation algorithm without standing up real audio nodes.
mod fake {
    use async_trait::async_trait;
    use remotemedia_core::capabilities::{
        AudioConstraints, AudioSampleFormat, CapabilityBehavior, ConstraintValue,
        MediaCapabilities, MediaConstraints,
    };
    use remotemedia_core::data::RuntimeData;
    use remotemedia_core::nodes::{
        InitializeContextRead, NodeRuntimeContextRead, StreamingNode, StreamingNodeFactory,
    };
    use remotemedia_core::{Error, Result};
    use serde_json::Value;

    pub struct FakeSource48k;

    #[async_trait]
    impl StreamingNode for FakeSource48k {
        fn node_type(&self) -> &str {
            "FakeSource48k"
        }
        fn node_id(&self) -> &str {
            "fake_source"
        }
        async fn initialize(&self, _ctx: &dyn InitializeContextRead) -> Result<()> {
            Ok(())
        }
        async fn process_async(
            &self,
            data: RuntimeData,
            _ctx: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData> {
            Ok(data)
        }
        async fn process_multi_async(
            &self,
            inputs: std::collections::HashMap<String, RuntimeData>,
            _ctx: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData> {
            inputs
                .into_iter()
                .next()
                .map(|(_, v)| v)
                .ok_or_else(|| Error::Execution("no input".into()))
        }
        fn is_multi_input(&self) -> bool {
            false
        }
    }

    pub struct FakeSource48kFactory;
    impl StreamingNodeFactory for FakeSource48kFactory {
        fn create(
            &self,
            _node_id: String,
            _params: &Value,
            _session_id: Option<String>,
        ) -> Result<Box<dyn StreamingNode>> {
            Ok(Box::new(FakeSource48k))
        }
        fn node_type(&self) -> &str {
            "FakeSource48k"
        }
        fn capability_behavior(&self) -> CapabilityBehavior {
            CapabilityBehavior::Static
        }
        fn media_capabilities(&self, _params: &Value) -> Option<MediaCapabilities> {
            Some(MediaCapabilities::with_output(MediaConstraints::Audio(
                AudioConstraints {
                    sample_rate: Some(ConstraintValue::Exact(48_000)),
                    channels: Some(ConstraintValue::Exact(1)),
                    format: Some(ConstraintValue::Exact(AudioSampleFormat::F32)),
                },
            )))
        }
    }

    /// Sink that requires 16 kHz mono f32 — same shape as Whisper / LFM2.5.
    pub struct FakeSink16k;
    #[async_trait]
    impl StreamingNode for FakeSink16k {
        fn node_type(&self) -> &str {
            "FakeSink16k"
        }
        fn node_id(&self) -> &str {
            "fake_sink"
        }
        async fn initialize(&self, _ctx: &dyn InitializeContextRead) -> Result<()> {
            Ok(())
        }
        async fn process_async(
            &self,
            data: RuntimeData,
            _ctx: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData> {
            Ok(data)
        }
        async fn process_multi_async(
            &self,
            inputs: std::collections::HashMap<String, RuntimeData>,
            _ctx: &dyn NodeRuntimeContextRead,
        ) -> Result<RuntimeData> {
            inputs
                .into_iter()
                .next()
                .map(|(_, v)| v)
                .ok_or_else(|| Error::Execution("no input".into()))
        }
        fn is_multi_input(&self) -> bool {
            false
        }
    }

    pub struct FakeSink16kFactory;
    impl StreamingNodeFactory for FakeSink16kFactory {
        fn create(
            &self,
            _node_id: String,
            _params: &Value,
            _session_id: Option<String>,
        ) -> Result<Box<dyn StreamingNode>> {
            Ok(Box::new(FakeSink16k))
        }
        fn node_type(&self) -> &str {
            "FakeSink16k"
        }
        fn capability_behavior(&self) -> CapabilityBehavior {
            CapabilityBehavior::Static
        }
        fn media_capabilities(&self, _params: &Value) -> Option<MediaCapabilities> {
            Some(MediaCapabilities::with_input(MediaConstraints::Audio(
                AudioConstraints {
                    sample_rate: Some(ConstraintValue::Exact(16_000)),
                    channels: Some(ConstraintValue::Exact(1)),
                    format: Some(ConstraintValue::Exact(AudioSampleFormat::F32)),
                },
            )))
        }
    }
}

fn build_registry() -> StreamingNodeRegistry {
    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(fake::FakeSource48kFactory));
    registry.register(Arc::new(fake::FakeSink16kFactory));
    registry
}

fn mismatched_manifest(auto_negotiate: bool) -> Arc<Manifest> {
    Arc::new(Manifest {
        version: "v1".into(),
        metadata: ManifestMetadata {
            auto_negotiate,
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "source".into(),
                node_type: "FakeSource48k".into(),
                ..Default::default()
            },
            NodeManifest {
                id: "sink".into(),
                node_type: "FakeSink16k".into(),
                ..Default::default()
            },
        ],
        connections: vec![Connection {
            from: "source".into(),
            to: "sink".into(),
            from_port: None,
            to_port: None,
        }],
        python_env: None,
        plugins: Vec::new(),
    })
}

#[test]
fn mismatch_without_auto_negotiate_produces_warning() {
    let registry = build_registry();
    let m = mismatched_manifest(/*auto_negotiate=*/ false);
    let outcome = negotiate_manifest(m, &registry);

    assert!(
        outcome.has_unresolved(),
        "expected a sample_rate mismatch warning"
    );
    assert!(
        outcome.inserted_nodes.is_empty(),
        "no insertion without opt-in"
    );
    // Manifest is unchanged
    assert_eq!(outcome.manifest.nodes.len(), 2);
    assert_eq!(outcome.manifest.connections.len(), 1);
}

#[test]
fn mismatch_with_auto_negotiate_inserts_fastresample() {
    let registry = build_registry();
    let m = mismatched_manifest(/*auto_negotiate=*/ true);
    let outcome = negotiate_manifest(m, &registry);

    assert!(
        outcome.warnings.is_empty(),
        "negotiation should resolve the gap"
    );
    assert_eq!(
        outcome.inserted_nodes.len(),
        1,
        "exactly one FastResampleNode expected for rate mismatch"
    );
    let inserted = &outcome.inserted_nodes[0];
    assert_eq!(inserted.node_type, "FastResampleNode");
    assert_eq!(inserted.between, ("source".into(), "sink".into()));
    assert_eq!(inserted.params["source_rate"], 48_000);
    assert_eq!(inserted.params["target_rate"], 16_000);

    // Manifest should now be: source → _auto_convert_1 → sink
    assert_eq!(outcome.manifest.nodes.len(), 3);
    assert_eq!(outcome.manifest.connections.len(), 2);
    assert_eq!(outcome.manifest.connections[0].from, "source");
    assert_eq!(outcome.manifest.connections[0].to, inserted.id);
    assert_eq!(outcome.manifest.connections[1].from, inserted.id);
    assert_eq!(outcome.manifest.connections[1].to, "sink");
}

#[test]
fn format_mismatch_with_auto_negotiate_inserts_format_converter() {
    // Source declares I16 output, sink wants F32. Auto-negotiate should splice
    // FastFormatConverterNode between them so the sink's format constraint is
    // satisfied. Sample rate matches on both sides so no resampler appears.
    struct I16SourceFactory;
    impl remotemedia_core::nodes::StreamingNodeFactory for I16SourceFactory {
        fn create(
            &self,
            _node_id: String,
            _params: &serde_json::Value,
            _session_id: Option<String>,
        ) -> remotemedia_core::Result<Box<dyn remotemedia_core::nodes::StreamingNode>> {
            Ok(Box::new(fake::FakeSink16k))
        }
        fn node_type(&self) -> &str {
            "I16Source16k"
        }
        fn capability_behavior(&self) -> remotemedia_core::capabilities::CapabilityBehavior {
            remotemedia_core::capabilities::CapabilityBehavior::Static
        }
        fn media_capabilities(&self, _p: &serde_json::Value) -> Option<MediaCapabilities> {
            Some(MediaCapabilities::with_output(MediaConstraints::Audio(
                AudioConstraints {
                    sample_rate: Some(ConstraintValue::Exact(16_000)),
                    channels: Some(ConstraintValue::Exact(1)),
                    format: Some(ConstraintValue::Exact(AudioSampleFormat::I16)),
                },
            )))
        }
    }

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(I16SourceFactory));
    registry.register(Arc::new(fake::FakeSink16kFactory));

    let m = Arc::new(Manifest {
        version: "v1".into(),
        metadata: ManifestMetadata {
            auto_negotiate: true,
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "source".into(),
                node_type: "I16Source16k".into(),
                ..Default::default()
            },
            NodeManifest {
                id: "sink".into(),
                node_type: "FakeSink16k".into(),
                ..Default::default()
            },
        ],
        connections: vec![Connection {
            from: "source".into(),
            to: "sink".into(),
            from_port: None,
            to_port: None,
        }],
        python_env: None,
        plugins: Vec::new(),
    });

    let outcome = negotiate_manifest(m, &registry);
    assert!(
        outcome.warnings.is_empty(),
        "negotiation should bridge format mismatch"
    );
    assert_eq!(outcome.inserted_nodes.len(), 1);
    assert_eq!(
        outcome.inserted_nodes[0].node_type,
        "FastFormatConverterNode"
    );
    assert_eq!(outcome.inserted_nodes[0].params["target_format"], "f32");
    assert_eq!(outcome.inserted_nodes[0].params["source_format"], "i16");
}

#[test]
fn rate_and_format_mismatch_chains_resample_then_format() {
    // Source: 48 kHz I16, sink: 16 kHz F32. Negotiation should emit two hops
    // in dependency order: resample → format-convert.
    struct I16At48kFactory;
    impl remotemedia_core::nodes::StreamingNodeFactory for I16At48kFactory {
        fn create(
            &self,
            _node_id: String,
            _params: &serde_json::Value,
            _session_id: Option<String>,
        ) -> remotemedia_core::Result<Box<dyn remotemedia_core::nodes::StreamingNode>> {
            Ok(Box::new(fake::FakeSink16k))
        }
        fn node_type(&self) -> &str {
            "I16Source48k"
        }
        fn capability_behavior(&self) -> remotemedia_core::capabilities::CapabilityBehavior {
            remotemedia_core::capabilities::CapabilityBehavior::Static
        }
        fn media_capabilities(&self, _p: &serde_json::Value) -> Option<MediaCapabilities> {
            Some(MediaCapabilities::with_output(MediaConstraints::Audio(
                AudioConstraints {
                    sample_rate: Some(ConstraintValue::Exact(48_000)),
                    channels: Some(ConstraintValue::Exact(1)),
                    format: Some(ConstraintValue::Exact(AudioSampleFormat::I16)),
                },
            )))
        }
    }

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(I16At48kFactory));
    registry.register(Arc::new(fake::FakeSink16kFactory));

    let m = Arc::new(Manifest {
        version: "v1".into(),
        metadata: ManifestMetadata {
            auto_negotiate: true,
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "source".into(),
                node_type: "I16Source48k".into(),
                ..Default::default()
            },
            NodeManifest {
                id: "sink".into(),
                node_type: "FakeSink16k".into(),
                ..Default::default()
            },
        ],
        connections: vec![Connection {
            from: "source".into(),
            to: "sink".into(),
            from_port: None,
            to_port: None,
        }],
        python_env: None,
        plugins: Vec::new(),
    });

    let outcome = negotiate_manifest(m, &registry);
    assert!(outcome.warnings.is_empty());
    assert_eq!(outcome.inserted_nodes.len(), 2);
    assert_eq!(outcome.inserted_nodes[0].node_type, "FastResampleNode");
    assert_eq!(
        outcome.inserted_nodes[1].node_type,
        "FastFormatConverterNode"
    );

    // The rewritten manifest chains: source → resample → format-convert → sink.
    let conns = &outcome.manifest.connections;
    assert_eq!(conns.len(), 3);
    assert_eq!(conns[0].from, "source");
    assert_eq!(conns[0].to, outcome.inserted_nodes[0].id);
    assert_eq!(conns[1].from, outcome.inserted_nodes[0].id);
    assert_eq!(conns[1].to, outcome.inserted_nodes[1].id);
    assert_eq!(conns[2].from, outcome.inserted_nodes[1].id);
    assert_eq!(conns[2].to, "sink");
}

#[test]
fn matched_manifest_is_returned_unchanged() {
    // source@16k → sink@16k — no insertion needed.
    struct Match16kFactory;
    impl remotemedia_core::nodes::StreamingNodeFactory for Match16kFactory {
        fn create(
            &self,
            _node_id: String,
            _params: &serde_json::Value,
            _session_id: Option<String>,
        ) -> remotemedia_core::Result<Box<dyn remotemedia_core::nodes::StreamingNode>> {
            Ok(Box::new(fake::FakeSink16k))
        }
        fn node_type(&self) -> &str {
            "Match16kSource"
        }
        fn capability_behavior(&self) -> remotemedia_core::capabilities::CapabilityBehavior {
            remotemedia_core::capabilities::CapabilityBehavior::Static
        }
        fn media_capabilities(&self, _params: &serde_json::Value) -> Option<MediaCapabilities> {
            Some(MediaCapabilities::with_output(MediaConstraints::Audio(
                AudioConstraints {
                    sample_rate: Some(ConstraintValue::Exact(16_000)),
                    channels: Some(ConstraintValue::Exact(1)),
                    format: Some(ConstraintValue::Exact(AudioSampleFormat::F32)),
                },
            )))
        }
    }

    let mut registry = StreamingNodeRegistry::new();
    registry.register(Arc::new(Match16kFactory));
    registry.register(Arc::new(fake::FakeSink16kFactory));

    let m = Arc::new(Manifest {
        version: "v1".into(),
        metadata: ManifestMetadata {
            auto_negotiate: true,
            ..Default::default()
        },
        nodes: vec![
            NodeManifest {
                id: "source".into(),
                node_type: "Match16kSource".into(),
                ..Default::default()
            },
            NodeManifest {
                id: "sink".into(),
                node_type: "FakeSink16k".into(),
                ..Default::default()
            },
        ],
        connections: vec![Connection {
            from: "source".into(),
            to: "sink".into(),
            from_port: None,
            to_port: None,
        }],
        python_env: None,
        plugins: Vec::new(),
    });

    let outcome = negotiate_manifest(m, &registry);
    assert!(outcome.warnings.is_empty());
    assert!(outcome.inserted_nodes.is_empty());
    assert_eq!(outcome.manifest.nodes.len(), 2);
}
